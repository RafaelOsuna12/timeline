﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Plugin.Contacts;
using Plugin.Contacts.Abstractions;
using WowonderPhone.Classes;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages;
using WowonderPhone.Pages.Tabs;
using WowonderPhone.Pages.Timeline_Pages.AddPostNavPages;
using WowonderPhone.SQLite;
using Xamarin.Forms;
using WowonderPhone.SQLite.Tables;

namespace WowonderPhone.Controls
{
    public class Functions
    {
        public static ObservableCollection<ChatUsers> ChatList = new ObservableCollection<ChatUsers>();
        public static ObservableCollection<UserContacts> ChatContactsList = new ObservableCollection<UserContacts>();
        public static ObservableCollection<GroupedChatList> grouped = new ObservableCollection<GroupedChatList>();

        public static ObservableCollection<GroupedRandomContacts> groupedRandomlist =
            new ObservableCollection<GroupedRandomContacts>();

        public static ObservableCollection<SearchResult> SearchFilterlist = new ObservableCollection<SearchResult>();

        public static ObservableCollection<MessageViewModal> Messages = new ObservableCollection<MessageViewModal>();
        public static string NumberOfcontacts;
        public static string Aftercontact = "0";
        public static string NotifiStoper = "0";



        //public static async Task<string> GetChatActivity(string userid, string session)
        //{
        //    try
        //    {
        //        #region Client Respone

        //        using (var client = new HttpClient())
        //        {
        //            var formContent = new FormUrlEncodedContent(new[]
        //            {
        //                new KeyValuePair<string, string>("user_id", Settings.User_id),
        //                new KeyValuePair<string, string>("user_profile_id", Settings.User_id),
        //                new KeyValuePair<string, string>("s", Settings.Session),
        //                new KeyValuePair<string, string>("list_type", "all")
        //            });

        //            var response =
        //                await
        //                    client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_users_list",
        //                        formContent).ConfigureAwait(false);
        //            response.EnsureSuccessStatusCode();
        //            string json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
        //            var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
        //            string apiStatus = data["api_status"].ToString();

        //            #endregion

        //            if (apiStatus == "200")
        //            {
        //                // Functions.ChatList.Clear();

        //                #region Respone Success

        //                var Users = data["users"];
        //                string ThemeUrl = data["theme_url"].ToString();
        //                var users = JObject.Parse(json).SelectToken("users").ToString();
                      
        //                JArray Chatusers = JArray.Parse(users);
        //                if (Chatusers.Count <= 0)
        //                {
        //                    var Cheke =
        //                        ChatList.FirstOrDefault(
        //                            a => a.Username == "  " + "  " + "  " + Settings.Label_NoAnyChatActivityAvailable);
        //                    if (ChatList.Contains(Cheke))
        //                    {

        //                    }
        //                    else
        //                    {
        //                        ChatList.Insert(0, new ChatUsers()
        //                        {
        //                            Username = "  " + "  " + "  " + Settings.Label_NoAnyChatActivityAvailable,
        //                            lastseen = "  ",
        //                            profile_picture = "  ",
        //                            TextMessage = "  ",
        //                            LastMessageDateTime = "  ",
        //                            UserID = "  ",
        //                            SeenMessageOrNo = "Transparent",
        //                            ChekeSeen = "false",
        //                            OnOficon = "  ",
        //                            TimeLong = "  ",
        //                            profile_picture_Url = "  "
        //                        });
        //                    }

        //                    return null;
        //                }

        //                //var ListTodelete = new ChatActivityFunctions();
        //                // ListTodelete.ClearChatUserTable();
        //                foreach (var ChatUser in Chatusers)
        //                {


        //                    JObject ChatlistUserdata = JObject.FromObject(ChatUser);
        //                    var ChatUser_User_ID = ChatlistUserdata["user_id"].ToString();
        //                    var ChatUser_avatar = ChatlistUserdata["profile_picture"].ToString();
        //                    var ChatUser_name = ChatlistUserdata["name"].ToString();
        //                    var ChatUser_lastseen = ChatlistUserdata["lastseen"].ToString();
        //                    // var ChatUser_lastseen_Time_Text = ChatlistUserdata["lastseen_time_text"].ToString();
        //                    //var ChatUser_verified = ChatlistUserdata["verified"].ToString();


        //                    JObject ChatlistuserLastMessage = JObject.FromObject(ChatlistUserdata["last_message"]);
        //                    var listuserLastMessage_Text = ChatlistuserLastMessage["text"].ToString();
        //                    var listuserLastMessage_date_time = ChatlistuserLastMessage["date_time"].ToString();
        //                    var SeenCo = ChatlistuserLastMessage["seen"].ToString();
        //                    var fromId = ChatlistuserLastMessage["from_id"].ToString();
        //                    var Messageid = ChatlistuserLastMessage["id"].ToString();
        //                    var Time = ChatlistuserLastMessage["time"].ToString();
        //                    var mediaFileName = ChatlistuserLastMessage["media"].ToString();

        //                    listuserLastMessage_Text = System.Net.WebUtility.HtmlDecode(listuserLastMessage_Text);
        //                    var MediafileIcon = "";
        //                    if (mediaFileName.Contains("soundFile"))
        //                    {
        //                        MediafileIcon = Settings.FN_SoundFileEmoji;
        //                    }
        //                    else if (mediaFileName.Contains("image"))
        //                    {
        //                        MediafileIcon = Settings.FN_ImageFileEmoji;
        //                    }
        //                    else if (mediaFileName.Contains("video"))
        //                    {
        //                        MediafileIcon = Settings.FN_VideoFileEmoji;
        //                    }
        //                    if (listuserLastMessage_Text == "")
        //                    {
        //                        listuserLastMessage_Text = MediafileIcon;
        //                    }
        //                    else
        //                    {
        //                        listuserLastMessage_Text = listuserLastMessage_Text
        //                            .Replace(":)", "\ud83d\ude0a")
        //                            .Replace(";)", "\ud83d\ude09")
        //                            .Replace("0)", "\ud83d\ude07")
        //                            .Replace("(<", "\ud83d\ude02")
        //                            .Replace(":D", "\ud83d\ude01")
        //                            .Replace("*_*", "\ud83d\ude0d")
        //                            .Replace("(<", "\ud83d\ude02")
        //                            .Replace("<3", "\ud83d\u2764")
        //                            .Replace("/_)", "\ud83d\ude0f")
        //                            .Replace("-_-", "\ud83d\ude11")
        //                            .Replace(":-/", "\ud83d\ude15")
        //                            .Replace(":*", "\ud83d\ude18")
        //                            .Replace(":_p", "\ud83d\ude1b")
        //                            .Replace(":p", "\ud83d\ude1c")
        //                            .Replace("x(", "\ud83d\ude20")
        //                            .Replace("X(", "\ud83d\ude21")
        //                            .Replace(":_(", "\ud83d\ude22")
        //                            .Replace("<5", "\ud83d\u2B50")
        //                            .Replace(":0", "\ud83d\ude31")
        //                            .Replace("B)", "\ud83d\ude0e")
        //                            .Replace("o(", "\ud83d\ude27")
        //                            .Replace("</3", "\uD83D\uDC94")
        //                            .Replace(":o", "\ud83d\ude26")
        //                            .Replace("o(", "\ud83d\ude27")
        //                            .Replace(":__(", "\ud83d\ude2d")
        //                            .Replace("!_", "\uD83D\u2757")
        //                            .Replace("<br> <br>", " ").Replace("<br>", " ");

        //                    }

        //                    var color = "Transparent";
        //                    var Chekicon = "false";

        //                    if (fromId != Settings.User_id)
        //                    {
        //                        if (SeenCo == "0")
        //                        {
        //                            int Messageidx = Int32.Parse(Messageid);
        //                            var Style = "Text";
        //                            color = Settings.UnseenMesageColor;

        //                            using (var Notifi = new NotifiFunctions())
        //                            {
        //                                var Exits = Notifi.GetNotifiDBCredentialsById(Messageidx);
        //                                if (Exits == null)
        //                                {
        //                                    Notifi.InsertNotifiDBCredentials(new NotifiDB
        //                                    {
        //                                        messageid = Messageidx,
        //                                        Seen = 0
        //                                    });
        //                                }

        //                                var Exits2 = Notifi.GetNotifiDBCredentialsById(Messageidx);
        //                                if (Exits2.Seen == 0 && NotifiStoper != ChatUser_User_ID)
        //                                {
        //                                    var Iconavatr =
        //                                        DependencyService.Get<IPicture>()
        //                                            .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID);
        //                                    DependencyService.Get<ILocalNotificationService>()
        //                                        .CreateLocalNotification(listuserLastMessage_Text, ChatUser_name,
        //                                            Iconavatr, ChatUser_User_ID, Style);
        //                                    Exits2.Seen = 1;
        //                                    Notifi.UpdateNotifiDBCredentials(Exits2);
        //                                }
        //                            }
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (SeenCo != "0")
        //                        {
        //                            Chekicon = "true";
        //                        }
        //                    }

        //                    var Imagepath = DependencyService.Get<IPicture>()
        //                        .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID);
        //                    var ImageMediaFile = ImageSource.FromFile(Imagepath);

        //                    if (
        //                        DependencyService.Get<IPicture>().GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID) ==
        //                        "File Dont Exists")
        //                    {
        //                        ImageMediaFile = new UriImageSource {Uri = new Uri(ChatUser_avatar)};
        //                        DependencyService.Get<IPicture>().SavePictureToDisk(ChatUser_avatar, ChatUser_User_ID);
        //                    }

        //                    #region Show_Online_Oflline_Icon

        //                    ImageSource OnlineOfflineIcon = ImageSource.FromFile("");
        //                    var OnOficon = "";
        //                    if (Settings.Show_Online_Oflline_Icon)
        //                    {
        //                        if (ChatUser_lastseen == "on")
        //                        {
        //                            OnOficon =
        //                                DependencyService.Get<IPicture>()
        //                                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/online.png", "Icons");
        //                            OnlineOfflineIcon = ImageSource.FromFile(OnOficon);



        //                            if (
        //                                DependencyService.Get<IPicture>()
        //                                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/online.png", "Icons") ==
        //                                "File Dont Exists")
        //                            {
        //                                OnlineOfflineIcon = new UriImageSource
        //                                {
        //                                    Uri = new Uri(ThemeUrl + "/img/windows_app/online.png")
        //                                };
        //                                DependencyService.Get<IPicture>()
        //                                    .SavePictureToDisk(ThemeUrl + "/img/windows_app/online.png", "Icons");
        //                            }

        //                        }
        //                        else
        //                        {
        //                            OnOficon =
        //                                DependencyService.Get<IPicture>()
        //                                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons");
        //                            OnlineOfflineIcon = ImageSource.FromFile(OnOficon);

        //                            if (
        //                                DependencyService.Get<IPicture>()
        //                                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons") ==
        //                                "File Dont Exists")
        //                            {
        //                                OnlineOfflineIcon = new UriImageSource
        //                                    {Uri = new Uri(ThemeUrl + "/img/windows_app/offline.png")};
        //                                DependencyService.Get<IPicture>()
        //                                    .SavePictureToDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons");
        //                            }
        //                        }

        //                    }

        //                    #endregion

        //                    var ChekeForNotAvailbleLabel =
        //                        ChatList.FirstOrDefault(
        //                            a => a.Username == "  " + "  " + "  " + Settings.Label_NoAnyChatActivityAvailable);
        //                    if (ChatList.Contains(ChekeForNotAvailbleLabel))
        //                    {
        //                        ChatList.Remove(ChekeForNotAvailbleLabel);
        //                    }

        //                    var Cheke = ChatList.FirstOrDefault(a => a.UserID == ChatUser_User_ID);
        //                    if (ChatList.Contains(Cheke))
        //                    {
        //                        //Cheke for online/offline Status
        //                        if (Cheke.OnOficon != OnOficon)
        //                        {
        //                            Cheke.OnOficon = OnOficon;
        //                            Cheke.lastseen = OnlineOfflineIcon;
        //                        }

        //                        if (Cheke.TextMessage != listuserLastMessage_Text)
        //                        {
        //                            var q =
        //                                ChatList.IndexOf(
        //                                    ChatList.Where(X => X.UserID == ChatUser_User_ID).FirstOrDefault());
        //                            if (q > -1)
        //                            {
        //                                Cheke.TextMessage = listuserLastMessage_Text;
        //                                Cheke.Username = ChatUser_name;
        //                                Cheke.TimeLong = Time;
        //                                ChatList.Move(q, 0);
        //                            }

        //                        }
        //                        //Change  User image if the user changed his avatar picture
        //                        if (Cheke.profile_picture_Url != Imagepath)
        //                        {
        //                            Cheke.profile_picture_Url = Imagepath;
        //                            Cheke.profile_picture = ImageMediaFile;
        //                        }
        //                        if (Cheke.SeenMessageOrNo != color ||
        //                            Cheke.LastMessageDateTime != listuserLastMessage_date_time)
        //                        {
        //                            Cheke.SeenMessageOrNo = color;
        //                            Cheke.LastMessageDateTime = listuserLastMessage_date_time;
        //                        }
        //                        if (Cheke.ChekeSeen != Chekicon)
        //                        {
        //                            Cheke.ChekeSeen = Chekicon;
        //                        }


        //                    }
        //                    else
        //                    {
        //                        ChatList.Insert(0, new ChatUsers()
        //                        {
        //                            Username = ChatUser_name,
        //                            lastseen = OnlineOfflineIcon,
        //                            profile_picture = ImageMediaFile,
        //                            TextMessage = listuserLastMessage_Text,
        //                            LastMessageDateTime = listuserLastMessage_date_time,
        //                            UserID = ChatUser_User_ID,
        //                            SeenMessageOrNo = color,
        //                            ChekeSeen = Chekicon,
        //                            OnOficon = OnOficon,
        //                            TimeLong = Time,
        //                            profile_picture_Url = Imagepath
        //                        });
        //                    }

        //                    using (var datas = new ChatActivityFunctions())
        //                    {
        //                        var contact = datas.GetChatUser(ChatUser_User_ID);
        //                        if (contact != null)
        //                        {
        //                            if (contact.UserID == ChatUser_User_ID &
        //                                ((contact.Name != ChatUser_name) || (contact.ProfilePicture != ChatUser_avatar) ||
        //                                 (contact.Username != ChatUser_name) || (contact.ChekeSeen != Chekicon)
        //                                 || (contact.SeenMessageOrNo != color) || (contact.TimeLong != Time)))
        //                            {

        //                                if ((contact.ProfilePicture != ChatUser_avatar))
        //                                {
        //                                    if (Settings.Delete_Old_Profile_Picture_From_Phone)
        //                                    {
        //                                        DependencyService.Get<IPicture>()
        //                                            .DeletePictureFromDisk(contact.ProfilePicture, ChatUser_User_ID);
        //                                    }

        //                                }

        //                                contact.UserID = ChatUser_User_ID;
        //                                contact.LastMessageDateTime = listuserLastMessage_date_time;
        //                                contact.Name = ChatUser_name;
        //                                contact.ProfilePicture = ChatUser_avatar;
        //                                contact.SeenMessageOrNo = color;
        //                                contact.TextMessage = listuserLastMessage_Text;
        //                                contact.Username = ChatUser_name;
        //                                contact.ChekeSeen = Chekicon;
        //                                contact.TimeLong = Time;
        //                                datas.UpdateChatUsers(contact);
        //                            }

        //                        }
        //                        else
        //                        {
        //                            datas.InsertChatUsers(new ChatActivityDB()
        //                            {
        //                                UserID = ChatUser_User_ID,
        //                                LastMessageDateTime = listuserLastMessage_date_time,
        //                                Name = ChatUser_name,
        //                                ProfilePicture = ChatUser_avatar,
        //                                SeenMessageOrNo = color,
        //                                TextMessage = listuserLastMessage_Text,
        //                                Username = ChatUser_name,
        //                                ChekeSeen = Chekicon,
        //                                TimeLong = Time,
        //                                lastseen = OnlineOfflineIcon.ToString()
        //                            });
        //                        }
        //                    }
        //                }

        //                #endregion

        //            }
        //            else if (apiStatus == "400")
        //            {
        //                json = Settings.Label_Error;
        //            }

        //            return json;
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return Settings.Label_Error;
        //    }

        //}


       

        public static async Task<string> GetChatContacts(string userid, string session)
        {
            #region Client Respone
            try
            {
                using (var client = new HttpClient())
                {

                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("user_profile_id", Settings.User_id),
                        new KeyValuePair<string, string>("s", Settings.Session),
                        new KeyValuePair<string, string>("after_user_id", Aftercontact),
                        new KeyValuePair<string, string>("list_type", "all")

                    });
                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_users_friends",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    string ThemeUrl = data["theme_url"].ToString();
                    #endregion

                    if (apiStatus == "200")
                    {
                        
                        var users = JObject.Parse(json).SelectToken("users").ToString();
                        var usersOnline = JObject.Parse(json).SelectToken("online").ToString();
                        JArray ChatusersOnlineGroup = JArray.Parse(usersOnline);
                        JArray Chatusers = JArray.Parse(users);

                        if (Chatusers.Count == 0)
                        {
                            Aftercontact = "0";
                            ChatContactsList.Add(new UserContacts()
                            {
                                Username = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble,

                                Name = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble

                            });

                            return null;
                        }
                        ChatContactsList.Clear();
                   
                        foreach (var Onlines in ChatusersOnlineGroup)
                        {
                            JObject ChatlistUserdata = JObject.FromObject(Onlines);
                            var ChatUser_User_ID = ChatlistUserdata["user_id"].ToString();
                            var ChatUser_avatar = ChatlistUserdata["profile_picture"].ToString();
                            var ChatUser_name = ChatlistUserdata["name"].ToString();
                            var Username = ChatlistUserdata["username"].ToString();
                            var ChatUser_lastseen = ChatlistUserdata["lastseen"].ToString();
                            var ChatUser_lastseen_Time_Text = ChatlistUserdata["lastseen_time_text"].ToString();
                            var ChatUser_verified = ChatlistUserdata["verified"].ToString();
                            var UserPlatform = ChatlistUserdata["user_platform"].ToString();

                            Aftercontact = ChatUser_User_ID;

                            if (UserPlatform == "phone")
                            {
                                UserPlatform = AppResources.Label_Mobile;
                            }
                            if (UserPlatform == "web")
                            {
                                UserPlatform = AppResources.Label_Web;
                            }
                            if (UserPlatform == "windows")
                            {
                                UserPlatform = AppResources.Label_Desktop;
                            }

                            #region Saving image

                            var ImageMediaFile =
                                ImageSource.FromFile(DependencyService.Get<IPicture>()
                                    .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID));
                            if ( DependencyService.Get<IPicture>().GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID) =="File Dont Exists")
                            {
                                ImageMediaFile = new UriImageSource { Uri = new Uri(ChatUser_avatar) };

                                ImageMediaFile = new UriImageSource
                                {
                                    Uri =new Uri(ChatUser_avatar),
                                    CachingEnabled = true,
                                    CacheValidity = new TimeSpan(5, 0, 0, 0)
                                };
                                DependencyService.Get<IPicture>().SavePictureToDisk(ChatUser_avatar, ChatUser_User_ID);
                            }
                            
                           
                            var OnlineOfflineIcon = ImageSource.FromFile("");
                            //if (Settings.Show_Online_Oflline_Icon)
                            //{
                            //    if (ChatUser_lastseen == "on")
                            //    {
                            //        OnlineOfflineIcon =
                            //            ImageSource.FromFile(
                            //                DependencyService.Get<IPicture>()
                            //                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/online.png", "Icons"));
                            //        if (
                            //            DependencyService.Get<IPicture>()
                            //                .GetPictureFromDisk(ThemeUrl + "/img/windows_app/online.png", "Icons") ==
                            //            "File Dont Exists")
                            //        {
                            //            OnlineOfflineIcon = new UriImageSource
                            //            {
                            //                Uri = new Uri(ThemeUrl + "/img/windows_app/online.png")
                            //            };
                            //            DependencyService.Get<IPicture>()
                            //                .SavePictureToDisk(ThemeUrl + "/img/windows_app/online.png", "Icons");
                            //        }

                            //    }
                            //    else
                            //    {
                            //        OnlineOfflineIcon =
                            //            ImageSource.FromFile(
                            //                DependencyService.Get<IPicture>()
                            //                    .GetPictureFromDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons"));
                            //        if (
                            //            DependencyService.Get<IPicture>()
                            //                .GetPictureFromDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons") ==
                            //            "File Dont Exists")
                            //        {
                            //            OnlineOfflineIcon = new UriImageSource
                            //            { Uri = new Uri(ThemeUrl + "/img/windows_app/offline.png") };
                            //            DependencyService.Get<IPicture>()
                            //                .SavePictureToDisk(ThemeUrl + "/img/windows_app/offline.png", "Icons");
                            //        }
                            //    }

                            //}

                            #endregion

                            if (ChatUser_lastseen == "on")
                            {
                                ChatContactsList.Add(new UserContacts()
                                {
                                    Username = ChatUser_name,
                                    lastseen = OnlineOfflineIcon,
                                    Name = ChatUser_name,
                                    SeenMessageOrNo = ChatUser_lastseen,
                                    profile_picture = ImageMediaFile,
                                    LastMessageDateTime = AppResources.Label_Online,
                                    //verified = ChatUser_verified_bitmap,
                                    UserID = ChatUser_User_ID,
                                    Platform = UserPlatform,
                                      Checkicon = "\uf1db",
                                    CheckiconColor = Settings.MainColor
                                });

                            }
                            #region adding to Sqlite table  

                            using (var datas = new ContactsFunctions())
                            {
                                var contact = datas.GetContactUser(ChatUser_User_ID);

                                #region Update contact information

                                if (contact != null)
                                {
                                    if (contact.UserID == ChatUser_User_ID &&
                                        ((contact.Name != ChatUser_name) || (contact.ProfilePicture != ChatUser_avatar) ||
                                         (contact.Username != Username) ||
                                         (contact.LastMessageDateTime != ChatUser_lastseen_Time_Text) ||
                                         (contact.Platform != UserPlatform)))
                                    {
                                        if ((contact.ProfilePicture != ChatUser_avatar))
                                        {
                                            datas.DeleteContactRow(contact);
                                            DependencyService.Get<IPicture>()
                                                .DeletePictureFromDisk(contact.ProfilePicture, ChatUser_User_ID);
                                            datas.InsertContactUsers(new ContactsTableDB()
                                            {
                                                UserID = ChatUser_User_ID,
                                                Name = ChatUser_name,
                                                ProfilePicture = ChatUser_avatar,
                                                SeenMessageOrNo = ChatUser_lastseen,
                                                LastMessageDateTime = ChatUser_lastseen_Time_Text,
                                                Username = Username,
                                                Platform = UserPlatform
                                            });
                                        }

                                        contact.UserID = ChatUser_User_ID;
                                        contact.Name = ChatUser_name;
                                        contact.ProfilePicture = ChatUser_avatar;
                                        contact.SeenMessageOrNo = ChatUser_lastseen;
                                        contact.LastMessageDateTime = ChatUser_lastseen_Time_Text;
                                        contact.Username = Username;
                                        contact.Platform = UserPlatform;

                                        datas.UpdateContactUsers(contact);


                                    }

                                }
                                #endregion

                                #region Add contact if dont exits

                                else
                                {
                                    datas.InsertContactUsers(new ContactsTableDB()
                                    {
                                        UserID = ChatUser_User_ID,
                                        Name = ChatUser_name,
                                        ProfilePicture = ChatUser_avatar,
                                        SeenMessageOrNo = ChatUser_lastseen,
                                        LastMessageDateTime = ChatUser_lastseen_Time_Text,
                                        Username = Username,
                                        Platform = UserPlatform
                                    });

                                }

                                #endregion

                            }

                            #endregion
                        }


                        foreach (var Offline in Chatusers)
                        {
                            JObject ChatlistUserdata = JObject.FromObject(Offline);
                            var ChatUser_User_ID = ChatlistUserdata["user_id"].ToString();
                            var ChatUser_avatar = ChatlistUserdata["profile_picture"].ToString();
                            var ChatUser_name = ChatlistUserdata["name"].ToString();
                            var Username = ChatlistUserdata["username"].ToString();
                            var ChatUser_lastseen = ChatlistUserdata["lastseen"].ToString();
                            var ChatUser_lastseen_Time_Text = ChatlistUserdata["lastseen_time_text"].ToString();
                            var ChatUser_verified = ChatlistUserdata["verified"].ToString();
                            var UserPlatform = ChatlistUserdata["user_platform"].ToString();
                            Aftercontact = ChatUser_User_ID;


                            if (UserPlatform == "phone")
                            {
                                UserPlatform = AppResources.Label_Mobile;
                            }
                            if (UserPlatform == "web")
                            {
                                UserPlatform = AppResources.Label_Web;
                            }
                            if (UserPlatform == "windows")
                            {
                                UserPlatform = AppResources.Label_Desktop;
                            }


                            #region Saving image

                            var ImageMediaFile =
                                ImageSource.FromFile(DependencyService.Get<IPicture>()
                                    .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID));
                            if (DependencyService.Get<IPicture>().GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID) == "File Dont Exists")
                            {
                                ImageMediaFile = new UriImageSource { Uri = new Uri(ChatUser_avatar) };

                                ImageMediaFile = new UriImageSource
                                {
                                    Uri = new Uri(ChatUser_avatar),
                                    CachingEnabled = true,
                                    CacheValidity = new TimeSpan(5, 0, 0, 0)
                                };
                                DependencyService.Get<IPicture>().SavePictureToDisk(ChatUser_avatar, ChatUser_User_ID);
                            }

                            #endregion


                            #region Data Adding


                            ChatContactsList.Add(new UserContacts()
                                {
                                    Username = Username,
                                    Name = ChatUser_name,
                                    SeenMessageOrNo = ChatUser_lastseen,
                                    profile_picture = ImageMediaFile,
                                    LastMessageDateTime = AppResources.Label_LastSeen + " " + ChatUser_lastseen_Time_Text,
                                    UserID = ChatUser_User_ID,
                                    Platform = UserPlatform,
                                    Checkicon = "\uf1db",
                                    CheckiconColor = Settings.MainColor
                            });

                           
                           
                            #region adding to Sqlite table  

                            using (var datas = new ContactsFunctions())
                            {
                                var contact = datas.GetContactUser(ChatUser_User_ID);

                                #region Update contact information

                                if (contact != null)
                                {
                                    if (contact.UserID == ChatUser_User_ID &&
                                        ((contact.Name != ChatUser_name) || (contact.ProfilePicture != ChatUser_avatar) ||
                                         (contact.Username != Username) ||
                                         (contact.LastMessageDateTime != ChatUser_lastseen_Time_Text) ||
                                         (contact.Platform != UserPlatform)))
                                    {
                                        if ((contact.ProfilePicture != ChatUser_avatar))
                                        {
                                            datas.DeleteContactRow(contact);
                                            DependencyService.Get<IPicture>()
                                                .DeletePictureFromDisk(contact.ProfilePicture, ChatUser_User_ID);
                                            datas.InsertContactUsers(new ContactsTableDB()
                                            {
                                                UserID = ChatUser_User_ID,
                                                Name = ChatUser_name,
                                                ProfilePicture = ChatUser_avatar,
                                                SeenMessageOrNo = ChatUser_lastseen,
                                                LastMessageDateTime = ChatUser_lastseen_Time_Text,
                                                Username = Username,
                                                Platform = UserPlatform
                                            });
                                        }

                                        contact.UserID = ChatUser_User_ID;
                                        contact.Name = ChatUser_name;
                                        contact.ProfilePicture = ChatUser_avatar;
                                        contact.SeenMessageOrNo = ChatUser_lastseen;
                                        contact.LastMessageDateTime = ChatUser_lastseen_Time_Text;
                                        contact.Username = Username;
                                        contact.Platform = UserPlatform;

                                        datas.UpdateContactUsers(contact);


                                    }

                                }
                                #endregion
                               
                                #region Add contact if dont exits

                                else
                                {
                                    datas.InsertContactUsers(new ContactsTableDB()
                                    {
                                        UserID = ChatUser_User_ID,
                                        Name = ChatUser_name,
                                        ProfilePicture = ChatUser_avatar,
                                        SeenMessageOrNo = ChatUser_lastseen,
                                        LastMessageDateTime = ChatUser_lastseen_Time_Text,
                                        Username = Username,
                                        Platform = UserPlatform
                                    });

                                }

                                #endregion

                            }

                            #endregion

                            #endregion



                        }

                    }
                    else if (apiStatus == "400")
                    {
                        ChatContactsList.Add(new UserContacts()
                        {
                            Username = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble,

                            Name = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble

                        });
                        json = AppResources.Label_Error;
                    }
                    UserDialogs.Instance.HideLoading();
                    return json;

                }
            }
            catch (Exception)
            {
                return AppResources.Label_Error;
            }

        }

        public static async Task<string> GetLoginUserProfile(string userid, string session)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("user_profile_id", userid),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_user_data",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        JObject userdata = JObject.FromObject(data["user_data"]);
                        //Settings.UserFullName = userdata["name"].ToString();

                        var avatar = userdata["avatar"].ToString();
                        var cover = userdata["cover"].ToString();
                        var First_name = userdata["first_name"].ToString();
                        var Last_name = userdata["last_name"].ToString();
                        var About = userdata["about"].ToString();
                        var Website = userdata["website"].ToString();
                        var School = userdata["school"].ToString();
                        var name = userdata["name"].ToString();
                        var username = userdata["username"].ToString();
                        var gender = userdata["gender"].ToString();
                        var birthday = userdata["birthday"].ToString();
                        var email = userdata["email"].ToString();
                        var address = userdata["address"].ToString();
                        var user_id = userdata["user_id"].ToString();
                        var url = userdata["url"].ToString();

                        About = WebUtility.HtmlDecode(About);
                        address = WebUtility.HtmlDecode(address);

                        var Imagecover = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(cover, user_id));
                       
                        if (DependencyService.Get<IPicture>().GetPictureFromDisk(cover, user_id) == "File Dont Exists")
                        {
                            Imagecover = new UriImageSource
                            {
                                Uri = new Uri(cover)
                            };

                            Settings.Avatarimage = cover;
                           DependencyService.Get<IPicture>().SavePictureToDisk(cover, user_id);
                        }

                        var Imageavatar =
                            ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id));
                        if (DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id) == "File Dont Exists")
                        {
                            Imageavatar = new UriImageSource
                            {
                                Uri = new Uri(avatar)
                            };

                            Settings.Coverimage = avatar;
                            DependencyService.Get<IPicture>().SavePictureToDisk(avatar, user_id);
                        }

                        using (var Datas = new LoginUserProfileFunctions())
                        {
                            var contact = Datas.GetProfileCredentialsById(user_id);
                            if (contact != null)
                            {
                                if (contact.UserID == user_id &&
                                    ((contact.Cover != cover) || (contact.Avatar != avatar) ||
                                     (contact.Birthday != birthday) || (contact.name != name)
                                     || (contact.Username != username) || (contact.First_name != First_name) ||
                                     (contact.Last_name != Last_name) || (contact.About != About) ||
                                     (contact.Website != Website)
                                     || (contact.School != School)))
                                {
                                    //Datas.DeleteProfileRow(contact);
                                    if ((contact.Avatar != avatar))
                                    {
                                        DependencyService.Get<IPicture>().DeletePictureFromDisk(contact.Avatar, user_id);
                                    }
                                    if ((contact.Cover != cover))
                                    {
                                        DependencyService.Get<IPicture>().DeletePictureFromDisk(contact.Cover, user_id);
                                    }

                                    contact.UserID = user_id;
                                    contact.name = name;
                                    contact.Avatar = avatar;
                                    contact.Cover = cover;
                                    contact.Birthday = birthday;
                                    contact.Address = address;
                                    contact.Gender = gender;
                                    contact.Email = email;
                                    contact.Username = username;
                                    contact.First_name = First_name;
                                    contact.Last_name = Last_name;
                                    contact.About = About;
                                    contact.Website = Website;
                                    contact.School = School;

                                    Datas.UpdateProfileCredentials(contact);

                                }
                            }
                            else
                            {
                                Datas.InsertProfileCredentials(new LoginUserProfileTableDB()
                                {
                                    UserID = user_id,
                                    name = name,
                                    Avatar = avatar,
                                    Cover = cover,
                                    Birthday = birthday,
                                    Address = address,
                                    Gender = gender,
                                    Email = email,
                                    Username = username,
                                    First_name = First_name,
                                    Last_name = Last_name,
                                    About = About,
                                    Website = Website,
                                    School = School
                                });

                            }

                        }
                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }
                    return json;
                }
            }
            catch (Exception)
            {

                return AppResources.Label_Error;
            }

        }

        public static async Task SyncContactsFromPhone()
        {
            try
            {

                var Dictionary = new Dictionary<string, string>();
                try
                {

                    if (await CrossContacts.Current.RequestPermission())
                    {
                        CrossContacts.Current.PreferContactAggregation = false;
                        await Task.Run(() =>
                        {
                            if (CrossContacts.Current.Contacts == null)
                                return;
                            var max = 0;
                            foreach (Contact contact in CrossContacts.Current.Contacts)
                            {
                                max += 1;
                                if (max == Settings.LimitContactGetFromPhone)
                                {
                                    continue;
                                }
                                foreach (var Number in contact.Phones)
                                {
                                    if (!Dictionary.ContainsKey(contact.FirstName + ' ' + contact.LastName))
                                    {
                                        Dictionary.Add(contact.FirstName + ' ' + contact.LastName, Number.Number);
                                    }
                                    break;
                                }
                            }
                        });
                    }

                }
                catch
                {
                }
                string Data = JsonConvert.SerializeObject(Dictionary.ToArray());

                UserDialogs.Instance.Toast("Loading from your phone contacts");

                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("contacts", Data),
                    new KeyValuePair<string, string>("s", Settings.Session)
                });

                    

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_suggestions",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    string ThemeUrl = data["theme_url"].ToString();

                    if (apiStatus == "200")
                    {
                        SearchFilterlist.Clear();
                        var users_sugParse = JObject.Parse(json).SelectToken("users_sug").ToString();
                        JArray Chatusers_sug = JArray.Parse(users_sugParse);

                        if (Chatusers_sug.Count > 0)
                        {
                            foreach (var userssug in Chatusers_sug)
                            {
                                JObject ChatlistUserdata = JObject.FromObject(userssug);
                                var ChatUser_User_ID = ChatlistUserdata["user_id"].ToString();
                                var ChatUser_avatar = ChatlistUserdata["profile_picture"].ToString();
                                var ChatUser_name = ChatlistUserdata["name"].ToString();
                                var ChatUser_lastseen = ChatlistUserdata["lastseen"].ToString();
                                var ChatUser_lastseen_Time_Text = ChatlistUserdata["lastseen_time_text"].ToString();
                                var ChatUser_verified = ChatlistUserdata["verified"].ToString();

                                #region Images

                                var ImageMediaFile =
                                    ImageSource.FromFile(DependencyService.Get<IPicture>()
                                        .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID));
                                if (
                                    DependencyService.Get<IPicture>()
                                        .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID) == "File Dont Exists")
                                {
                                    ImageMediaFile = new UriImageSource
                                    {
                                        Uri = new Uri(ChatUser_avatar)
                                    };
                                    //DependencyService.Get<IPicture>().SavePictureToDisk(ChatUser_avatar, ChatUser_User_ID);
                                }

                                var OnlineOfflineIcon = ImageSource.FromFile("");
                               

                                #endregion

                                var status = AppResources.Label_AddFriend;
                                if (Settings.ConnectivitySystem == "1")
                                {
                                    status = AppResources.Label_Follow;
                                }

                                if (ChatUser_lastseen == "on")
                                {

                                    SearchFilterlist.Add(new SearchResult()
                                    {
                                        BigLabel = ChatUser_name,
                                        lastseen = OnlineOfflineIcon,
                                        Name = ChatUser_name,
                                        SeenMessageOrNo = ChatUser_lastseen,
                                        profile_picture = ImageMediaFile,
                                        MiniLabel = AppResources.Label_Online,
                                        //verified = ChatUser_verified_bitmap,
                                        ResultID = ChatUser_User_ID,
                                        connectivitySystem = status,
                                        ResultType = "Users",
                                        ButtonColor = Settings.ButtonColorNormal,
                                        ButtonTextColor = Settings.ButtonTextColorNormal,
                                        ButtonImage = Settings.Add_Icon,
                                        ResultButtonAvailble = "true"

                                    });

                                }
                                else
                                {
                                    SearchFilterlist.Add(new SearchResult()
                                    {
                                        BigLabel = ChatUser_name,
                                        lastseen = OnlineOfflineIcon,
                                        Name = ChatUser_name,
                                        SeenMessageOrNo = ChatUser_lastseen,
                                        profile_picture = ImageMediaFile,
                                        MiniLabel = AppResources.Label_LastSeen + " " + ChatUser_lastseen_Time_Text,
                                        //verified = ChatUser_verified_bitmap,
                                        ResultID = ChatUser_User_ID,
                                        connectivitySystem = status,
                                        ResultType = "Users",
                                        ButtonColor = Settings.ButtonColorNormal,
                                        ButtonTextColor = Settings.ButtonTextColorNormal,
                                        ButtonImage = Settings.Add_Icon,
                                        ResultButtonAvailble = "true"
                                    });

                                }
                            }
                        }

                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }

                    if (SearchFilterlist.Count == 0)
                    {
                        SearchFilterlist.Add(new SearchResult()
                        {
                            BigLabel = "  " + AppResources.FN_NoContactPhoneAreAvailble,
                            Name = "  " + AppResources.FN_NoContactPhoneAreAvailble,
                            ButtonColor = Settings.ButtonColorNormal,
                            ButtonTextColor = Settings.ButtonTextColorNormal,
                            ButtonImage = Settings.Add_Icon,
                            ResultButtonAvailble = "false"
                        });
                    }
                }
            }
            catch
            {
            }
            
        }

        public static async Task<string> GetRandomUsers()
        {

            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("s", Settings.Session)
                });
                    UserDialogs.Instance.Toast("Loading Random Users");
                    var response =await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_suggestions",  formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    string ThemeUrl = data["theme_url"].ToString();

                    if (apiStatus == "200")
                    {
                        SearchFilterlist.Clear();
                        var users = JObject.Parse(json).SelectToken("users_random").ToString();
                        JArray Chatusers = JArray.Parse(users);

                        foreach (var ChatUser in Chatusers)
                        {
                            JObject ChatlistUserdata = JObject.FromObject(ChatUser);
                            var ChatUser_User_ID = ChatlistUserdata["user_id"].ToString();
                            var ChatUser_avatar = ChatlistUserdata["profile_picture"].ToString();
                            var ChatUser_name = ChatlistUserdata["name"].ToString();
                            var ChatUser_lastseen = ChatlistUserdata["lastseen"].ToString();
                            var ChatUser_lastseen_Time_Text = ChatlistUserdata["lastseen_time_text"].ToString();
                            var ChatUser_verified = ChatlistUserdata["verified"].ToString();


                            var ImageMediaFile =
                                ImageSource.FromFile(
                                    DependencyService.Get<IPicture>()
                                        .GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID));
                            if (
                                DependencyService.Get<IPicture>().GetPictureFromDisk(ChatUser_avatar, ChatUser_User_ID) ==
                                "File Dont Exists")
                            {
                                ImageMediaFile = new UriImageSource
                                {
                                    Uri = new Uri(ChatUser_avatar)
                                };
                                //DependencyService.Get<IPicture>().SavePictureToDisk(ChatUser_avatar, ChatUser_User_ID);
                            }

                            var OnlineOfflineIcon = ImageSource.FromFile("");
                            


                            #region Data Adding

                            var status = AppResources.Label_AddFriend;
                            if (Settings.ConnectivitySystem == "1")
                            {
                                status = AppResources.Label_Follow;
                            }

                            if (ChatUser_lastseen == "on")
                            {
                                 SearchFilterlist.Add(new SearchResult()
                                {
                                    BigLabel = ChatUser_name,
                                    ResultType="Users",
                                    lastseen = OnlineOfflineIcon,
                                    Name = ChatUser_name,
                                    SeenMessageOrNo = ChatUser_lastseen,
                                    profile_picture = ImageMediaFile,
                                    MiniLabel = AppResources.Label_Online,
                                    //verified = ChatUser_verified_bitmap,
                                    ResultID = ChatUser_User_ID,
                                    connectivitySystem = status,
                                    ButtonColor = Settings.ButtonColorNormal,
                                    ButtonTextColor = Settings.ButtonTextColorNormal,
                                    ButtonImage = Settings.Add_Icon,
                                    ResultButtonAvailble = "true"
                                });

                            }
                            else
                            {
                                   SearchFilterlist.Add(new SearchResult()
                                {
                                    BigLabel = ChatUser_name,
                                    lastseen = OnlineOfflineIcon,
                                    Name = ChatUser_name,
                                    ResultType = "Users",
                                    SeenMessageOrNo = ChatUser_lastseen,
                                    profile_picture = ImageMediaFile,
                                    MiniLabel = AppResources.Label_LastSeen + " " + ChatUser_lastseen_Time_Text,
                                    //verified = ChatUser_verified_bitmap,
                                    ResultID = ChatUser_User_ID,
                                    connectivitySystem = status,
                                    ButtonColor = Settings.ButtonColorNormal,
                                    ButtonTextColor = Settings.ButtonTextColorNormal,
                                    ButtonImage = Settings.Add_Icon,
                                    ResultButtonAvailble = "true"
                                });

                            }


                            #endregion
                        }

                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }

                   

                    if (SearchFilterlist.Count == 0)
                    {
                          SearchFilterlist.Add(new SearchResult()
                        {
                            BigLabel = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble,
                            Name = "  " + "  " + "  " + AppResources.FN_NoUsersAreAvailble,
                            ButtonColor = Settings.ButtonColorNormal,
                            ButtonTextColor = Settings.ButtonTextColorNormal,
                            ButtonImage = Settings.Add_Icon,
                            ResultType = "Users",
                            ResultButtonAvailble = "false"
                        });
                    }

                    return json;

                }
            }
            catch
            {
                return AppResources.Label_Error;
            }
        }

      

        public static string IsUrlValid(string url)
        {
            try
            {
                string pattern =
                    @"^(http|https|ftp|)\://|[a-zA-Z0-9\-\.]+\.[a-zA-Z](:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&amp;%\$#\=~])*[^\.\,\)\(\s]$";
                Regex reg = new Regex(pattern, RegexOptions.ExplicitCapture | RegexOptions.IgnoreCase);
                Match m = reg.Match(url);
                while (m.Success)
                {
                    //do things with your matching text 
                    m = m.NextMatch();
                    break;
                }
                if (reg.IsMatch(url))
                {
                    return "http://" + m.Value;
                }
                else
                {
                    return "";
                }
            }
            catch (Exception)
            {
                return "";
            }

        }

      

       
      
        public static int ListInfoResizer(string About)
        {

            if (About.Length <= 40)
            {
                return 150;
            }
            else if (About.Length <= 90)
            {
                return 165;
            }
            else if (About.Length <= 130)
            {
                return 175;
            }
            else if (About.Length <= 175)
            {
                return 185;
            }
            else if (About.Length <= 205)
            {
                return 195;
            }
            else if (About.Length <= 250)
            {
                return 205;
            }
            else if (About.Length <= 290)
            {
                return 215;
            }
            else if (About.Length <= 335)
            {
                return 225;
            }
            else if (About.Length <= 350)
            {
                return 235;
            }
            else if (About.Length <= 375)
            {
                return 243;
            }
            else if (About.Length <= 390)
            {
                return 247;
            }
            else if (About.Length <= 405)
            {
                return 259;
            }
            else if (About.Length <= 445)
            {
                return 275;
            }
            else if (About.Length <= 485)
            {
                return 292;
            }
            else if (About.Length <= 525)
            {
                return 308;
            }
            else if (About.Length <= 555)
            {
                return 315;
            }
            else if (About.Length <= 570)
            {
                return 320;
            }
            else if (About.Length <= 590)
            {
                return 330;
            }
            else if (About.Length <= 610)
            {
                return 345;
            }
            else if (About.Length <= 650)
            {
                return 360;
            }
            else if (About.Length <= 685)
            {
                return 380;
            }
            else if (About.Length <= 695)
            {
                return 395;
            }
            else if (About.Length <= 711)
            {
                return 410;
            }
            else if (About.Length <= 735)
            {
                return 420;
            }
            else
            {
                return 0;
            }
        }

        public static string DecodeString(string Content)
        {
            var Decoded = System.Net.WebUtility.HtmlDecode(Content);
            var Stringformater = Decoded.Replace(":)", "\ud83d\ude0a")
                .Replace(";)", "\ud83d\ude09")
                .Replace("0)", "\ud83d\ude07")
                .Replace("(<", "\ud83d\ude02")
                .Replace(":D", "\ud83d\ude01")
                .Replace("*_*", "\ud83d\ude0d")
                .Replace("(<", "\ud83d\ude02")
                .Replace("<3", "\ud83d\u2764")
                .Replace("/_)", "\ud83d\ude0f")
                .Replace("-_-", "\ud83d\ude11")
                .Replace(":-/", "\ud83d\ude15")
                .Replace(":*", "\ud83d\ude18")
                .Replace(":_p", "\ud83d\ude1b")
                .Replace(":p", "\ud83d\ude1c")
                .Replace("x(", "\ud83d\ude20")
                .Replace("X(", "\ud83d\ude21")
                .Replace(":_(", "\ud83d\ude22")
                .Replace("<5", "\ud83d\u2B50")
                .Replace(":0", "\ud83d\ude31")
                .Replace("B)", "\ud83d\ude0e")
                .Replace("o(", "\ud83d\ude27")
                .Replace("</3", "\uD83D\uDC94")
                .Replace(":o", "\ud83d\ude26")
                .Replace("o(", "\ud83d\ude27")
                .Replace(":__(", "\ud83d\ude2d")
                .Replace("!_", "\uD83D\u2757")
                .Replace("<br> <br>", " ").Replace("<br>", " ");

            return Stringformater;
        }

      

    }
}
