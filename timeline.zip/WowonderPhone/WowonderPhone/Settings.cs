﻿
//WOWONDER Timeline v1.2
//Copyright: DoughouzLight
//Email: alidoughous1993@gmail.com
//Full Documentation on same zip file 
//==============================
using PropertyChanged;
using WowonderPhone.Languish;
using Xamarin.Forms;

namespace WowonderPhone
{
    //1-Add Your logo From Solution Explorer go to WowonderPhone.Android > Resources > Remove logo.png 
    //2-Right click on Resources folder > Add > Existing Item > pick your own logo.png
    //Same thing for all images and icons

    [ImplementPropertyChanged]
    public class Settings
    {

        /// ##########################################################
     
        public static string Website = "https://demo.wowonder.com/";

        public static string API_ID = "144235f5702cb70fa6c3f48842738e35";
        public static string API_KEY = "b37bb1cd53d0bc21c13c1644e98a58ca";

        public static string APP_Name = "Wowownder";
        public static string Version = "1.0";

        public static string ConnectivitySystem = "1";

        /// ##########################################################

        //Main Style
        public static string MainColor = "#a84849";
        public static string MainPage_HeaderTextLabel = APP_Name;
        public static string MainPage_HeaderBackround_Color = "#a84849";
        public static string MainPage_HeaderText_Color = "#ffff";

        //Button Colors
        public static string ButtonColorNormal = "#a54647";
        public static string ButtonTextColorNormal = "#fff";
        public static string ButtonLightColor = "#E7E7E7";
        public static string ButtonTextLightColor = "#444";
        public static string UnseenMesageColor = "#ededed";

        //Background Images
        public static string Background_Image_WelcomePage = "welcome_bg.jpg";
        public static string Background_Image_RegisterPage = "aa2.png";
        public static string Background_Image_LoginPage = "aa2.png";
        public static string Logo_Image_WelcomePage = "logo.png";
        public static string Logo_Image_LoginPage = "logo.png";

        //Social Logins
        ///*********************************************************
        public static bool Show_Facebook_Login = true;
        public static bool Show_Google_Login = true;
        public static bool Show_Vkontakte_Login = false;
        public static bool Show_Instagram_Login = false;
        public static bool Show_Twitter_Login = true;

        //Main Messenger settings
        public static bool Messenger_Integration = true;
        public static string Messenger_Package_Name = "com.facebook.orca"; //APK name on Google Play

        //Main Slider settings
        ///*********************************************************
        public static bool Show_Articles = true;
        public static bool Show_Market = true;
        public static bool Show_Pro_Members = true;
        public static bool Show_Promoted_Pages = true;
        public static bool Show_Trending_Hashtags = true;
        public static bool Show_Block_On_User_Profiles = true;

        //Main Refresh Posts & Notifications Time
        ///*********************************************************
        public static int  Notifications_Push_Secounds = 25;
        public static int  LoadMore_Post_Secounds = 160;

        //Android Display
        ///*********************************************************
        public static bool TurnFullScreenOn = false;

        //Bypass Web Erros
        ///*********************************************************
        public static bool TurnTrustFailureOn_WebException = false;
        public static bool TurnSecurityProtocolType3072On = false;
        ///*********************************************************
      
        //Main Icons
        public static string Like_Icon = "Like_Icon.png";
        public static string Add_Icon = "Plus.png"; 
        public static string CheckMark_Icon = "Checkmark.png";
        public static string Post_Picture_Icon = "PostPicture.png";
        public static string Post_Video_Icon = "PostVideo.png";
        public static string Post_Feeling_Icon = "PostFeeling.png";
        public static string Post_Tags_Icon = "PostTags.png";
        public static string Likecheked_Icon = "P_Checked.png";
        public static string LikePage_Icon = "P_Like.png";
        public static string AddUser_Icon = "P_AddUser.png";
        public static string BlockedUser_Icon = "P_Blocked.png";
        public static string BlockUser_Icon = "P_BlockUser.png";
        public static string Requested_Icon = "P_ Requested.png";

        //User Synic Limit
        ///*********************************************************
        public static int LimitContactGetFromPhone = 300;


        ///*********************************************************
        public static HtmlWebViewSource HTML_LoadingPost_Page = new HtmlWebViewSource
        {
            Html = "<html ><body bgcolor='#E9E9E9'>" +
                  "<img src='Smallloader.gif' style='width:380;height:200'/>" +
                  "<br><img src='Smallloader.gif' style='width:380;height:200'/>" +
                  "<br><img src='Smallloader.gif' style='width:380;height:200'/>" +
                  "</body></html>"
        };

        public static HtmlWebViewSource HTML_OfflinePost_Page = new HtmlWebViewSource
        {
            Html = "<html ><body>" +
                  "</br></br><img src='no_internet.png' style='width:100%;height:40%'/></br>" +
                  "</body></html>"
        };


        public static HtmlWebViewSource GIF_ProUpgrade = new HtmlWebViewSource
        {
            Html = "<html ><body bgcolor='#4659DF'>" +
                   "<img src='material_icons_animation.gif' style='width:350;height:260'/></br>" +
                   "</body></html>"
        };

        //############# DONT'T MODIFY HERE #############
        //Auto Session bindable objects 

        public static string Session { get; set; }
        public static string Cookie { get; set; }
        public static string User_id { get; set; }
        public static string ProfilePicture { get; set; }
        public static string Username { get; set; }
        public static string UserFullName { get; set; }
        public static ImageSource Coverimage { get; set; }
        public static ImageSource Avatarimage { get; set; }
        public static string SearchByGenderValue { get; set; }
        public static string SearchByProfilePictureValue { get; set; }
        public static string SearchByStatusValue { get; set; }
        public static bool ReLogin { get; set; } = false;
        public static bool NotificationVibrate { get; set; } = true;
        public static bool NotificationSound { get; set; } = true;
        public static bool NotificationPopup { get; set; } = true;
        public static string NotificationLedColor { get; set; } = MainColor;
        public static string NotificationLedColorName { get; set; } = "Default";
        public static string Label_Whats_Going_On = AppResources.Label_Whats_Going_On;
        public static string Label_Default = AppResources.Label_Default;
        public static string PR_AboutDefault = "-------------";
        //##############################################
    }
}
