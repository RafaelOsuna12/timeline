﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
//using Acr.UserDialogs;
using WowonderPhone.Controls;
using WowonderPhone.Languish;
using WowonderPhone.Pages;
using WowonderPhone.Pages.Register_pages;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        async void OnLoginClicked(object sender, EventArgs e)
        {
            try
            {
            var answer = await DisplayAlert(AppResources.Label_Security, AppResources.Label_WouldYouLikeToSaveYourPassword, AppResources.Label_Yes, AppResources.Label_NO);
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (xx == true)
            {
                await DisplayAlert(AppResources.Label_Error, AppResources.Label_CheckYourInternetConnection, AppResources.Label_OK);
            }
            else
            {
                var StatusApiKey = "";
                using (var client = new HttpClient())
                {

                    Settings.Session = RandomString(70);
                    LoadingPanel.IsVisible = true;

                    var SettingsValues = new FormUrlEncodedContent(new[]
                       { new KeyValuePair<string,string>("windows_app_version",Settings.Version),

                       });

                    var responseSettings = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_settings", SettingsValues);
                    responseSettings.EnsureSuccessStatusCode();
                    string jsonSettings = await responseSettings.Content.ReadAsStringAsync();
                    var dataSettings = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonSettings);
                    string apiStatusSettings = dataSettings["api_status"].ToString();
                    if (apiStatusSettings == "200")
                    {
                        JObject settings = JObject.FromObject(dataSettings["config"]);

                        if (Settings.API_ID == settings["widnows_app_api_id"].ToString() &&
                            Settings.API_KEY == settings["widnows_app_api_key"].ToString())
                        {
                            StatusApiKey = "true";
                        }
                        else
                        {
                            StatusApiKey = "false";
                        }
                        if (settings["footer_background_n"].ToString() != "#aaa")
                        {
                            await DisplayAlert("Security", settings["error_android_text"].ToString(), "Yes", "No");
                            LoadingPanel.IsVisible = false;
                            return;
                        }
                    }
                    if (StatusApiKey == "true")
                    {

                        var TimeZoneContry = "UTC";
                        try
                        {
                            var formContenst = new FormUrlEncodedContent(new[]
                                {new KeyValuePair<string, string>("username", usernameEntry.Text),});

                            var responseTime = await client.PostAsync("http://ip-api.com/json/", formContenst);
                            string jsonres = await responseTime.Content.ReadAsStringAsync();

                            var datares = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonres);

                            string ResulttimeZone = datares["status"].ToString();
                            if (ResulttimeZone == "success")
                                TimeZoneContry = datares["timezone"].ToString();
                        }
                        catch (Exception)
                        {

                        }

                        var formContent = new FormUrlEncodedContent(new[]
                        {
                                new KeyValuePair<string, string>("username", usernameEntry.Text),
                                new KeyValuePair<string, string>("password", passwordEntry.Text),
                                new KeyValuePair<string, string>("timezone", TimeZoneContry),
                                new KeyValuePair<string, string>("s", Settings.Session)
                            });

                        var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=user_login&cookie=1", formContent);
                        response.EnsureSuccessStatusCode();
                        string json = await response.Content.ReadAsStringAsync();
                        var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                        string apiStatus = data["api_status"].ToString();


                        if (apiStatus == "200")
                        {
                            Settings.Cookie = data["cookie"].ToString();
                            Settings.User_id = data["user_id"].ToString();

                            await LoginUserFunctions.GetSessionProfileData(Settings.User_id, Settings.Session);

                            if (answer)
                            {
                                using (var datas = new LoginFunctions())
                                {
                                    LoginTableDB LoginData = new LoginTableDB();
                                    LoginData.ID = 1;
                                    LoginData.Password = passwordEntry.Text;
                                    LoginData.Username = usernameEntry.Text;
                                    LoginData.Session = Settings.Session;
                                    LoginData.UserID = Settings.User_id;
                                    LoginData.Status = "Active";
                                    LoginData.Cookie = Settings.Cookie;
                                    LoginData.PrivacyPostValue = "0";
                  
                                   
                                    datas.InsertLoginCredentials(LoginData);
                                }
                                LoadingPanel.IsVisible = false;
                            }
                            try
                            {
                                if (Settings.ReLogin)
                                {
                                    await Navigation.PopAsync();
                                    await Navigation.PushModalAsync(new WalkThrough_Page1());
                                }
                                else
                                {
                                    await Navigation.PushModalAsync(new WalkThrough_Page1());
                                    LoadingPanel.IsVisible = false;
                                }

                            }
                            catch
                            {
                                await Navigation.PopModalAsync();
                            }

                        }
                        else if (apiStatus == "400")
                        {
                            JObject errors = JObject.FromObject(data["errors"]);
                            var errortext = errors["error_text"].ToString();
                            var ErrorMSG = await DisplayAlert(AppResources.Label_Security, errortext, AppResources.Label_Retry, AppResources.Label_Forget_My_Password);
                            if (ErrorMSG == false)
                            {
                                // var URI = new Uri(Settings.Website + "/forgot-password");
                                await Navigation.PushAsync(new ForgetPasswordpage());
                            }
                            LoadingPanel.IsVisible = false;
                        }
                    }
                    else
                    {
                        await DisplayAlert("Security", "APIKEY And APIID are incorrect ", "Yes");
                        LoadingPanel.IsVisible = false;
                    }
                }
            }
            }
            catch (Exception exception)
            {
                await DisplayAlert("Security", exception.ToString(), "Yes");
               
            }
        }
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();
            if (Settings.ReLogin)
            {
                return true;
            }
            return false;
        }
        private static Random random = new Random();

        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXdsdaawerthklmnbvcxer46gfdsYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        public static String GetTimestamp(DateTime value)
        {
            return value.ToString("yyyyMMddHHmmssffff");
        }

        public static bool IsPageInNavigationStack<TPage>(INavigation navigation) where TPage : Page
        {
            if (navigation.NavigationStack.Count > 1)
            {
                var last = navigation.NavigationStack[navigation.NavigationStack.Count - 2];

                if (last is TPage)
                {
                    return true;
                }
            }
            return false;
        }

        private async void LoginsocialButton_OnClicked(object sender, EventArgs e)
        {
            var socials = "";

            if (Settings.Show_Facebook_Login == true)
            {
                socials += "Facebook,";
            }
            if (Settings.Show_Google_Login == true)
            {
                socials += "Google,";
            }
            if (Settings.Show_Twitter_Login == true)
            {
                socials += "Twitter,";
            }
            if (Settings.Show_Vkontakte_Login == true)
            {
                socials += "Vkontakte,";
            }
            if (Settings.Show_Instagram_Login == true)
            {
                socials += "Instagram";
            }

            var socialsArray = socials.Split(',');

            var Actionclick = await DisplayActionSheet(AppResources.Label_Login_with , AppResources.Label_Cancel, null, socialsArray);

            #region Login Clicks
            if (Actionclick == "Facebook")
            {
                try
                {
                   await Navigation.PushAsync(new FacebookView());
                }
                catch
                {
                    await Navigation.PushModalAsync(new FacebookView());
                }
            }
            else if (Actionclick == "Google")
            {
                try
                {
                    await Navigation.PushAsync(new GoogleView());
                }
                catch
                {
                    await Navigation.PushModalAsync(new GoogleView());
                }
            }
            else if (Actionclick == "Twitter")
            {
                try
                {
                    await Navigation.PushAsync(new TwitterView());
                }
                catch
                {
                    await Navigation.PushModalAsync(new TwitterView());
                }
            }
            else if (Actionclick == "Vkontakte")
            {
                try
                {
                    await Navigation.PushAsync(new VkontakteView());
                }
                catch
                {
                    await Navigation.PushModalAsync(new VkontakteView());
                }
            }

            else if (Actionclick== "Instagram")
            {
                try
                {
                    await Navigation.PushAsync(new InstegramView());
                }
                catch
                {
                    await Navigation.PushModalAsync(new InstegramView());
                }
            }

          #endregion 
        }

    }
}
