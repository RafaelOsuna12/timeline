﻿using SQLite.Net;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Classes;
using WowonderPhone.Controls;
using WowonderPhone.Dependencies;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;

namespace WowonderPhone.SQLite
{
    class ChatActivityFunctions : IDisposable
    {
        private SQLiteConnection Connection;
        public void Dispose()
        {
            Connection.Dispose();
        }
        public ChatActivityFunctions()
        {
            var config = DependencyService.Get<SQLiteData>();
            Connection = new SQLiteConnection(config.Platform, Path.Combine(config.DirectoriDB, "ChatActivityDB.db3"));
            Connection.CreateTable<ChatActivityDB>();
        }
        public void InsertChatUsers(ChatActivityDB ChatActivity)
        {
            Connection.Insert(ChatActivity);
        }
        public void InsertChatUsers(List<ChatActivityDB> ChatActivity)
        {
            Connection.Insert(ChatActivity);
        }
        public void UpdateChatUsers(ChatActivityDB ChatActivity)
        {
            Connection.Update(ChatActivity);
        }
        public void DeleteChatUserRow(ChatActivityDB ChatActivity)
        {
            Connection.Delete(ChatActivity);
        }
        public void ClearChatUserTable()
        {
            Connection.DeleteAll<ChatActivityDB>();
        }

        public ChatActivityDB GetChatUser(string ID)
        {
            return Connection.Table<ChatActivityDB>().FirstOrDefault(c => c.UserID == ID);
        }
        public ChatActivityDB GetChatUserByUsername(string Username)
        {
            return Connection.Table<ChatActivityDB>().FirstOrDefault(c => c.Username == Username);
        }
        public ObservableCollection<ChatUsers> GetChatUsersCacheList()
        {
            try
            {
                var CachedChatlist = Functions.ChatList;
                CachedChatlist.Clear();
                //var CacshedChatlist = new ObservableCollection<ChatUsers>();
                foreach (var Item in Connection.Table<ChatActivityDB>().ToList().OrderByDescending(a=>a.TimeLong))

                    if(Item.SeenMessageOrNo == Settings.UnseenMesageColor)
                    {
                        CachedChatlist.Insert(0,new ChatUsers()
                        {
                            Username = Item.Username,
                            profile_picture = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(Item.ProfilePicture, Item.UserID)),
                            TextMessage = Item.TextMessage,
                            LastMessageDateTime = Item.LastMessageDateTime,
                            //verified = ChatUser_verified_bitmap,
                            SeenMessageOrNo = Item.SeenMessageOrNo,
                            ChekeSeen = Item.ChekeSeen,
                            UserID = Item.UserID,
                            lastseen = Item.lastseen

                        });
                    }
                else
                    {
                        CachedChatlist.Add(new ChatUsers()
                        {
                            Username = Item.Username,
                            profile_picture = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(Item.ProfilePicture, Item.UserID)),
                            TextMessage = Item.TextMessage,
                            LastMessageDateTime = Item.LastMessageDateTime,
                            //verified = ChatUser_verified_bitmap,
                            SeenMessageOrNo = Item.SeenMessageOrNo,
                            ChekeSeen = Item.ChekeSeen,
                            UserID = Item.UserID,

                        });
                    }

                   

                return CachedChatlist;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public void DeletAllChatUsersList()
        {
            Connection.DeleteAll<ChatActivityDB>();
            foreach (var Activity in Connection.Table<ChatActivityDB>())
            {
                Connection.Delete(Activity);
            }
        }
    }
}
