﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Plugin.Contacts;
using Plugin.Contacts.Abstractions;
using PropertyChanged;
using WowonderPhone.Classes;
using WowonderPhone.Controls;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Timeline_Pages.Friend_System;
using WowonderPhone.SQLite;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Tabs
{
    [ImplementPropertyChanged]
    public class DetailsViewModel 
    {
        public static bool LoadingImage = true;    
    }

    
    public partial class ContactsTab : ContentPage
    {
       
        public  ContactsTab()
        {
            InitializeComponent();
           
            BindingContext = new DetailsViewModel();
            try
            {
                if (MasterMainSlidePage.FriendRequestsItemsCollection.Count > 0)
                {
                    if (Settings.ConnectivitySystem == "1")
                    {
                        FriendRequestLabel.Text = "( " + MasterMainSlidePage.FriendRequestsItemsCollection.Count + " ) " + AppResources.Label_Follow_Requests;
                    }
                    else
                    {
                        FriendRequestLabel.Text = "( " + MasterMainSlidePage.FriendRequestsItemsCollection.Count + " ) " + AppResources.Label_Friend_Requests;
                    }
                   
                    FriendGridBanner.IsVisible = true;
                }
                else
                {
                    FriendGridBanner.IsVisible = false;
                }
                
                ContactsLoader();
            }
            catch (Exception)
            {

            }
            
        }

        private async void ContactListview_OnRefreshing(object sender, EventArgs e)
        {
            try
            {
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network;
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (xx == false)
                {
                    ContactListview.ItemsSource = null;
                    
                    ContactListview.ItemsSource = Functions.ChatContactsList;
                }
                ContactListview.EndRefresh();
            }
            catch (Exception)
            {
                ContactListview.EndRefresh();
            }
        }

        public async void ContactsLoader()
        {
            try
            {
                UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.None);
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network;
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
              
                    using (var data = new ContactsFunctions())
                    {
                        if (Functions.ChatContactsList.Count > 0)
                        {
                           ContactListview.ItemsSource = Functions.ChatContactsList;
                           UserDialogs.Instance.HideLoading();
                           return;
                        }
                        var GetContactList = data.GetContactCacheList();

                        if (GetContactList.Count > 0)
                        {
                            UserDialogs.Instance.HideLoading();
                            ContactListview.ItemsSource = GetContactList;
                        }
                        else
                        {
                            if (xx == false)
                            {
                            ContactListview.ItemsSource = null;
                            await Functions.GetChatContacts(Settings.User_id, Settings.Session);
                            if (Functions.ChatContactsList.Count > 0)
                            {

                                UserDialogs.Instance.HideLoading();
                                ContactListview.ItemsSource = Functions.ChatContactsList;
                                DetailsViewModel.LoadingImage = false;
                            }
                            else
                            {
                                UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection);
                            }
                        } 
                    }
                       
                }
             
            }
            catch (Exception)
            {

            }
           
        }

        private async void OnDelete(object sender, EventArgs e)
        {
            try
            {
                var mi = ((MenuItem) sender);
                var answer =
                    await DisplayAlert("Delete " + mi.CommandParameter + " from my contact list ?", null, "Yes", "No");
                if (answer)
                {
                    #region Delete from list

                 
             var getuser = Functions.ChatContactsList.Where(a => a.Name == mi.CommandParameter.ToString()).ToList().FirstOrDefault();
                if (getuser != null)
                {
                  if (getuser.Username == mi.CommandParameter.ToString())
                    {
                      Functions.ChatContactsList.Remove(getuser);
                    }
                }
                    #endregion

                    #region Delete from SqlTable (Cashe)

                    using (var data = new ContactsFunctions())
                    {
                        var contact = data.GetContactUserByUsername(mi.CommandParameter.ToString());
                        if (contact != null)
                        {
                          data.DeleteContactRow(contact);
                        }

                        #region Delete from website

                        try
                        {
                            using (var client = new HttpClient())
                            {
                                var formContent = new FormUrlEncodedContent(new[]
                                {
                                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                                    new KeyValuePair<string, string>("recipient_id", contact.UserID),
                                    new KeyValuePair<string, string>("s", Settings.Session)
                                });

                                var response =
                                    await
                                        client.PostAsync(
                                            Settings.Website + "/app_api.php?application=phone&type=follow_user",
                                            formContent).ConfigureAwait(false);
                                response.EnsureSuccessStatusCode();
                                string json = await response.Content.ReadAsStringAsync();
                                var data2 = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                                string apiStatus = data2["api_status"].ToString();
                                if (apiStatus == "200")
                                {

                                }
                            }
                        }
                        catch (Exception)
                        {

                        }
                    }

                    #endregion
                }

                #endregion
              }
            catch (Exception)
            {
                
            }
         }

        private  void ContactListview_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {
                //ContactListview.SelectedItem = null;
                var user = e.Item as UserContacts;
                if (user != null)
                {
                    Navigation.PushAsync(new UserProfilePage(user.UserID, "FriendList"));
                }
               
            }
            catch (Exception)
            {
                
            }
        }

        private void ContactListview_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ContactListview.SelectedItem = null;
        }

        private async void Refresh_OnClicked(object sender, EventArgs e)
        {
            try
            {
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network;
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (xx == false)
                {


                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.None);
                    await Functions.GetChatContacts(Settings.User_id, Settings.Session);

                    Device.BeginInvokeOnMainThread(() =>
                    {

                        ContactListview.ItemsSource = Functions.ChatContactsList;

                    });
                   

                }
                else
                {
                    UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection, 2000);
                }
               
            }
            catch (Exception)
            {
                UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost, 2000);
            }
        }

        private TapGestureRecognizer tapGestureRecognizer = new TapGestureRecognizer();
        private void ContactsTab_OnAppearing(object sender, EventArgs e)
        {
            tapGestureRecognizer.Tapped += OnBannerTapped;
            FriendGridBanner.GestureRecognizers.Add(tapGestureRecognizer);
        }

        private async void OnBannerTapped(Object sender, EventArgs e)
        {
            uint duration = 500;
            var visualElement = (VisualElement)sender;

            await Task.WhenAll(
                visualElement.FadeTo(0, duration / 2, Easing.CubicIn),
                visualElement.ScaleTo(0, duration / 2, Easing.CubicInOut)
            );

            visualElement.HeightRequest = 0;
            await Navigation.PushAsync(new Friend_Request_Page());
        }

        private void ContactsTab_OnDisappearing(object sender, EventArgs e)
        {
            tapGestureRecognizer.Tapped -= OnBannerTapped;
            FriendGridBanner.GestureRecognizers.Remove(tapGestureRecognizer);
            UserDialogs.Instance.HideLoading();
        }
    }
   
}
