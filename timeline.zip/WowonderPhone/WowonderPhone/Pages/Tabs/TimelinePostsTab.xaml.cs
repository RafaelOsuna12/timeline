﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using Newtonsoft.Json;

using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Timeline_Pages;
using WowonderPhone.Pages.Timeline_Pages.DefaultPages;
using WowonderPhone.Pages.Timeline_Pages.Java_Inject_Pages;
using WowonderPhone.SQLite;
using Xam.Plugin.Abstractions;
using Xam.Plugin.Abstractions.Events.Inbound;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;
using Exception = System.Exception;


namespace WowonderPhone.Pages.Tabs
{
    
    public partial class TimelinePostsTab : ContentPage
    {

   

        public string vsde = "";

        public TimelinePostsTab()
        {
            InitializeComponent();
           
            OfflinePost.Source = WowonderPhone.Settings.HTML_LoadingPost_Page;
           
            if (WowonderPhone.Settings.Cookie != null)
            {
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network; // Create Interface to Network-functions
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (!xx)
                {
                    OfflinePost.IsVisible = true;
                    var service = DependencyService.Get<IMethods>();
                    service.ClearWebViewCache();
                    PostWebLoader.Source = WowonderPhone.Settings.Website + "/get_news_feed";
                   
                    

                    Device.StartTimer(TimeSpan.FromSeconds(WowonderPhone.Settings.LoadMore_Post_Secounds), () =>
                    {
                        LoadMoreFunction();
                        return true;
                    });
                   
                }
                else
                {
                    OfflinePost.IsVisible = false;
                    PostWebLoader.IsVisible = false;

                    OfflinePage.IsVisible = true;
                    OfflinePost.Source = WowonderPhone.Settings.HTML_OfflinePost_Page;
                    
                }
            }
        }

     

        public void LoadMoreFunction()
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                   
                  PostWebLoader.InjectJavascript("Wo_GetNewPosts();");
                    
                });

            }

        }

      
        

        public void EditCommentDone(string ID , string Text)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                var JavaCode = "$('#post-' + " + ID + ").find('#edit-post').attr('onclick', '{*type*:*edit_post*,*post_id*:*" + ID + "*,*edit_text*:*" + Text + "*}');";
                //var JavaCode = "$('#post-' + " + ID + ").find('#edit-post').attr('onclick', 'rr');";
                var service = DependencyService.Get<IMethods>();
                service.ClearWebViewCache();
                var Decode = JavaCode.Replace("*", "&quot;");
                PostWebLoader.InjectJavascript(Decode);

                PostWebLoader.InjectJavascript("$('#post-' + " + ID + ").find('.post-description p').html('" + Text + "');");

                  
            });
        }

        public void PostAjaxRefresh(string type)
        {
            if (type == "Hashtag")
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    PostWebLoader.InjectJavascript(" Wo_GetNewHashTagPosts();");
                });
            }
            else
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    PostWebLoader.InjectJavascript("Wo_GetNewPosts();");
                });
               
            }
           
        }
        public void InjectedJavaOpen_UserProfile(string Userid)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new UserProfilePage(Userid, ""));
            });
        }
        public void InjectedJavaOpen_OpenImage(ImageSource Image)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushModalAsync(new ImageFullScreenPage(Image));
            });
        }
        public void InjectedJavaOpen_PostLinks(string link)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Device.OpenUri(new Uri(link));
            });
        }
        public void InjectedJavaOpen_Hashtag(string word)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new HyberdPostViewer("Hashtag", word));
            });
        }
        public void InjectedJavaOpen_LikePage(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialPageViewer(id, "", ""));
            });
        }
        public void InjectedJavaOpen_Group(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialGroup("id", ""));
            });
        }

        private void AddPost_OnClicked_OnClicked(object sender, EventArgs e)
        {
            try
            {
                Navigation.PushAsync(new AddPost(this));
            }
            catch (Exception exception)
            {
            }
           
        }

        private void Logout_OnClicked(object sender, EventArgs e)
        {
            using (var Data = new LoginFunctions())
            {
                Data.ClearLoginCredentialsList();
            }
            using (var Data = new LoginUserProfileFunctions())
            {
                Data.ClearProfileCredentialsList();
            }
            using (var Data = new MessagesFunctions())
            {
                Data.ClearMessageList();
            }
            using (var Data = new ContactsFunctions())
            {
                Data.DeletAllChatUsersList();
            }

            using (var Data = new ChatActivityFunctions())
            {

                Data.DeletAllChatUsersList();
                WowonderPhone.Settings.ReLogin = true;
                Navigation.PopAsync();
                App.GetLoginPage();
            }


        }

        private void Settings_OnClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SettingsPage());
        }

        private void TimelinePostsTab_OnAppearing(object sender, EventArgs e)
        {
          
        }


        private void RefreshPosts_OnClicked(object sender, EventArgs e)
        {
            
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                // var service = DependencyService.Get<IMethods>();
                // service.ClearWebViewCache();
                OfflinePost.IsVisible = true;
                OfflinePage.IsVisible = false;
                PostWebLoader.IsVisible = false;
                PostWebLoader.Source = WowonderPhone.Settings.Website + "/get_news_feed";

            }
            else
            {
                PostWebLoader.IsVisible = false;
                OfflinePage.IsVisible = true;
                OfflinePost.Source = WowonderPhone.Settings.HTML_OfflinePost_Page;
            }
           
        }

 

       

        public async Task Post_Manager(string Type,string postid)
        {
            try
            {
                var Action = " ";
                if (Type == "edit_post")
                {
                    Action = "edit";
                }
                else
                {
                    Action = "delete";
                }
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", WowonderPhone.Settings.User_id),
                        new KeyValuePair<string, string>("post_id", postid),
                        new KeyValuePair<string, string>("s",WowonderPhone.Settings.Session),
                        new KeyValuePair<string, string>("action",Action),
                        
                    });

                    var response =
                        await
                            client.PostAsync(WowonderPhone.Settings.Website + "/app_api.php?application=phone&type=post_manager",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        if (Type == "edit_post")
                        {
                            Action = "edit";
                        }
                        else
                        {
                           
                        }
                       
                    }
                }
            }
            catch 
            {
                
            }
        }

      

        private void search_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Search_Page());
        }

        private void PostWebLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            OfflinePost.IsVisible = false;
            OfflinePost.Source = null;
            PostWebLoader.IsVisible = true;
            PostWebLoader.RegisterCallback("type", (str) =>
            {
                vsde = str;
                Debug.WriteLine(str);
            });
        }

        private NavigationRequestedDelegate PostWebLoader_OnOnNavigationStarted(NavigationRequestedDelegate eventobj)
        {
            if (eventobj.Uri.Contains(WowonderPhone.Settings.Website))
            {
                return eventobj;
            }
            else
            {
                eventobj.Cancel = true;
                return eventobj;
            }

        }

        private async void PostWebLoader_OnOnJavascriptResponse(JavascriptResponseDelegate eventobj)
        {


            if (eventobj.Data.Contains("type"))
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(eventobj.Data);
                string type = data["type"].ToString();
                if (type == "user")
                {
                    string Userid = data["profile_id"].ToString();
                    if (WowonderPhone.Settings.User_id == Userid)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Navigation.PushAsync(new MyProfilePage());
                        });
                    }
                    else
                    {
                        InjectedJavaOpen_UserProfile(Userid);
                    }

                }
                else if (type == "lightbox")
                {

                    string ImageSource = data["image_url"].ToString();
                    var Image = new UriImageSource
                    {
                        Uri = new Uri(ImageSource),
                        CachingEnabled = true,
                        CacheValidity = new TimeSpan(2, 0, 0, 0)
                    };
                    InjectedJavaOpen_OpenImage(Image);
                }
                else if (type == "mention")
                {
                    string user_id = data["user_id"].ToString();
                    InjectedJavaOpen_UserProfile(user_id);
                }
                else if (type == "hashtag")
                {
                    string hashtag = data["hashtag"].ToString();

                    InjectedJavaOpen_OpenImage(hashtag);
                }
                else if (type == "url")
                {
                    string link = data["link"].ToString();

                    InjectedJavaOpen_PostLinks(link);
                }
                else if (type == "page")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_LikePage(Id);
                }
                else if (type == "group")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_Group(Id);
                }
                else if (type == "post_wonders" || type == "post_likes")
                {
                    string Id = data["post_id"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Like_Wonder_Viewer_Page(Id, type));
                    });
                }
                else if (type == "edit_post")
                {
                    string Id = data["post_id"].ToString();
                    string Edit_text = data["edit_text"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Edit_Post_For_Hyberd_Page(Edit_text, Id, null, this));

                    });
                }
                else if (type == "delete_post")
                {
                    string Id = data["post_id"].ToString();

                    var Qussion = await DisplayAlert(AppResources.Label_Question, AppResources.Label_Would_You_like_to_delete_this_post, AppResources.Label_Yes, AppResources.Label_NO);
                    if (Qussion)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            PostWebLoader.InjectJavascript("$('#post-' + " + Id + ").slideUp(200, function () { $(this).remove();}); ");
                        });

                        Post_Manager("delete_post", Id).ConfigureAwait(false);
                    }
                }
            }
        }

        private void PostWebLoader_OnOnNavigationError(NavigationErrorDelegate eventobj)
        {
            try
            {
                
                OfflinePost.IsVisible = false;
                OfflinePage.IsVisible = true;
                OfflinePost.Source = WowonderPhone.Settings.HTML_OfflinePost_Page;
                PostWebLoader.IsVisible = false;

            }
            catch (Exception e)
            {
                
            }
        }

        private void TryButton_OnClicked(object sender, EventArgs e)
        {
            try
            {
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network; // Create Interface to Network-functions
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (!xx)
                {
                    OfflinePost.IsVisible = true;
                    OfflinePage.IsVisible = false;
                    PostWebLoader.IsVisible = false;
                    PostWebLoader.Source = WowonderPhone.Settings.Website + "/get_news_feed";

                }
                else
                {
                    OfflinePage.IsVisible = true;
                    PostWebLoader.IsVisible = false;
                    OfflinePost.Source = WowonderPhone.Settings.HTML_OfflinePost_Page;
                    UserDialogs.Instance.Toast(AppResources.Label_You_are_still_Offline);
                }
            }
            catch (Exception exception)
            {
               
            }
            
        }
    }
}
