﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using WowonderPhone.Controls;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Timeline_Pages;
using WowonderPhone.Pages.Timeline_Pages.DefaultPages;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xam.Plugin.Abstractions.Events.Inbound;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages
{
    public partial class UserProfilePage : ContentPage
    {

        private string F_Still_NotFriend = "";
        private string F_Request = "";
        private string F_AlreadyFriend = "";

        public static string U_UserID = "";
        public static string S_About = "";
        public static string S_Website = "";
        public static string S_Name = "";
        public static string S_Username = "";
        public static string S_Gender = "";
        public static string S_Email = "";
        public static string S_Birthday = "";
        public static string S_Address = "";
        public static string S_URL = "";
        public static string S_School = "";
        public static string S_Working = "";
        public static string S_Facebook = "";
        public static string S_Google = "";
        public static string S_Twitter = "";
        public static string S_Linkedin = "";
        public static string S_Youtube = "";
        public static string S_VK = "";
        public static string S_Instagram = "";
        public static string S_Can_follow = "";

        
        public class Userprofiletems
        {
            public string Label { get; set; }
            public string Icon { get; set; }
            public string Color { get; set; }
        }

        public static ObservableCollection<Userprofiletems> UserprofileListItems = new ObservableCollection<Userprofiletems>();

        public UserProfilePage(string userid ,string con)
        {
            InitializeComponent();
            U_UserID = userid;

            if (Settings.Messenger_Integration==false)
            {
                MessageImage.IsVisible = false;
                MessageText.IsVisible = false; 
            }

            if (Settings.Show_Block_On_User_Profiles == false)
            {
                blockImage.IsVisible = false;
                BlockLabel.IsVisible = false;
            }



            if (Settings.ConnectivitySystem == "1")
            {
                F_Still_NotFriend = AppResources.Label_Follow;
                F_Request = AppResources.Label_Requested;
                F_AlreadyFriend = AppResources.Label_Following;
            }
            else if (Settings.ConnectivitySystem == "0")
            {
                F_Still_NotFriend = AppResources.Label_AddFriend;
                F_Request = AppResources.Label_Requested;
                F_AlreadyFriend = AppResources.Label_Friends;
            }

            if (con == "FriendList")
            {
                FriendStatusText.Text = F_AlreadyFriend;
                FriendStatusImage.Source = Settings.Likecheked_Icon;
            }
            else
            {
                FriendStatusText.Text = F_Still_NotFriend;
            }
            UserprofileListItems.Clear();
          
            GetUserProfileFromChach(userid);
            AddClickActions();

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                this.Title = AppResources.Label_Loading;
                PostWebLoader.Source = Settings.Website + "/get_news_feed?user_id=" + userid;
                PostWebLoader.OnJavascriptResponse += OnJavascriptResponse;
                PostWebLoader.RegisterCallback("type", (str) => { });
            }
            else
            {
                //PostWebLoader.Source = Settings.HTML_LoadingPost_Page;
            }
            
        }

        public void AddClickActions()
        {

            //FriendStatusImage.Source = Settings.Likecheked_Icon;
            var TapFriendGestureRecognizer = new TapGestureRecognizer();
            TapFriendGestureRecognizer.Tapped += (s, ee) =>
            {
                if (FriendStatusText.Text == F_AlreadyFriend)
                {
                    SendFriendRequest(U_UserID).ConfigureAwait(false);
                    FriendStatusText.Text = F_Still_NotFriend;
                    FriendStatusImage.Source = Settings.AddUser_Icon;
                }
                else if(FriendStatusText.Text == F_Still_NotFriend)
                {
                    
                    SendFriendRequest(U_UserID).ConfigureAwait(false);
                    FriendStatusText.Text = F_AlreadyFriend;
                    FriendStatusImage.Source = Settings.Likecheked_Icon;
                }
                else if (FriendStatusText.Text == F_Request)
                {
                    SendFriendRequest(U_UserID).ConfigureAwait(false);
                    FriendStatusText.Text = F_Still_NotFriend;
                    FriendStatusImage.Source = Settings.AddUser_Icon;
                }
            };

            if (FriendStatusText.GestureRecognizers.Count > 0)
            {
                FriendStatusText.GestureRecognizers.Clear();
            }

            FriendStatusText.GestureRecognizers.Add(TapFriendGestureRecognizer);
            FriendStatusImage.GestureRecognizers.Add(TapFriendGestureRecognizer);

            var TapMessageGestureRecognizer = new TapGestureRecognizer();
            TapMessageGestureRecognizer.Tapped += (s, ee) =>
            { 
               DependencyService.Get<IMethods>().OpenMessengerApp(Settings.Messenger_Package_Name);
            };

            if (MessageText.GestureRecognizers.Count > 0)
            {
                MessageText.GestureRecognizers.Clear();
            }
            if (MessageImage.GestureRecognizers.Count > 0)
            {
                MessageImage.GestureRecognizers.Clear();
            }

            MessageText.GestureRecognizers.Add(TapMessageGestureRecognizer);
            MessageImage.GestureRecognizers.Add(TapMessageGestureRecognizer);



            var TapBlockGestureRecognizer = new TapGestureRecognizer();
            TapBlockGestureRecognizer.Tapped += (s, ee) =>
            {
                if (BlockLabel.Text == AppResources.Label_Block)
                {
                    SendBlockRequest(U_UserID).ConfigureAwait(false);
                    BlockLabel.Text = AppResources.Label_Blocked;
                    blockImage.Source = Settings.BlockedUser_Icon;
                }
                else if(BlockLabel.Text == AppResources.Label_Blocked)
                {
                    SendUnBlockRequest(U_UserID).ConfigureAwait(false);
                    BlockLabel.Text = AppResources.Label_Block;
                    blockImage.Source = Settings.BlockUser_Icon;
                }
            };

            if (BlockLabel.GestureRecognizers.Count > 0)
            {
                BlockLabel.GestureRecognizers.Clear();
            }
            if (blockImage.GestureRecognizers.Count > 0)
            {
                blockImage.GestureRecognizers.Clear();
            }

            blockImage.GestureRecognizers.Add(TapBlockGestureRecognizer);
            BlockLabel.GestureRecognizers.Add(TapBlockGestureRecognizer);

        }


        public  void GetUserProfileFromChach(string userid)
        {
            try
            {

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            using (var ProfileFn = new ContactsFunctions())
            {
                var Profile = ProfileFn.GetContactUser(userid);
                if (Profile == null)
                {
                    if (xx == true)
                    {

                        UserDialogs.Instance.Toast(AppResources.Label_CheckYourInternetConnection);
                    }
                    else
                    {
                        GetUserProfile(userid).ConfigureAwait(false);
                    }
                }
                else
                {
                    this.Title = Profile.Name;
                    Username.Text = Profile.Name;

                    S_About = Profile.About;
                    S_Website = Profile.Website;
                    S_Name = Profile.Website;
                    S_Username = Profile.Username;
                    S_Gender = Profile.Gender;
                    S_Email = Profile.Email;
                    S_Birthday = Profile.Birthday;
                    S_Address = Profile.Address;
                    S_URL = Profile.Url;
                    S_School = Profile.School;
                    S_Working = Profile.Working;
                    S_Facebook = Profile.Facebook;
                    S_Google = Profile.Google;
                    S_Twitter = Profile.Twitter;
                    S_Linkedin = Profile.Linkedin;
                    S_VK = Profile.vk;
                    S_Instagram = Profile.instagram;

                    UserprofileListItems.Add(new Userprofiletems()
                    {
                        Label = Profile.About,
                        Icon = "\uf040",
                        Color = "#c5c9c8"
                    });
                    UserprofileListItems.Add(new Userprofiletems()
                    {
                        Label = Profile.Gender,
                        Icon = "\uf224",
                        Color = "#c5c9c8"
                    });
                    UserprofileListItems.Add(new Userprofiletems()
                    {
                        Label = Profile.Birthday,
                        Icon = "\uf133",
                        Color = "#c5c9c8"
                    });
                    UserprofileListItems.Add(new Userprofiletems()
                    {
                        Label = AppResources.Label_Show_More,
                        Icon = "\uf0ca",
                        Color = Settings.MainColor,

                    });

                    LastseenLabel.Text = Profile.lastseen;
                    UserInfoList.ItemsSource = UserprofileListItems;
                    AvatarImage.Source = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(Profile.Avatar, userid));
                    CoverImage.Source = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(Profile.Cover, userid));
                    var tapGestureRecognizer = new TapGestureRecognizer();

                    tapGestureRecognizer.Tapped += (s, ee) =>
                    {
                        DependencyService.Get<IMethods>().OpenImage("Disk", Profile.Avatar, userid);
                    };

                    if (AvatarImage.GestureRecognizers.Count > 0)
                    {
                        AvatarImage.GestureRecognizers.Clear();
                    }

                    AvatarImage.GestureRecognizers.Add(tapGestureRecognizer);


                    //Start updating the profile again
                    if (xx != true)
                    {
                        GetUserProfile(userid).ConfigureAwait(false);
                    }
                }
            }
            }
            catch (Exception)
            {

            }
        }

        public async Task<string> GetUserProfile(string userid)
        {
        try
        {
            using (var client = new HttpClient())
            {
                var formContent = new FormUrlEncodedContent(new[]
                 {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("user_profile_id",userid),
                    new KeyValuePair<string, string>("s",Settings.Session)
                 });

                var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_user_data", formContent);
                response.EnsureSuccessStatusCode();
                string json = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                string apiStatus = data["api_status"].ToString();
                if (apiStatus == "200")
                {
                    JObject userdata = JObject.FromObject(data["user_data"]);
                    //Settings.UserFullName = userdata["name"].ToString();

                    var avatar = userdata["avatar"].ToString();
                    var cover = userdata["cover"].ToString();
                    var First_name = userdata["first_name"].ToString();
                    var Last_name = userdata["last_name"].ToString();
                    var Website = userdata["website"].ToString();
                    var user_id = userdata["user_id"].ToString();
                    var Lastseen = userdata["lastseen_time_text"].ToString();
                    var url = userdata["url"].ToString();
                    var is_following = userdata["is_following"].ToString();
                    var Pro_Type = userdata["pro_type"].ToString();
                    var Is_Pro = userdata["is_pro"].ToString();
                    var Is_blocked = userdata["is_blocked"].ToString();

                        
                    S_About = Functions.DecodeString(userdata["about"].ToString()); 

                    S_Website = userdata["website"].ToString();
                    S_Name = userdata["name"].ToString();
                    S_Username = userdata["username"].ToString();
                    S_Gender = userdata["gender"].ToString();
                    S_Email = userdata["email"].ToString();
                    S_Birthday = userdata["birthday"].ToString();
                    S_Address = userdata["address"].ToString();
                    S_URL = userdata["url"].ToString();
                    S_School = userdata["school"].ToString();
                    S_Working = userdata["working"].ToString();
                    S_Facebook = userdata["facebook"].ToString();
                    S_Google = userdata["google"].ToString();
                    S_Twitter = userdata["twitter"].ToString();
                    S_Linkedin = userdata["linkedin"].ToString();
                    S_Youtube = userdata["youtube"].ToString();
                    S_VK = userdata["vk"].ToString();
                    S_Instagram = userdata["instagram"].ToString();
                    S_Can_follow = userdata["can_follow"].ToString();

                    if (Is_Pro == "1")
                    {
                            if (Pro_Type == "1")
                            {
                                StarIcon.IsVisible = true;
                            }
                            else if(Pro_Type == "2")
                            {
                                HotIcon.IsVisible = true;
                            }
                            else if (Pro_Type == "3")
                            {
                                UltimaIcon.IsVisible = true;
                            }
                            else if (Pro_Type == "4")
                            {
                                VIPIcon.IsVisible = true;
                            }
                      }
                    if (Is_blocked == "true")
                    {
                            BlockLabel.Text = AppResources.Label_Blocked;
                            blockImage.Source = Settings.BlockedUser_Icon;
                    }

                        var Post_Count = userdata["post_count"].ToString();
                        if (Post_Count == "0")
                        {
                            ButtonStacklayot.IsVisible = false;
                            PostWebLoader.HeightRequest = 230;
                        }
                        else if (Post_Count == "1")
                        {
                            PostWebLoader.HeightRequest = 260;
                        }
                        else if (Post_Count == "2")
                        {
                            PostWebLoader.HeightRequest = 570;
                        }

                        else if (Post_Count == "3")
                        {
                            PostWebLoader.HeightRequest = 740;
                        }
                        else if (Post_Count == "4")
                        {
                            PostWebLoader.HeightRequest = 950;
                        }
                        else if (Post_Count == "5")
                        {
                            PostWebLoader.HeightRequest = 1150;
                        }
                        else if (Post_Count == "6")
                        {
                            PostWebLoader.HeightRequest = 1350;
                        }
                        else if (Post_Count == "7")
                        {
                            PostWebLoader.HeightRequest = 1550;
                        }
                        else if (Post_Count == "8")
                        {
                            PostWebLoader.HeightRequest = 1850;
                        }
                        CoverImage.Source = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(cover, user_id));
                    if (DependencyService.Get<IPicture>().GetPictureFromDisk(cover, user_id) == "File Dont Exists")
                    {
                        CoverImage.Source = new UriImageSource { Uri = new Uri(cover) };
                        DependencyService.Get<IPicture>().SavePictureToDisk(cover, user_id);
                    }

                    AvatarImage.Source = ImageSource.FromFile(DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id));
                    if (DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id) == "File Dont Exists")
                    {
                        AvatarImage.Source = new UriImageSource { Uri = new Uri(avatar) };
                        DependencyService.Get<IPicture>().SavePictureToDisk(avatar, user_id);
                    }

                    if (Website == "") { Website = AppResources.Label_Unavailable; }
                    if (S_School == "")
                    {
                        S_School = AppResources.Label_Askme;
                    }
                    if (S_Birthday == "" || S_Birthday.Contains("00"))
                    {
                        S_Birthday = AppResources.Label_Askme;
                    }
                    if (S_About == ""|| S_About == " ")
                    {
                        S_About = Settings.PR_AboutDefault;
                    }
                    if (S_Address == "")
                    {
                        S_Address = AppResources.Label_Unavailable;
                    }
                    if (S_Gender == "")
                    {
                        S_Gender = AppResources.Label_Unavailable;
                    }
                    if (S_Working == "")
                    {
                       S_Working = AppResources.Label_Unavailable;
                    }
                   
                    LastseenLabel.Text = Lastseen;

                    if (Lastseen == "online" || Lastseen == "Online" || Lastseen.Contains("sec") || Lastseen.Contains("Sec"))
                    {
                        LastseenLabel.Text = AppResources.Label_Online;
                    }

                    if (S_Can_follow == "0" && is_following == "0")
                    {
                        if (FriendStatusText.IsVisible)
                        {
                                FriendStatusText.IsVisible = false;
                                FriendStatusImage.IsVisible = false;
                        }
                       
                    }

                    if (is_following == "1")
                    {
                            if (FriendStatusText.Text != F_AlreadyFriend)
                            {
                                FriendStatusText.Text = F_AlreadyFriend;
                                FriendStatusImage.Source = Settings.Likecheked_Icon;
                            }
                        
                    }
                    else if (is_following == "2")
                    {
                            if (FriendStatusText.Text != F_Request)
                            {
                                FriendStatusText.Text = F_Request;
                                FriendStatusImage.Source = Settings.Requested_Icon;
                            }
                       
                    }
                    else if (is_following == "0")
                    {
                        if (FriendStatusText.Text != F_Still_NotFriend)
                        {
                           FriendStatusText.Text = F_Still_NotFriend;
                           FriendStatusImage.Source = Settings.AddUser_Icon;
                        }  
                    }

                        Username.Text = S_Name;

                      if (UserprofileListItems.Count > 0)
                      {
                       UserprofileListItems.Clear();
                      }

                        UserprofileListItems.Add(new Userprofiletems()
                        {
                            Label = S_About,
                            Icon = "\uf040",
                            Color = "#c5c9c8"
                        });
                        UserprofileListItems.Add(new Userprofiletems()
                        {
                            Label = S_Gender,
                            Icon = "\uf224",
                            Color = "#c5c9c8"
                        });
                        UserprofileListItems.Add(new Userprofiletems()
                        {
                            Label = S_Birthday,
                            Icon = "\uf133",
                            Color = "#c5c9c8"
                        });
                        UserprofileListItems.Add(new Userprofiletems()
                        {
                            Label = AppResources.Label_Show_More,
                            Icon = "\uf0ca",
                            Color = Settings.MainColor,

                        });

                        UserInfoList.ItemsSource = UserprofileListItems;
                        this.Title = S_Name;


                      UserInfoList.HeightRequest = Functions.ListInfoResizer(S_About);


                    using (var Datas = new ContactsFunctions())
                    {
                        var contact = Datas.GetContactUser(user_id);
                        if (contact != null)
                        {
                            if (contact.UserID == user_id && ((contact.Cover != cover) || (contact.Avatar != avatar) || (contact.Birthday != S_Birthday) || (contact.Name != S_Name)
                                || (contact.Username != S_Username) || (contact.First_name != First_name) || (contact.Last_name != Last_name) || (contact.lastseen != Lastseen) || (contact.About != S_About) || (contact.Website != Website)
                                || (contact.School != S_School)))
                            {
                              
                                if ((contact.Avatar != avatar))
                                {
                                    DependencyService.Get<IPicture>().DeletePictureFromDisk(contact.Avatar, user_id);
                                }
                                if ((contact.Cover != cover))
                                {
                                    DependencyService.Get<IPicture>().DeletePictureFromDisk(contact.Cover, user_id);
                                }

                                contact.UserID = user_id;
                                contact.Name = S_Name;
                                contact.Avatar = avatar;
                                contact.Cover = cover;
                                contact.Birthday = S_Birthday;
                                contact.Address = S_Address;
                                contact.Gender = S_Gender;
                                contact.Email = S_Email;
                                contact.Username = S_Username;
                                contact.First_name = First_name;
                                contact.Last_name = Last_name;
                                contact.About = S_About;
                                contact.Website = Website;
                                contact.School = S_School;
                                contact.lastseen = Lastseen;

                                Datas.UpdateContactUsers(contact);
                            }
                        }

                    }

                }
                else if (apiStatus == "400")
                {
                    json = AppResources.Label_Error;
                }
                return json;
            }
        }
        catch (Exception)
        {

            return AppResources.Label_Error;
        }

    }

       
        public static async Task<string> SendFriendRequest(string recipient_id)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("recipient_id", recipient_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=follow_user",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        return "Succes";

                    }
                }
            }
            catch (Exception)
            {

            }
            return null;
        }

        public static async Task<string> SendBlockRequest(string recipient_id)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("block_type", "block"),
                         new KeyValuePair<string, string>("recipient_id", recipient_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=block_user",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        return "Succes";

                    }
                }
            }
            catch (Exception)
            {

            }
            return null;
        }

        public static async Task<string> SendUnBlockRequest(string recipient_id)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("block_type", "un-block"),
                         new KeyValuePair<string, string>("recipient_id", recipient_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=block_user",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        return "Succes";

                    }
                }
            }
            catch (Exception)
            {

            }
            return null;
        }

       
        private void UserProfilePage_OnDisappearing(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void UserInfoList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            UserInfoList.SelectedItem = null;
        }

        private void UserInfoList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var item = e.Item as Userprofiletems;
            if (item.Label == AppResources.Label_Show_More)
            {
                Navigation.PushAsync(new InfoViewer("User"));
            }
        }

        private void CopyUrlButton_OnClicked(object sender, EventArgs e)
        {
            DependencyService.Get<IClipboardService>().CopyToClipboard(S_URL);
        }

        public void OnScroll(object sender, ScrolledEventArgs e)
        {
            //var imageHeight = CoverImage.Height * 2;
            //var scrollRegion = layeringGrid.Height - outerScrollView.Height;
            //var parallexRegion = imageHeight - outerScrollView.Height;
            //var factor = outerScrollView.ScrollY - parallexRegion * (outerScrollView.ScrollY / scrollRegion);
            //CoverImage.TranslationY = factor;
            //CoverImage.Opacity = 1 - (factor / imageHeight);
            //PostWebLoader.Scale = 1 - ((factor) / (imageHeight * 2));
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            outerScrollView.Scrolled += OnScroll;
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            outerScrollView.Scrolled -= OnScroll;
        }

       

        private void ShowmoreButton_OnClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new HyberdPostViewer("User",""));
        }

        private async void OnJavascriptResponse(JavascriptResponseDelegate EventObj)
        {

            if (EventObj.Data.Contains("type"))
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(EventObj.Data);
                string type = data["type"].ToString();
                if (type == "user")
                {
                    string Userid = data["profile_id"].ToString();
                    if (WowonderPhone.Settings.User_id == Userid)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Navigation.PushAsync(new MyProfilePage());
                        });
                    }
                    else if (Userid == U_UserID)
                    {
                        return;
                    }
                    else
                    {
                        InjectedJavaOpen_UserProfile(Userid);
                    }

                }
                else if (type == "lightbox")
                {
                    string ImageSource = data["image_url"].ToString();
                    var Image = new UriImageSource
                    {
                        Uri = new Uri(ImageSource),
                        CachingEnabled = true,
                        CacheValidity = new TimeSpan(2, 0, 0, 0)
                    };
                    InjectedJavaOpen_OpenImage(Image);
                }
                else if (type == "mention")
                {
                    string user_id = data["user_id"].ToString();
                    InjectedJavaOpen_UserProfile(user_id);
                }
                else if (type == "hashtag")
                {
                    string hashtag = data["hashtag"].ToString();

                    InjectedJavaOpen_OpenImage(hashtag);
                }
                else if (type == "url")
                {
                    string link = data["link"].ToString();

                    InjectedJavaOpen_PostLinks(link);
                }
                else if (type == "page")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_LikePage(Id);
                }
                else if (type == "group")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_Group(Id);
                }
                else if (type == "post_wonders" || type == "post_likes")
                {
                    string Id = data["post_id"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Like_Wonder_Viewer_Page(Id, type));
                    });
                }
               
                else if (type == "delete_post")
                {
                    string Id = data["post_id"].ToString();

                    var Qussion = await DisplayAlert(AppResources.Label_Question, AppResources.Label_Would_You_like_to_delete_this_post, AppResources.Label_Yes, AppResources.Label_NO);
                    if (Qussion)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            PostWebLoader.InjectJavascript("$('#post-' + " + Id + ").slideUp(200, function () { $(this).remove();}); ");
                        });

                        Post_Manager("delete_post", Id).ConfigureAwait(false);
                    }
                }

            }

        }
        public void InjectedJavaOpen_UserProfile(string Userid)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new UserProfilePage(Userid, ""));
            });
        }
        public void InjectedJavaOpen_OpenImage(ImageSource Image)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushModalAsync(new ImageFullScreenPage(Image));
            });
        }
        public void InjectedJavaOpen_PostLinks(string link)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Device.OpenUri(new Uri(link));
            });
        }
        public void InjectedJavaOpen_Hashtag(string word)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new HyberdPostViewer("Hashtag", word));
            });
        }
        public void InjectedJavaOpen_LikePage(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialPageViewer(id, "", ""));
            });
        }
        public void InjectedJavaOpen_Group(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialGroup("id", ""));
            });
        }

        public async Task Post_Manager(string Type, string postid)
        {
            try
            {
                var Action = " ";
                if (Type == "edit_post")
                {
                    Action = "edit";
                }
                else
                {
                    Action = "delete";
                }
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", WowonderPhone.Settings.User_id),
                        new KeyValuePair<string, string>("post_id", postid),
                        new KeyValuePair<string, string>("s",WowonderPhone.Settings.Session),
                        new KeyValuePair<string, string>("action",Action),

                    });

                    var response =
                        await
                            client.PostAsync(WowonderPhone.Settings.Website + "/app_api.php?application=phone&type=post_manager",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        if (Type == "edit_post")
                        {
                            Action = "edit";
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch
            {

            }
        }

        private void PostWebLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            //OfflinePost.IsVisible = false;
            //OfflinePost.Source = null;
            //PostWebLoader.IsVisible = true;
            PostWebLoader.RegisterCallback("type", (str) => { });
        }
    }
}


//{
//    "api_status": "200",
//    "api_text": "success",
//    "api_version": "1.4.1",
//    "user_data": {
//        "user_id": "1",
//        "username": "deendoughouz",
//        "email": "deendoughouz@gmail.com",
//        "first_name": "Deen",
//        "last_name": "Doughouz",
//        "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/02\/l3AAT2Lg3BcRDfaVQimy_17_88e3cb39ec306edcae265a40bb58e7e9_avatar.jpg",
//        "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/02\/EbabAD8Gr2D2AEy1psVI_21_5bb19f86b76d53af2db8237e2de287ca_cover.jpg",
//        "relationship_id": "0",
//        "address": "\u0130stanbul, T\u00fcrkiye",
//        "working": "WoWonder",
//        "working_link": "http:\/\/www.wowonder.com",
//        "about": "I&#039;m Deen, I love coding !",
//        "school": "PHP",
//        "gender": "male",
//        "birthday": "1997-05-28",
//        "website": "https:\/\/www.wowonder.com",
//        "facebook": "deendoughouz",
//        "google": "",
//        "twitter": "",
//        "linkedin": "",
//        "youtube": "channel\/UCm_jYhKckK_QY-ugiefU9mA",
//        "vk": "",
//        "instagram": "",
//        "language": "english",
//        "ip_address": "178.241.212.237",
//        "follow_privacy": "0",
//        "post_privacy": "ifollow",
//        "message_privacy": "0",
//        "confirm_followers": "0",
//        "show_activities_privacy": "1",
//        "birth_privacy": "2",
//        "visit_privacy": "0",
//        "verified": "1",
//        "lastseen": "1488026743",
//        "showlastseen": "1",
//        "status": "0",
//        "active": "1",
//        "admin": "1",
//        "registered": "00\/0000",
//        "phone_number": "",
//        "is_pro": "1",
//        "pro_type": "3",
//        "joined": "0",
//        "timezone": "Europe\/Istanbul",
//        "referrer": "0",
//        "balance": "0.7",
//        "paypal_email": "",
//        "notifications_sound": "1",
//        "order_posts_by": "0",
//        "url": "https:\/\/demo.wowonder.com\/deendoughouz",
//        "name": "Deen Doughouz",
//        "is_following": 1,
//        "can_follow": 1,
//        "gender_text": "Male",
//        "lastseen_time_text": "2 hours ago"
//    }
//}