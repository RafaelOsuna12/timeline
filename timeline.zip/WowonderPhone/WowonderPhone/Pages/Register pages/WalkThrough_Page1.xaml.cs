﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Classes;
using WowonderPhone.Controls;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Timeline_Pages.DefaultPages;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Register_pages
{
    public partial class WalkThrough_Page1 : ContentPage
    {
        public WalkThrough_Page1()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
            Gifplayer.Source = Settings.GIF_ProUpgrade;
            Webviewcooki.Source = WowonderPhone.Settings.Website + "/app_api.php?application=phone&type=set_c&c=" + WowonderPhone.Settings.Cookie;
            try
            {
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network;
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (xx == true)
                {
                    
                }
                else
                {
                   
                    Span1.Text = AppResources.Label_Loading_User_Contacts;
                    LoadContacts();
                    
                }
            }
            catch (Exception)
            {

            }
            
        }


        public async void LoadContacts()
        {
            await Functions.GetChatContacts(Settings.User_id, Settings.Session);
            Span1.Text = AppResources.Label_User_Contacts_Loaded;
            Spanchek1.Text = "\uf05d";
            await Task.Delay(1000);
            Span2.Text = AppResources.Label_Loading_User_Data;
            Spanchek2.Text = "\uf0da";
            await LoginUserFunctions.GetSessionProfileData(Settings.User_id, Settings.Session);
            await Task.Delay(3000);
            Span2.Text = AppResources.Label_User_Data_Loaded;
            Spanchek2.Text = "\uf05d";
            await Task.Delay(1000);
            Span3.Text = AppResources.Label_Loading_User_Pages;
            Spanchek3.Text = "\uf0da";
            await GetCommunities();
            await Task.Delay(3000);
            Span3.Text = AppResources.Label_Pages_and_Groups_Loaded;
            Spanchek3.Text = "\uf05d";
            NextButton.Text = AppResources.Label_Finish;

        }

        private void NextButtonClicked(object sender, EventArgs e)
        {
            try
            {
                if (NextButton.Text == AppResources.Label_Finish)
                {
                    using (var Data = new LoginFunctions())
                    {
                       
                        var CredentialStatus = Data.GetLoginCredentialsStatus();
                        if (CredentialStatus == "Registered")
                        {
                            var Credential = Data.GetLoginCredentials("Registered");
                            Credential.Status = "Active";
                            Data.UpdateLoginCredentials(Credential);
                            Settings.Session = Credential.Session;
                            Settings.User_id = Credential.UserID;
                            Settings.Username = Credential.Username;
                        }

                    }

                    var navigationPage = new NavigationPage(new MasterMainSlidePage()) { };
                    navigationPage.BarBackgroundColor = Color.FromHex(Settings.MainPage_HeaderBackround_Color);
                    navigationPage.BarTextColor = Color.FromHex(Settings.MainPage_HeaderText_Color);
                    navigationPage.Title = Settings.MainPage_HeaderTextLabel;
                    navigationPage.Padding = new Thickness(0, 0, 0, 0);
                    Application.Current.MainPage = navigationPage;
                    //Navigation.PushAsync(navigationPage);
                    //App.Current.MainPage.Navigation.PushAsync(navigationPage);

                }
               
            }
            catch (Exception)
            {
                Navigation.PushModalAsync(new RegisterFriends());
            }


        }


        public async Task<string> GetCommunities()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                     {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("user_profile_id",Settings.User_id),
                    new KeyValuePair<string, string>("s",Settings.Session)
                 });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_my_community", formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var Page = JObject.Parse(json).SelectToken("pages").ToString();
                        JArray PagedataArray = JArray.Parse(Page);

                        foreach (var PageItem in PagedataArray)
                        {

                            var page_id = PageItem["page_id"].ToString();
                            var page_name = PageItem["page_name"].ToString();
                            var page_title = PageItem["page_title"].ToString();
                            var avatar = PageItem["avatar"].ToString();
                            var about = PageItem["about"].ToString();
                            var url = PageItem["url"].ToString();
                            var category = PageItem["category"].ToString();

                            var Imagepath = DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, page_id);
                            var ImageMediaFile = ImageSource.FromFile(Imagepath);

                            if (Imagepath == "File Dont Exists")
                            {
                                ImageMediaFile = new UriImageSource { Uri = new Uri(avatar) };
                                DependencyService.Get<IPicture>().SavePictureToDisk(avatar, page_id);
                            }

                            var Cheke = CommunitiesPage.CommunitiesListItems.FirstOrDefault(a => a.CommunityID == page_id);
                            if (CommunitiesPage.CommunitiesListItems.Contains(Cheke))
                            {
                                if (Cheke.CommunityName != page_name)
                                {
                                    Cheke.CommunityName = page_name;
                                }
                                if (Cheke.ImageUrlString != avatar)
                                {
                                    Cheke.CommunityPicture = new UriImageSource { Uri = new Uri(avatar) };
                                }

                            }
                            else
                            {
                                CommunitiesPage.CommunitiesListItems.Add(new Communities()
                                {
                                    CommunityID = page_id,
                                    CommunityName = page_name,
                                    CommunityType = "Pages",
                                    CommunityPicture = ImageMediaFile,
                                    ImageUrlString = avatar
                                });
                            }


                            using (var CO_Data = new CommunitiesFunction())
                            {
                                var Community = CO_Data.GetCommunityByID(page_id);
                                if (Community != null)
                                {
                                    if (Community.CommunityID == page_id && (Community.CommunityName != page_name || Community.CommunityPicture != avatar || Community.CommunityUrl != url))
                                    {
                                        Community.CommunityName = page_name;
                                        Community.CommunityPicture = avatar;
                                        Community.CommunityUrl = url;
                                        Community.CommunityID = page_id;

                                        CO_Data.UpdateCommunities(Community);
                                    }
                                }
                                else
                                {
                                    CO_Data.InsertCommunities(new CommunitiesDB()
                                    {
                                        CommunityID = page_id,
                                        CommunityName = page_name,
                                        CommunityPicture = avatar,
                                        CommunityType = "Pages",
                                        CommunityUrl = url
                                    });
                                }
                            }
                        }

                        var Group = JObject.Parse(json).SelectToken("groups").ToString();
                        JArray GroupdataArray = JArray.Parse(Group);


                        if (GroupdataArray.Count <= 0 && PagedataArray.Count <= 0)
                        {
                            
                            return "emety";
                        }
                        else
                        {
                            foreach (var GroupItem in GroupdataArray)
                            {

                                var group_id = GroupItem["group_id"].ToString();
                                var group_name = GroupItem["group_name"].ToString();
                                var group_title = GroupItem["group_name"].ToString();
                                var avatar = GroupItem["avatar"].ToString();
                                var about = GroupItem["about"].ToString();
                                var url = GroupItem["url"].ToString();
                                var category = GroupItem["category"].ToString();

                                var Imagepath = DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, group_id);
                                var ImageMediaFile = ImageSource.FromFile(Imagepath);

                                if (Imagepath == "File Dont Exists")
                                {
                                    ImageMediaFile = new UriImageSource { Uri = new Uri(avatar) };
                                    DependencyService.Get<IPicture>().SavePictureToDisk(avatar, group_id);
                                }
                                var Cheke = CommunitiesPage.CommunitiesListItems.FirstOrDefault(a => a.CommunityID == group_id);
                                if (CommunitiesPage.CommunitiesListItems.Contains(Cheke))
                                {
                                    if (Cheke.CommunityName != group_name)
                                    {
                                        Cheke.CommunityName = group_name;
                                    }
                                    if (Cheke.ImageUrlString != avatar)
                                    {
                                        Cheke.CommunityPicture = new UriImageSource { Uri = new Uri(avatar) };
                                    }

                                }
                                else
                                {
                                    CommunitiesPage.CommunitiesListItems.Add(new Communities()
                                    {
                                        CommunityID = group_id,
                                        CommunityName = group_name,
                                        CommunityType = "Groups",
                                        CommunityPicture = ImageMediaFile,
                                        ImageUrlString = avatar
                                    });
                                }


                                using (var CO_Data = new CommunitiesFunction())
                                {
                                    var Community = CO_Data.GetCommunityByID(group_id);
                                    if (Community != null)
                                    {
                                        if (Community.CommunityID == group_id && (Community.CommunityName != group_name || Community.CommunityPicture != avatar || Community.CommunityUrl != url))
                                        {
                                            Community.CommunityName = group_name;
                                            Community.CommunityPicture = avatar;
                                            Community.CommunityUrl = url;
                                            Community.CommunityID = group_id;
                                            CO_Data.UpdateCommunities(Community);
                                        }
                                    }
                                    else
                                    {
                                        CO_Data.InsertCommunities(new CommunitiesDB()
                                        {
                                            CommunityID = group_id,
                                            CommunityName = group_name,
                                            CommunityPicture = avatar,
                                            CommunityType = "Groups",
                                            CommunityUrl = url
                                        });
                                    }
                                }
                            }

                        }
                        
                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }
                    return json;
                }
            }
            catch (Exception)
            {
                return AppResources.Label_Error;
            }

        }
    }
}
