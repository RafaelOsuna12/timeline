﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Controls;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Register_pages
{
    public partial class GoogleView : ContentPage
    {
        public static string HashSet = "";
        public static string Result = "false";

        public GoogleView()
        {
            InitializeComponent();
            UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Black);
            HashSet = RandomString(80);
            WebView1.Source = Settings.Website + "/app_api.php?application=phone&type=user_login_with&provider=Google&hash=" + HashSet;
            TimerLogin().ConfigureAwait(false);
        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXdsdaawerthklmnbvcxer46gfdsYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void WebView1_OnNavigated(object sender, WebNavigatedEventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }

       

        public async Task<string> GoogleLogin()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var response = await client.GetAsync(Settings.Website + "/app_api.php?application=phone&type=check_hash&hash_id=" + HashSet);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        JObject userdata = JObject.FromObject(data["user_data"]);
                        Settings.User_id = userdata["user_id"].ToString();
                        Settings.Session = userdata["session_id"].ToString();
                        Settings.Cookie = userdata["cookie"].ToString();
                        using (var datas = new LoginFunctions())
                        {
                            LoginTableDB LoginData = new LoginTableDB();
                            LoginData.Session = Settings.Session;
                            LoginData.UserID = Settings.User_id;
                            LoginData.Status = "Active";
                            LoginData.Cookie = Settings.Cookie;
                            datas.InsertLoginCredentials(LoginData);
                        }
                        Result = "True";



                        await Navigation.PushAsync(new WalkThrough_Page1());


                    }
                }
            }
            catch
            {

            }

            return "true";
        }


        public async Task<string> TimerLogin()
        {
            try
            {
                Stopwatch sw = new Stopwatch();
                for (int i = 0; i < 5; i++)
                {
                    while (Result == "false")
                    {
                        await Task.Delay(3000);
                        await GoogleLogin();
                        if (Result == "True")
                        {

                            return "Stop";
                        }

                    }
                }
            }
            catch
            {

            }

            return "true";
        }

    }
}


