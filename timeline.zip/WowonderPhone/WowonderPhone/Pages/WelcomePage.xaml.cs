﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Pages.Register_pages;
using Xamarin.Forms;

namespace WowonderPhone.Pages
{
    public partial class WelcomePage : ContentPage
    {
        public WelcomePage()
        {
            InitializeComponent();

            NavigationPage.SetHasNavigationBar(this, false);
        }

        private async void RegisterButtonTapped(object sender, EventArgs e)
        {
            try
            {
                await Navigation.PushModalAsync(new RegisterPage());
            }
            catch (Exception)
            {

                await Navigation.PushAsync(new RegisterPage());
            }
        }

        private async void LoginButtonTapped(object sender, EventArgs e)
        {
            try
            {
                Navigation.PushModalAsync(new MainPage());
            }
            catch (Exception)
            {

                Navigation.PushAsync(new MainPage());
            }
        }
    }
}
