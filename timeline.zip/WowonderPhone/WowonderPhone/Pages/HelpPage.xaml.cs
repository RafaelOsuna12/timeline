﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using WowonderPhone.Languish;
using Xam.Plugin.Abstractions.Events.Inbound;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages
{
    public partial class HelpPage : ContentPage
    {
        public HelpPage()
        {
            InitializeComponent();

           
                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network; // Create Interface to Network-functions
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (!xx)
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.None);
                    AboutUSLoader.Source = WowonderPhone.Settings.Website + "/terms/about-us";
                  
                    AboutUSLoader.InjectJavascript("$('.content-container').css('margin-top', '0');");
                    AboutUSLoader.InjectJavascript("$('.header-container').hide();");
                    AboutUSLoader.InjectJavascript("$('.footer-wrapper').hide();");

                }
                else
                {
                    AboutUSLoader.IsVisible = false;
                    OfflinePage.IsVisible = true;
                }
           

        }


        private void AboutUSLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            AboutUSLoader.InjectJavascript("$('.content-container').css('margin-top', '0');");
            AboutUSLoader.InjectJavascript("$('.header-container').hide();");
            AboutUSLoader.InjectJavascript("$('.footer-wrapper').hide();");
            OfflinePage.IsVisible = false;
            AboutUSLoader.IsVisible = true;
            
            UserDialogs.Instance.HideLoading();
        }

        private void TryButton_OnClicked(object sender, EventArgs e)
        {


            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                UserDialogs.Instance.ShowLoading(AppResources.Label_Loading);
                AboutUSLoader.Source = WowonderPhone.Settings.Website + "/terms/about-us";

                AboutUSLoader.InjectJavascript("$('.content-container').css('margin-top', '0');");
                AboutUSLoader.InjectJavascript("$('.header-container').hide();");
                AboutUSLoader.InjectJavascript("$('.footer-wrapper').hide();");

            }
            else
            {
                AboutUSLoader.IsVisible = false;
                OfflinePage.IsVisible = true;
            }


        }


        private void HelpPage_OnDisappearing(object sender, EventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }
    }
}
