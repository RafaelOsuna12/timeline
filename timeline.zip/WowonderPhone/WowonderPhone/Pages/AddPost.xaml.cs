﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Plugin.Media;
using Plugin.Media.Abstractions;
using PropertyChanged;
using WowonderPhone.Controls;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Tabs;
using WowonderPhone.Pages.Timeline_Pages;
using WowonderPhone.Pages.Timeline_Pages.AddPostNavPages;
using WowonderPhone.SQLite;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages
{
    public partial class AddPost : ContentPage
    {

        public class PostItems
        {
            public string Label { get; set; }
            public ImageSource Icon { get; set; }
        }

        [ImplementPropertyChanged]
        public class Activitytems
        {
            public string Label { get; set; }
            public string Content { get; set; }
            public string Icon { get; set; }
            public string TypePost { get; set; }
            public ImageSource Image { get; set; }
            public Stream Stream { get; set; }
            public string Filepath { get; set; }
        }

        public static ObservableCollection<PostItems> PostListItems = new ObservableCollection<PostItems>();

        public static ObservableCollection<Activitytems> ActivityListItems = new ObservableCollection<Activitytems>();

        public static string Contenttextcach = "";

        public static bool IsPageInNavigationStack<TPage>(INavigation navigation) where TPage : Page
        {
            if (navigation.NavigationStack.Count > 1)
            {
                var last = navigation.NavigationStack[navigation.NavigationStack.Count - 2];

                if (last is TPage)
                {
                    return true;
                }
            }
            return false;
        }

        public void AddPrivacyToList()
        {
            try
            {

           
            if (PrivacyAddPostPage.PrivacyListItemsCollection.Count == 0)
            {
                if (Settings.ConnectivitySystem == "1")
                {
                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_Everyone,
                        value = "0",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_People_I_Follow,
                        value = "1",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_People_Follow_Me,
                        value = "2",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_Only_me,
                        value = "3",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                }
                else
                {
                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_Everyone,
                        value = "0",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_My_Friends,
                        value = "1",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });

                    PrivacyAddPostPage.PrivacyListItemsCollection.Add(new PrivacyAddPostPage.PrivacyItems()
                    {
                        PrivacyLabel = AppResources.Label_Only_me,
                        value = "2",
                        Checkicon = "\uf1db",
                        CheckiconColor = Settings.MainColor
                    });
                }
            }
            using (var Data = new LoginFunctions())
            {
                var Database = Data.GetLoginCredentialsByUserID(Settings.User_id);
                
                    if (Database.PrivacyPostValue == null)
                    {
                        var SelectedValue = PrivacyAddPostPage.PrivacyListItemsCollection.FirstOrDefault(a => a.value == Database.PrivacyPostValue);

                        if (SelectedValue != null)
                        {
                            SelectedValue.Checkicon = "\uf058";
                            PrivacyAddPostPage.PostPrivacyValueNumber = SelectedValue.value;
                        }
                        else
                        {
                            SelectedValue = PrivacyAddPostPage.PrivacyListItemsCollection.FirstOrDefault(a => a.PrivacyLabel == AppResources.Label_Only_me);
                            SelectedValue.Checkicon = "\uf058";
                        }
                    }
                    else
                    {
                        var SelectedValue = PrivacyAddPostPage.PrivacyListItemsCollection.FirstOrDefault(a => a.PrivacyLabel == AppResources.Label_Only_me);
                        SelectedValue.Checkicon = "\uf058";
                    }
                    
              }
            }
            catch (Exception e)
            {
            }
        }

        private TimelinePostsTab Page;

        public AddPost(TimelinePostsTab PostTimline)
        {
            try
            {
            
            InitializeComponent();

            Page = PostTimline;


            PostListItems.Clear();

            if (Contenttextcach != "")
            {
                PostContent.Text = Contenttextcach;
            }

            ActivityList.ItemsSource = ActivityListItems;

            if (PostListItems.Count == 0)
            {
                PostListItems.Add(new PostItems()
                {
                    Label = AppResources.Label_Pick_Take_Photo,
                    Icon = Settings.Post_Picture_Icon,
                });

                PostListItems.Add(new PostItems()
                {
                    Label = AppResources.Label_Pick_Video_Recourd,
                    Icon = Settings.Post_Video_Icon,
                });

                PostListItems.Add(new PostItems()
                {
                    Label = AppResources.Label_Feeling_Activity,
                    Icon = Settings.Post_Feeling_Icon,
                });
                PostListItems.Add(new PostItems()
                {
                    Label = AppResources.Label_Mention_Friend,
                    Icon = Settings.Post_Tags_Icon,
                });

            }

            PostList.ItemsSource = PostListItems;
            AddPrivacyToList();
            }
            catch (Exception e)
            {
               
            }
        }

        private void PostContent_OnTextChanged(object sender, TextChangedEventArgs e)
        {
          PostContent.TextColor = Color.FromHex("#888");
        }

        private void PostList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            PostList.SelectedItem = null;
        }

        private async void PostList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {

                var Item = e.Item as PostItems;

                if (Item.Label == AppResources.Label_Pick_Take_Photo)
                {
                    var action = await DisplayActionSheet(AppResources.Label_Photo, AppResources.Label_Cancel, null, AppResources.Label_Choose_from_Galery, AppResources.Label_Take_a_Picture);
                    if (action == AppResources.Label_Choose_from_Galery)
                    {
                        await CrossMedia.Current.Initialize();
                        if (!CrossMedia.Current.IsPickPhotoSupported)
                        {
                            await DisplayAlert("Oops", "You Cannot pick an image", AppResources.Label_OK);
                            return;
                        }
                        var file = await CrossMedia.Current.PickPhotoAsync();

                        if (file == null)
                            return;

                            ActivityList.IsVisible = true;
                            if (ActivityListItems.Count() > 0)
                            {
                                ActivityListItems.Clear();
                            }

                            ActivityListItems.Add(new Activitytems()
                            {
                                Label = file.Path.Split('/').Last(),
                                Icon = "\uf030",
                                TypePost = "Image",
                                Stream = file.GetStream()
                                ,
                                Filepath = file.Path
                            });

                            ActivityList.ItemsSource = ActivityListItems;

                    }
                    else if(action == AppResources.Label_Take_a_Picture)
                    {
                        await CrossMedia.Current.Initialize();

                        if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                        {
                            await DisplayAlert("No Camera", ":( No camera avaialble.", AppResources.Label_OK);
                            return;
                        }
                        var time = DateTime.Now.ToString("hh:mm");
                        var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                        {
                            PhotoSize = PhotoSize.Medium,
                            CompressionQuality = 92,
                            SaveToAlbum = true,
                            Name = time + "Picture.jpg",
                             
                        });

                        if (file == null)
                            return;

                        ActivityList.IsVisible = true;
                        if (ActivityListItems.Count() > 0)
                        {
                            ActivityListItems.Clear();
                        }

                        ActivityListItems.Add(new Activitytems()
                        {
                            Label = file.Path.Split('/').Last(),
                            Icon = "\uf030",
                            TypePost = "Image",
                            Stream = file.GetStream(),
                            Filepath= file.Path
                        });

                        ActivityList.ItemsSource = ActivityListItems;
                    }
                   
                }
                else if (Item.Label == AppResources.Label_Pick_Video_Recourd)
                {
                    try
                    {
                        var action = await DisplayActionSheet(AppResources.Label_Video, AppResources.Label_Cancel, null, AppResources.Label_Choose_from_Galery, AppResources.Label_Recourd_Video);
                        

                        if (action== AppResources.Label_Choose_from_Galery)
                        {
                            if (CrossMedia.Current.IsPickVideoSupported)
                            {
                                var file = await CrossMedia.Current.PickVideoAsync();
                                if (file == null)
                                    return;

                                if (file.GetStream() != null)
                                {
                                    ActivityList.IsVisible = true;
                                    if (ActivityListItems.Count() > 0)
                                    {
                                        ActivityListItems.Clear();
                                    }

                                    ActivityListItems.Add(new Activitytems()
                                    {
                                        Label = file.Path.Split('/').Last(),
                                        Icon = "\uf03d",
                                        TypePost = "Video",
                                        Stream = file.GetStream(),
                                        Filepath = file.Path
                                    });

                                    ActivityList.ItemsSource = ActivityListItems;
                                }
                            }
                        }
                        else if(action == AppResources.Label_Recourd_Video)
                        {
                            await CrossMedia.Current.Initialize();

                            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakeVideoSupported)
                            {
                                await DisplayAlert("No Camera", ":( No camera avaialble.", AppResources.Label_OK);
                                return;
                            }

                            var file = await CrossMedia.Current.TakeVideoAsync(new Plugin.Media.Abstractions.StoreVideoOptions
                            {
                                Name = "video.mp4",
                                Directory = "DefaultVideos",
                                SaveToAlbum = true
                            });

                            if (file == null)
                                return;

                            if (file.GetStream() != null)
                            {
                                ActivityList.IsVisible = true;
                                if (ActivityListItems.Count() > 0)
                                {
                                    ActivityListItems.Clear();
                                }

                                ActivityListItems.Add(new Activitytems()
                                {
                                    Label = file.Path.Split('/').Last(),
                                    Icon = "\uf03d",
                                    TypePost = "Video",
                                    Stream = file.GetStream(),
                                    Filepath = file.Path
                                });

                                ActivityList.ItemsSource = ActivityListItems;
                            }
                        }
                        

                       
                    }
                    catch
                    {

                    }
                }
                else if (Item.Label == AppResources.Label_Feeling_Activity)
                {
                    var action = await DisplayActionSheet(AppResources.Label_Add, AppResources.Label_Cancel, null, AppResources.Label_Your_Feeling, AppResources.Label_Your_Activity);

                    if (action == AppResources.Label_Your_Feeling)
                    {
                        FeelingsPage Feelings_Page = new FeelingsPage();
                        await Navigation.PushAsync(Feelings_Page);
                    }
                    else if(action == AppResources.Label_Your_Activity)
                    {
                        ActivitiesPage Activities_Page = new ActivitiesPage();
                        await Navigation.PushAsync(Activities_Page);
                    }
                }
                else if (Item.Label == AppResources.Label_Mention_Friend)
                {
                    
                   await Navigation.PushAsync(new UsersTagPage());
                    
                }

            }
            catch (Exception)
            {

            }
        }

        private async void PostButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                var PrivacyPost = PrivacyAddPostPage.PrivacyListItemsCollection.FirstOrDefault(a => a.Checkicon == "\uf058");
                if (PrivacyPost != null)
                {
                        if (PostContent.Text == "" && ActivityListItems.Count==0)
                        {
                            UserDialogs.Instance.Alert(AppResources.Label_You_Cannot_Post_an_Empty_Post, AppResources.Label_Error);
                        }
                        else
                        {
                             if (PostContent.Text != "" && ActivityListItems.Count == 0)
                             {
                               await AddPostFunction(PostContent.Text, PrivacyPost.value, "", "");
                               await Navigation.PopAsync(false);
                             }

                            foreach (var Item in ActivityListItems)
                            {
                                if (Item.TypePost == "Traveling")
                                {
                                   
                                    await AddPostFunction(PostContent.Text, PrivacyPost.value, "traveling", Item.Content);
                                    ActivityListItems.Clear();
                                    await Navigation.PopAsync(false);
                                    return;
                                }
                                if (Item.TypePost == "Watching")
                                {
                                    await AddPostFunction(PostContent.Text, PrivacyPost.value, "watching", Item.Content);
                                    ActivityListItems.Clear();
                                    await Navigation.PopAsync(false);
                                    return;
                                }
                                if (Item.TypePost == "Playing")
                                {
                                await AddPostFunction(PostContent.Text, PrivacyPost.value, "playing", Item.Content);
                                    ActivityListItems.Clear();
                                await Navigation.PopAsync(false);
                                    return;
                                }
                                if (Item.TypePost == "Listening")
                                {
                                    await AddPostFunction(PostContent.Text, PrivacyPost.value, "Listening", Item.Content);
                                    ActivityListItems.Clear();
                                    await Navigation.PopAsync(false);
                                    return;
                                }
                                if (Item.TypePost == "Feelings")
                                {
                                await AddPostFunction(PostContent.Text, PrivacyPost.value, "feelings", Item.Content);
                                ActivityListItems.Clear();
                                await Navigation.PopAsync(false);
                                return;
                                }

                              if (Item.TypePost == "Image")
                              {
                                UserDialogs.Instance.Toast(AppResources.Label_Uploading_Image_started);
                                DependencyService.Get<IMethods>().AddPost(Item.Stream, Item.Filepath, PostContent.Text, PrivacyPost.value,"Image", Page);
                                  ActivityListItems.Clear();
                                await Navigation.PopAsync(false);
                                  return;
                              }

                            if (Item.TypePost == "Video")
                            {
                                UserDialogs.Instance.Toast(AppResources.Label_Uploading_Video_started);
                                DependencyService.Get<IMethods>().AddPost(Item.Stream, Item.Filepath, PostContent.Text, PrivacyPost.value,"Video", Page);
                                ActivityListItems.Clear();
                                await Navigation.PopAsync(false);
                                return;
                            }
                            if (Item.TypePost== "Mention")
                            {
                                var Gettag = ActivityListItems.FirstOrDefault(a => a.Label.Contains("Mention"));
                                var Content = PostContent.Text + " " + Gettag.Content;
                                await AddPostFunction(Content, PrivacyPost.value, "", Item.Content);
                                ActivityListItems.Clear();
                                await Navigation.PopAsync(false);
                                return;
                            }
                        }
                           
                        
                    }
                    }
                }
            
            else
            {
                UserDialogs.Instance.ShowError(AppResources.Label_Post_Faild, 2000);
            }
            
        }

       
        public async Task AddPostFunction(string TextContent, string Privacy, string feeling_type, string feeling)
        {
            try
            {
               
                using (var client = new HttpClient())
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Posting, MaskType.Clear);

                    var formContent = new FormUrlEncodedContent(new[]
                    {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("postText",TextContent),
                    new KeyValuePair<string, string>("s", Settings.Session),
                    new KeyValuePair<string, string>("postPrivacy", Privacy),
                    new KeyValuePair<string, string>("feeling_type", feeling_type),
                    new KeyValuePair<string, string>("feeling", feeling),

                });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=new_post", formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        if (Page != null)
                        {
                            Page.PostAjaxRefresh("");
                        }
                        UserDialogs.Instance.ShowSuccess(AppResources.Label_Post_Added, 2000);

                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        UserDialogs.Instance.ShowError(AppResources.Label_Post_Faild, 2000);
                    }
                }
            }
            catch (Exception)
            {

                UserDialogs.Instance.HideLoading();
            }


        }
        private void ActivityList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ActivityList.SelectedItem = null;
        }

        private async void ActivityList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var item = e.Item as Activitytems;
            var Function = await DisplayAlert(AppResources.Label_Question, AppResources.Label_Request_removed, AppResources.Label_NO, AppResources.Label_Yes);
            if (Function)
            { 
            }
            else
            {
                ActivityListItems.Clear();
            }

        }

        private async void PrivacyToolBar_OnClicked(object sender, EventArgs e)
        {
            PrivacyAddPostPage PrivacyAddPost_Page = new PrivacyAddPostPage();
            await Navigation.PushAsync(PrivacyAddPost_Page);
        }

        private void AddPost_OnDisappearing(object sender, EventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }
    }
}


