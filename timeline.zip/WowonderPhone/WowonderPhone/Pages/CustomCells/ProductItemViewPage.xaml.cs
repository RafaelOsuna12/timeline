﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Pages.Timeline_Pages;
using Xamarin.Forms;

namespace WowonderPhone.Pages.CustomCells
{
    public partial class ProductItemViewPage : ContentPage
    {

        public ProductItemViewPage()
        {
            InitializeComponent();
        }

        private async void OnImageTapped(Object sender, EventArgs e)
        {
            try
            {
                var imagePreview = new ImageFullScreenPage((sender as Image).Source);
                await Navigation.PushModalAsync(new NavigationPage(imagePreview));
            }
            catch (Exception)
            {
            }

        }

        private void Button_OnClicked(object sender, EventArgs e)
        {
            try
            {
                var mi = ((Button)sender);
                Navigation.PushAsync(new UserProfilePage(mi.CommandParameter.ToString(),"" ));
            }
            catch (Exception)
            {            
            }
          

        }

        private void ProductItemViewPage_OnAppearing(object sender, EventArgs e)
        {
            if (ManufacturerLabel.Text == "BY You")
            {
                ButtonContact.IsVisible = false;
            }
        }
    }
}
