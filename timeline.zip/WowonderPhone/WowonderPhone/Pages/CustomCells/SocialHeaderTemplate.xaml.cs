﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace WowonderPhone.Pages.CustomCells
{
    public partial class SocialHeaderTemplate : ContentView
    {
        public SocialHeaderTemplate()
        {
            InitializeComponent();
        }

        public object IconText
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }
    }
}
