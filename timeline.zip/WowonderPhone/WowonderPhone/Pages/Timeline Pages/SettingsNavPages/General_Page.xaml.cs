﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Classes;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.SettingsNavPages
{
    public partial class General_Page : ContentPage
    {
        

        public General_Page()
        {
            InitializeComponent();

           
        }

       
    }
}
