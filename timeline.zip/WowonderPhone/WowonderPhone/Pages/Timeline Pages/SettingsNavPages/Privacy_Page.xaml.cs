﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.SettingsNavPages
{
    public partial class Privacy_Page : ContentPage
    {
        public int WhoCanMessageMePicker_E = 0;
        public int WhoCanFollowMe_E = 0;
        public int WhoCanSeeMyBirthday_E = 0;

        public Privacy_Page()
        {
            InitializeComponent();
            StyleChanger();

            using (var DataLoader = new PrivacyFunctions())
            {
                var data = DataLoader.GetPrivacyDBCredentialsById(Settings.User_id);
                if (data != null)
                {
                    WhocamessagemePicker.SelectedIndex = data.WhoCanMessageMe;
                    Whocanfollowme.SelectedIndex = data.WhoCanFollowMe;
                    Whocanseemybirthday.SelectedIndex = data.WhoCanSeeMyBirday;

                    //>>>>>>>>
                    WhoCanMessageMePicker_E = data.WhoCanMessageMe;
                    WhoCanFollowMe_E = data.WhoCanFollowMe;
                    WhoCanSeeMyBirthday_E = data.WhoCanSeeMyBirday;
                    //>>>>>>>>
                }
                else
                {
                    WhocamessagemePicker.SelectedIndex = 0;
                    Whocanfollowme.SelectedIndex = 0;
                    Whocanseemybirthday.SelectedIndex = 0;
                }

            }
        }

        public void StyleChanger()
        {
            FolowOrFriendLabel.Text = AppResources.Label_WhoCan_Follow_me;
            WhoCanSeemybirthdaylabel.Text = AppResources.Label_WhoCan_See_my_Birthday;
            WhoCanmessgamelabel.Text = AppResources.Label_WhoCan_Message_me;

            if (Settings.ConnectivitySystem == "0")
            {
                FolowOrFriendLabel.Text = AppResources.Label_WhoCan_Add_me;
            }
        }

        private async void PrivacyPage_OnDisappearing(object sender, EventArgs e)
        {
            try
            {
                if (WhoCanFollowMe_E != Whocanfollowme.SelectedIndex ||
                    WhoCanMessageMePicker_E != WhocamessagemePicker.SelectedIndex ||
                    WhoCanSeeMyBirthday_E != Whocanseemybirthday.SelectedIndex)
                {
                    var device = Resolver.Resolve<IDevice>();
                    var oNetwork = device.Network; // Create Interface to Network-functions
                    var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                    if (xx == true)
                    {
                        await DisplayAlert(AppResources.Label_Error, AppResources.Label_CheckYourInternetConnection, AppResources.Label_OK);
                    }
                    else
                    {
                        #region Send Data 

                        using (var client = new HttpClient())
                        {
                            var Passwords = new Dictionary<string, string>
                        {
                            {"message_privacy", WhocamessagemePicker.SelectedIndex.ToString()},
                            {"follow_privacy", Whocanfollowme.SelectedIndex.ToString()},
                            {"birth_privacy", Whocanseemybirthday.SelectedIndex.ToString()}
                        };

                            string Pass = JsonConvert.SerializeObject(Passwords);
                            var formContent = new FormUrlEncodedContent(new[]
                            {
                            new KeyValuePair<string, string>("user_id", Settings.User_id),
                            new KeyValuePair<string, string>("type", "privacy_settings"),
                            new KeyValuePair<string, string>("s", Settings.Session),
                            new KeyValuePair<string, string>("user_data", Pass)
                        });

                            var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=update_user_data", formContent);
                            response.EnsureSuccessStatusCode();
                            string json = await response.Content.ReadAsStringAsync();
                            var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                            string apiStatus = data["api_status"].ToString();
                            if (apiStatus == "200")
                            {

                                using (var DataLoader = new PrivacyFunctions())
                                {
                                    var ID = DataLoader.GetPrivacyDBCredentialsById(Settings.User_id);
                                    if (ID != null)
                                    {
                                        DataLoader.UpdatePrivacyDBCredentials(new PrivacyDB()
                                        {
                                            UserID = Settings.User_id,
                                            WhoCanSeeMyBirday = Whocanseemybirthday.SelectedIndex,
                                            WhoCanFollowMe = Whocanfollowme.SelectedIndex,
                                            WhoCanMessageMe = WhocamessagemePicker.SelectedIndex
                                        });
                                    }
                                    else
                                    {
                                        DataLoader.InsertPrivacyDBCredentials(new PrivacyDB()
                                        {
                                            UserID = Settings.User_id,
                                            WhoCanSeeMyBirday = Whocanseemybirthday.SelectedIndex,
                                            WhoCanFollowMe = Whocanfollowme.SelectedIndex,
                                            WhoCanMessageMe = WhocamessagemePicker.SelectedIndex
                                        });
                                    }
                                }
                            }
                            else
                            {

                            }
                        }
                    }

                    #endregion
                }
            }
            catch (Exception)
            {

            }
        }
    }
}
