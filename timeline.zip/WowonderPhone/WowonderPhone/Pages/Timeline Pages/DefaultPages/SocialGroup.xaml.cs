﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xam.Plugin.Abstractions.Events.Inbound;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class SocialGroup : ContentPage
    {

        public class GroupInfoitems
        {
            public string Label { get; set; }
            public string Icon { get; set; }
            public string Color { get; set; }
        }

        public static ObservableCollection<GroupInfoitems> GroupInfoListItems = new ObservableCollection<GroupInfoitems>();

        public static string G_GroupID = "";
        public static string S_Name = "";
        public static string S_Username = "";
        public static string S_Category = "";
        public static string S_About = "";
        public static string S_URL = "";
        public static string S_Cover = "";
        public static string S_Avatar = "";
        public static string S_Group_Title = "";

        public SocialGroup(string GroupID, string GroupType)
        {
           

            InitializeComponent();
            G_GroupID = GroupID;

            if (GroupType == "Joined")
            {
                ActionButton.Text = AppResources.Label_Joined;
            }
            else
            {
                ActionButton.Text = AppResources.Label_Join_Group;
            }
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                GetGroupData(GroupID).ConfigureAwait(false);
                PostWebLoader.Source = Settings.Website + "/get_news_feed?group_id=" + GroupID;
                PostWebLoader.OnJavascriptResponse += OnJavascriptResponse;
                PostWebLoader.RegisterCallback("type", (str) => { });
            }
            else
            {
                this.Title = AppResources.Label_Connection_Lost;
                //PostWebLoader.Source = Settings.HTML_LoadingPost_Page;
            }
        }

        public static async Task<string> AddUnAddRequest(string GroupID)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("group_id", GroupID),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=join_group",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        return "Succes";

                    }
                }
            }
            catch (Exception)
            {

            }
            return null;

        }

        public async Task<string> GetGroupData(string Pageid)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                     {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("group_profile_id",Pageid),
                    new KeyValuePair<string, string>("s",Settings.Session)
                 });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_group_data", formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        JObject userdata = JObject.FromObject(data["group_data"]);
                        var group_id = userdata["group_id"].ToString();
                        var group_name = userdata["group_name"].ToString();
                        S_Group_Title = userdata["group_title"].ToString();
                        S_Avatar = userdata["avatar"].ToString();
                        S_Cover = userdata["cover"].ToString();
                        S_Name = userdata["name"].ToString();
                        S_Username = userdata["username"].ToString();
                        S_Category = userdata["category"].ToString();
                        S_URL = userdata["url"].ToString();
                        var Isjoined =userdata["is_joined"].ToString();
                        
                        S_About = System.Net.WebUtility.HtmlDecode(userdata["url"].ToString());
                        GroupTitle.Text = S_Group_Title;
                        AboutMini.Text = S_Category;

                        if (Isjoined == "True")
                        {
                            ActionButton.Text = AppResources.Label_Joined;
                        }




                        var Post_Count = userdata["post_count"].ToString();
                        if (Post_Count == "0")
                        {
                            ButtonStacklayot.IsVisible = false;
                            PostWebLoader.HeightRequest = 230;
                        }
                        else if (Post_Count == "1")
                        {
                            PostWebLoader.HeightRequest = 260;
                        }
                        else if (Post_Count == "2")
                        {
                            PostWebLoader.HeightRequest = 570;
                        }

                        else if (Post_Count == "3")
                        {
                            PostWebLoader.HeightRequest = 740;
                        }
                        else if (Post_Count == "4")
                        {
                            PostWebLoader.HeightRequest = 950;
                        }
                        else if (Post_Count == "5")
                        {
                            PostWebLoader.HeightRequest = 1150;
                        }
                        else if (Post_Count == "6")
                        {
                            PostWebLoader.HeightRequest = 1350;
                        }
                        else if (Post_Count == "7")
                        {
                            PostWebLoader.HeightRequest = 1550;
                        }
                        else if (Post_Count == "8")
                        {
                            PostWebLoader.HeightRequest = 1850;
                        }
                        CoverImage.Source = new UriImageSource { Uri = new Uri(S_Cover) };
                        AvatarImage.Source = new UriImageSource { Uri = new Uri(S_Avatar) };
                        if (S_About == "")
                        {
                            GroupInfoListItems.Add(new GroupInfoitems()
                            {
                                Label = AppResources.Label_No_Description,
                                Icon = "\uf0a1",
                                Color = "#c5c9c8"
                            });
                        }
                        else if (S_About != "")
                        {
                            if (S_About.Length > 30)
                            {
                                GroupInfoList.HeightRequest = 45;
                                GroupInfoList.MinimumHeightRequest = 45;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }
                            if (S_About.Length > 60)
                            {
                                GroupInfoList.HeightRequest = 65;
                                GroupInfoList.MinimumHeightRequest = 65;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }
                            if (S_About.Length > 150)
                            {
                                GroupInfoList.HeightRequest = 75;
                                GroupInfoList.MinimumHeightRequest = 75;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }
                            if (S_About.Length > 250)
                            {
                                GroupInfoList.HeightRequest = 105;
                                GroupInfoList.MinimumHeightRequest = 100;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }

                            if (S_About.Length > 350)
                            {
                                GroupInfoList.HeightRequest = 145;
                                GroupInfoList.MinimumHeightRequest = 130;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }

                            if (S_About.Length > 450)
                            {
                                GroupInfoList.HeightRequest = 165;
                                GroupInfoList.MinimumHeightRequest = 140;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }

                            if (S_About.Length > 550)
                            {
                                GroupInfoList.HeightRequest = 195;
                                GroupInfoList.MinimumHeightRequest = 170;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }

                            if (S_About.Length > 650)
                            {
                                GroupInfoList.HeightRequest = 210;
                                GroupInfoList.MinimumHeightRequest = 170;
                                GroupInfoListItems.Add(new GroupInfoitems()
                                {
                                    Label = S_About,
                                    Icon = "\uf0a1",
                                    Color = "#c5c9c8"
                                });
                            }

                        }
                       



                        GroupInfoList.ItemsSource = GroupInfoListItems;
                        this.Title = S_Name;

                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }
                    return json;
                }
            }
            catch (Exception)
            {

                return AppResources.Label_Error;
            }

        }

        private void CopyUrlButton_OnClicked(object sender, EventArgs e)
        {
            DependencyService.Get<IClipboardService>().CopyToClipboard(S_URL);
        }

        private void GroupInfoList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            GroupInfoList.SelectedItem = null;
        }

        private void GroupInfoList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
           
        }

        private  void ActionButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (ActionButton.Text == AppResources.Label_Join_Group)
                {
                    ActionButton.Text = AppResources.Label_Joined;
                    using (var data = new CommunitiesFunction())
                    {
                        if (G_GroupID != "" && S_URL != "")
                        {
                            DependencyService.Get<IPicture>().SavePictureToDisk(S_Avatar, G_GroupID);
                            data.InsertCommunities(new CommunitiesDB()
                            {
                                CommunityID = G_GroupID,
                                CommunityName = S_Group_Title,
                                CommunityPicture = S_Avatar,
                                CommunityType = AppResources.Label_Groups,
                                CommunityUrl = S_URL
                            });
                        }

                    }
                }
                else if (ActionButton.Text == AppResources.Label_Joined)
                {
                    ActionButton.Text = AppResources.Label_Join;
                    using (var data = new CommunitiesFunction())
                    {
                        var Community = data.GetCommunityByID(G_GroupID);
                        if (Community.CommunityID != "")
                        {
                            if (Community.CommunityID != null)
                            {
                                DependencyService.Get<IPicture>()
                                    .DeletePictureFromDisk(Community.CommunityPicture, Community.CommunityID);
                                data.DeleteCommunitiesRow(Community);
                            }
                        }
                    }
                }

                AddUnAddRequest(G_GroupID).ConfigureAwait(false);
            }
            else
            {
                DisplayAlert(AppResources.Label_Error, AppResources.Label_CheckYourInternetConnection, AppResources.Label_OK);
            }
           
        }

        private void SocialGroup_OnDisappearing(object sender, EventArgs e)
        {
            GroupInfoListItems.Clear();
        }

        private void ShowmoreButton_OnClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new HyberdPostViewer("Group",""));
        }

        private void OnJavascriptResponse(JavascriptResponseDelegate EventObj)
        {

            if (EventObj.Data.Contains("type"))
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(EventObj.Data);
                string type = data["type"].ToString();
                if (type == "user")
                {
                    string Userid = data["profile_id"].ToString();
                    if (WowonderPhone.Settings.User_id == Userid)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Navigation.PushAsync(new MyProfilePage());
                        });
                    }
                    else
                    {
                        InjectedJavaOpen_UserProfile(Userid);
                    }

                }
                else if (type == "lightbox")
                {
                    string ImageSource = data["image_url"].ToString();
                    var Image = new UriImageSource
                    {
                        Uri = new Uri(ImageSource),
                        CachingEnabled = true,
                        CacheValidity = new TimeSpan(2, 0, 0, 0)
                    };
                    InjectedJavaOpen_OpenImage(Image);
                }
                else if (type == "mention")
                {
                    string user_id = data["user_id"].ToString();
                    InjectedJavaOpen_UserProfile(user_id);
                }
                else if (type == "hashtag")
                {
                    string hashtag = data["hashtag"].ToString();

                    InjectedJavaOpen_OpenImage(hashtag);
                }
                else if (type == "url")
                {
                    string link = data["link"].ToString();

                    InjectedJavaOpen_PostLinks(link);
                }
                else if (type == "page")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_LikePage(Id);
                }
                else if (type == "group")
                {
                    string Id = data["profile_id"].ToString();

                    if (G_GroupID != Id)
                    {
                        InjectedJavaOpen_Group(Id);
                    }
                    
                }
                else if (type == "post_wonders" || type == "post_likes")
                {
                    string Id = data["post_id"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Like_Wonder_Viewer_Page(Id, type));
                    });
                }
            }

        }
        public void InjectedJavaOpen_UserProfile(string Userid)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new UserProfilePage(Userid, ""));
            });
        }
        public void InjectedJavaOpen_OpenImage(ImageSource Image)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushModalAsync(new ImageFullScreenPage(Image));
            });
        }
        public void InjectedJavaOpen_PostLinks(string link)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Device.OpenUri(new Uri(link));
            });
        }
        public void InjectedJavaOpen_Hashtag(string word)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new HyberdPostViewer("Hashtag", word));
            });
        }
        public void InjectedJavaOpen_LikePage(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialPageViewer(id, "", ""));
            });
        }
        public void InjectedJavaOpen_Group(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialGroup("id", ""));
            });
        }
    

        private void PostWebLoader_OnOnNavigationError(NavigationErrorDelegate eventobj)
        {
            try
            {

                PostWebLoader.IsVisible = false;
                UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost);
            }
            catch (Exception e)
            {

            }
        }

        private void PostWebLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            PostWebLoader.RegisterCallback("type", (str) => { });
        }

        private NavigationRequestedDelegate PostWebLoader_OnOnNavigationStarted(NavigationRequestedDelegate eventobj)
        {
            if (eventobj.Uri.Contains(WowonderPhone.Settings.Website))
            {
                return eventobj;
            }
            else
            {
                eventobj.Cancel = true;
                return eventobj;
            }
        }
    }
}


//JSON WOWONDER SCRIPT RESPONE
//>>>>>>>>>>>>
//{
//    "api_status": "200",
//    "api_text": "success",
//    "api_version": "1.4.1",
//    "group_data": {
//        "user_id": "8052",
//        "group_name": "Grouptesting",
//        "group_title": "Group Testing",
//        "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/10\/9yDj635NjSEVNfnfm3kK_02_a6e0a727790e2fa721f169ac8fbd3f72_avatar.jpg",
//        "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/10\/zIXV3Mb9QGqOUp3ZSQDq_02_a6e0a727790e2fa721f169ac8fbd3f72_cover.jpg",
//        "about": "This is for testing the ability of the script to see how it creates groups.",
//        "category": "Entertainment",
//        "privacy": "2",
//        "join_privacy": "2",
//        "active": "1",
//        "registered": "10\/2016",
//        "group_id": "213",
//        "url": "https:\/\/demo.wowonder.com\/Grouptesting",
//        "name": "Group Testing",
//        "category_id": "6",
//        "username": "Grouptesting"
//    }
//}
//>>>>>>>>>>>>>>>