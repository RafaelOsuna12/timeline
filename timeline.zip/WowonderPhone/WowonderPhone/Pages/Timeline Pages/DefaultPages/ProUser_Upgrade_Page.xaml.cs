﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class ProUser_Upgrade_Page : ContentPage
    {
        public ProUser_Upgrade_Page()
        {
            InitializeComponent();

        }

        private void UpgradeButtonClicked(object sender, EventArgs e)
        {
            try
            {
                Device.OpenUri(new Uri(Settings.Website + "/go-pro"));
            }
            catch (Exception)
            {
                
            }
           
        }
    }
}
