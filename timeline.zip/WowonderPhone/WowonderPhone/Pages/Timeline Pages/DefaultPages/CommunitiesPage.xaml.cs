﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Classes;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class CommunitiesPage : ContentPage
    {
        public static ObservableCollection<Communities> CommunitiesListItems = new ObservableCollection<Communities>();

        public CommunitiesPage()
        {
            InitializeComponent();
            LoadCommunitiesFromCash();
        }
        
        public void LoadCommunitiesFromCash()
        {
            try
            {
                using (var data = new CommunitiesFunction())
                {
                    var Data = data.GetCommunityCacheList();
                    if (Data.Count > 0)
                    {
                        CommunitiesListview.ItemsSource = data.GetCommunityCacheList();
                    }
                    else
                    {
                        var device = Resolver.Resolve<IDevice>();
                        var oNetwork = device.Network; // Create Interface to Network-functions
                        var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                        if (!xx)
                        {
                            UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
                            GetCommunities().ConfigureAwait(false);
                        }
                        else
                        {
                            UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection, 2000);
                        }
                    }

                }
            }
            catch (Exception e)
            {

            }

        }

        private void Search_OnClicked(object sender, EventArgs e)
        {
            if (SearchFrame.IsVisible)
            {
                SearchFrame.IsVisible = false;
            }
            else
            {
                SearchFrame.IsVisible = true;
            }
        }

        private void SearchBarCo_OnSearchButtonPressed(object sender, EventArgs e)
        {
            try
            {
                using (var data = new CommunitiesFunction())
                {
                    data.GetCommunitySearchList(SearchBarCo.Text);
                }
            }
            catch (Exception)
            {
                
            }
        }

        private void SearchBarCo_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                using (var data = new CommunitiesFunction())
                {
                    data.GetCommunitySearchList(SearchBarCo.Text);
                }
            }
            catch (Exception)
            {

            }
        }

        private void CommunitiesListview_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            CommunitiesListview.SelectedItem = null;
        }

        private void CommunitiesListview_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {
                var Item = e.Item as Communities;
                if (Item.CommunityType == AppResources.Label_Groups)
                {
                    Navigation.PushAsync(new SocialGroup(Item.CommunityID, "Joined"));
                }
                else if (Item.CommunityType == AppResources.Label_Pages)
                {
                    Navigation.PushAsync(new SocialPageViewer(Item.CommunityID, Item.CommunityName, "Liked"));
                }
            }
            catch (Exception)
            {
            }
            
          
        }

        public async Task<string> GetCommunities()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                     {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("user_profile_id",Settings.User_id),
                    new KeyValuePair<string, string>("s",Settings.Session)
                 });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_my_community", formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var Page = JObject.Parse(json).SelectToken("pages").ToString();
                        JArray PagedataArray = JArray.Parse(Page);

                        foreach (var PageItem in PagedataArray)
                        {

                            var page_id = PageItem["page_id"].ToString();
                            var page_name = PageItem["page_name"].ToString();
                            var page_title = PageItem["page_title"].ToString();
                            var avatar = PageItem["avatar"].ToString();
                            var about = PageItem["about"].ToString();
                            var url = PageItem["url"].ToString();
                            var category = PageItem["category"].ToString();

                            var Imagepath = DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, page_id);
                            var ImageMediaFile = ImageSource.FromFile(Imagepath);

                            if (Imagepath == "File Dont Exists")
                            {
                                ImageMediaFile = new UriImageSource { Uri = new Uri(avatar) };
                                DependencyService.Get<IPicture>().SavePictureToDisk(avatar, page_id);
                            }

                            var Cheke = CommunitiesListItems.FirstOrDefault(a => a.CommunityID == page_id);
                            if (CommunitiesListItems.Contains(Cheke))
                            {
                                if (Cheke.CommunityName != page_name)
                                {
                                    Cheke.CommunityName = page_name;
                                }
                                if (Cheke.ImageUrlString != avatar)
                                {
                                    Cheke.CommunityPicture = new UriImageSource {Uri = new Uri(avatar)};
                                }

                            }
                            else
                            {
                                CommunitiesListItems.Add(new Communities()
                                {
                                    CommunityID = page_id,
                                    CommunityName = page_name,
                                    CommunityType = AppResources.Label_Pages,
                                    CommunityPicture = ImageMediaFile,
                                    ImageUrlString = avatar
                                });
                            }
                          

                            using (var CO_Data = new CommunitiesFunction())
                            {
                                var Community = CO_Data.GetCommunityByID(page_id);
                                if (Community != null)
                                {
                                    if (Community.CommunityID == page_id && (Community.CommunityName!= page_name || Community.CommunityPicture != avatar || Community.CommunityUrl != url))
                                    {
                                        Community.CommunityName = page_name;
                                        Community.CommunityPicture = avatar;
                                        Community.CommunityUrl = url;
                                        Community.CommunityID = page_id;

                                        CO_Data.UpdateCommunities(Community);
                                    }
                                }
                                else
                                {
                                    CO_Data.InsertCommunities(new CommunitiesDB()
                                    {
                                        CommunityID = page_id,
                                        CommunityName = page_name,
                                        CommunityPicture = avatar,
                                        CommunityType = AppResources.Label_Pages,
                                        CommunityUrl = url
                                    });
                                }
                            }
                     }

                        var Group = JObject.Parse(json).SelectToken("groups").ToString();
                        JArray GroupdataArray = JArray.Parse(Group);


                        if (GroupdataArray.Count <= 0 && PagedataArray.Count <= 0 )
                        {
                            UserDialogs.Instance.HideLoading();
                            UserDialogs.Instance.ShowError(AppResources.Label_Community_Empty, 2000);
                            return "emety";
                        }
                        else
                        {
                            foreach (var GroupItem in GroupdataArray)
                            {

                                var group_id = GroupItem["group_id"].ToString();
                                var group_name = GroupItem["group_name"].ToString();
                                var group_title = GroupItem["group_name"].ToString();
                                var avatar = GroupItem["avatar"].ToString();
                                var about = GroupItem["about"].ToString();
                                var url = GroupItem["url"].ToString();
                                var category = GroupItem["category"].ToString();

                                var Imagepath = DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, group_id);
                                var ImageMediaFile = ImageSource.FromFile(Imagepath);
                                
                                if (Imagepath == "File Dont Exists")
                                {
                                    ImageMediaFile = new UriImageSource { Uri = new Uri(avatar) };
                                    DependencyService.Get<IPicture>().SavePictureToDisk(avatar, group_id);
                                }
                                var Cheke = CommunitiesListItems.FirstOrDefault(a => a.CommunityID == group_id);
                                if (CommunitiesListItems.Contains(Cheke))
                                {
                                    if (Cheke.CommunityName != group_name)
                                    {
                                        Cheke.CommunityName = group_name;
                                    }
                                    if (Cheke.ImageUrlString != avatar)
                                    {
                                        Cheke.CommunityPicture = new UriImageSource {Uri = new Uri(avatar)};
                                    }

                                }
                                else
                                {
                                    CommunitiesListItems.Add(new Communities()
                                    {
                                        CommunityID = group_id,
                                        CommunityName = group_name,
                                        CommunityType = AppResources.Label_Groups,
                                        CommunityPicture = ImageMediaFile,
                                        ImageUrlString = avatar
                                    });
                                }
                               
                              
                                using (var CO_Data = new CommunitiesFunction())
                                {
                                    var Community = CO_Data.GetCommunityByID(group_id);
                                    if (Community != null)
                                    {
                                        if (Community.CommunityID == group_id && (Community.CommunityName != group_name || Community.CommunityPicture != avatar || Community.CommunityUrl != url))
                                        {
                                            Community.CommunityName = group_name;
                                            Community.CommunityPicture = avatar;
                                            Community.CommunityUrl = url;
                                            Community.CommunityID = group_id;
                                            CO_Data.UpdateCommunities(Community);
                                        }
                                    }
                                    else
                                    {
                                        CO_Data.InsertCommunities(new CommunitiesDB()
                                        {
                                            CommunityID = group_id,
                                            CommunityName = group_name,
                                            CommunityPicture = avatar,
                                            CommunityType = AppResources.Label_Groups,
                                            CommunityUrl = url
                                        });
                                    }
                                }
                            }
                           
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else if (apiStatus == "400")
                    {
                        json = AppResources.Label_Error;
                    }
                    return json;
                }
            }
            catch (Exception)
            {
                UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost, 2000);
                return AppResources.Label_Error;
            }

        }

        private void Refresh_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
                GetCommunities().ConfigureAwait(false);
            }
            else
            {
                UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection, 2000);
            }
        }

        private void CommunitiesPage_OnDisappearing(object sender, EventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }
    }
}



//    "api_status": "200",
//    "api_text": "success",
//    "api_version": "1.4.1",
//    "groups": [
//        {
//            "id": "195",
//            "user_id": "7332",
//            "group_name": "TestGroup",
//            "group_title": "Test Group",
//            "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/09\/ZGdfcqi6bPl1hJpsCVBp_25_3d61be36449462c7288b907fe178f333_avatar.jpg",
//            "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/d-cover.jpg  ",
//            "about": "Yep, just another test group to compile a list of things that would be helpful <br> <br>Edit test group: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam ante massa, egestas id justo et, aliquam rutrum mi.  &lt;br&gt; &lt;br&gt;Nunc sit amet nunc porta ante vestibulum porttitor ac sed risus. Quisque feugiat mi erat, a volutpat dolor fermentum nec. Morbi gravida eget nunc eget facilisis.  &lt;br&gt; &lt;br&gt;Proin et sodales purus, non elementum nibh. Morbi venenatis venenatis quam. Proin ut justo rhoncus, molestie dolor vel, rhoncu",
//            "category": "Cars and Vehicles",
//            "privacy": "2",
//            "join_privacy": "2",
//            "active": "1",
//            "registered": "9\/2016",
//            "group_id": "195",
//            "url": "https:\/\/demo.wowonder.com\/TestGroup",
//            "name": "Test Group",
//            "category_id": "2",
//            "type": "group",
//            "username": "TestGroup"
//        },
//    