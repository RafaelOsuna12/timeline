﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Splat;

using WowonderPhone.Controls;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using WowonderPhone.SQLite.Tables;
using Xam.Plugin.Abstractions.Events.Inbound;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class SocialPageViewer : ContentPage
    {

        public class PageInfoitems
        {
            public string Label { get; set; }
            public string Icon { get; set; }
            public string Color { get; set; }
        }

        public static ObservableCollection<PageInfoitems> PageInfoListItems = new ObservableCollection<PageInfoitems>();


        public static string P_PageID = "";
        public static string S_Page_Description = "";
        public static string S_About = "";
        public static string S_Website = "";
        public static string S_Name = "";
        public static string S_Username = "";
        public static string S_Phone = "";
        public static string S_Address = "";
        public static string S_Facebook = "";
        public static string S_Google = "";
        public static string S_Twitter = "";
        public static string S_Linkedin = "";
        public static string S_Youtube = "";
        public static string S_VK = "";
        public static string S_Instagram = "";
        public static string S_Category = "";
        public static string S_Company = "";
        public static string S_URL = "";
        public static string S_Cover = "";
        public static string S_Avatar = "";
        public static string Call_Action_Type_URL = "";
       
        public static string S_Page_Title = "";


        public static string PageType = "";

        public SocialPageViewer(string Pageid,string pagename, string Pagetype)
        {
            P_PageID = Pageid;
            InitializeComponent();
            PageTitle.Text = pagename;
            Call_Action_Type_URL = "";
            PageInfoListItems.Clear();

            if (Pagetype == "Liked")
            {
                PageType = "Liked";
                LikeText.Text = AppResources.Label_Liked;
                LikeImage.Source = Settings.Likecheked_Icon;
            }
            
            AddClickActions();

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                GetPageData(Pageid).ConfigureAwait(false);
                PostWebLoader.Source = Settings.Website + "/get_news_feed?page_id=" + Pageid;
                PostWebLoader.OnJavascriptResponse += OnJavascriptResponse;
                PostWebLoader.RegisterCallback("type", (str) => { });
            }
            else
            {
                this.Title = AppResources.Label_Offline_Mode;
                // PostWebLoader.Source = Settings.HTML_OfflinePost_Page;
            }

        }

        public void AddClickActions()
        {

            var TapFriendGestureRecognizer = new TapGestureRecognizer();
            TapFriendGestureRecognizer.Tapped += (s, ee) =>
            {
                if (LikeText.Text == AppResources.Label_Like)
                {
                    var device = Resolver.Resolve<IDevice>();
                    var oNetwork = device.Network; // Create Interface to Network-functions
                    var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                    if (!xx)
                    {
                        LikeUnlikePageRequest(P_PageID).ConfigureAwait(false);
                        LikeText.Text = AppResources.Label_Liked;
                        LikeImage.Source = Settings.Likecheked_Icon;
                        using (var data = new CommunitiesFunction())
                        {

                            if (P_PageID != "" && S_URL != "")
                            {
                                var Community = data.GetCommunityByID(P_PageID);
                                if (Community != null)
                                {
                                    return;
                                }
                                DependencyService.Get<IPicture>().SavePictureToDisk(S_Avatar, P_PageID);
                                data.InsertCommunities(new CommunitiesDB()
                                {
                                    CommunityID = P_PageID,
                                    CommunityName = S_Page_Title,
                                    CommunityPicture = S_Avatar,
                                    CommunityType = AppResources.Label_Pages,
                                    CommunityUrl = S_URL
                                });
                            }

                        }
                    }
                    else
                    {
                        DisplayAlert(AppResources.Label_Error, AppResources.Label_CheckYourInternetConnection, AppResources.Label_OK);
                    }

                }
                else if (LikeText.Text == AppResources.Label_Liked)
                {
                    try
                    {
                        var device = Resolver.Resolve<IDevice>();
                        var oNetwork = device.Network; 
                        var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                        if (!xx)
                        {
                            LikeUnlikePageRequest(P_PageID).ConfigureAwait(false);
                            LikeText.Text = AppResources.Label_Like;
                            LikeImage.Source = Settings.LikePage_Icon;
                            using (var data = new CommunitiesFunction())
                            {
                                var Community = data.GetCommunityByID(P_PageID);
                                if (Community.CommunityID != "")
                                {
                                    if (Community.CommunityID != null)
                                    {
                                        DependencyService.Get<IPicture>()
                                            .DeletePictureFromDisk(Community.CommunityPicture, Community.CommunityID);
                                        data.DeleteCommunitiesRow(Community);
                                    }
                                }
                            }
                        }
                        else
                        {

                            DisplayAlert(AppResources.Label_Error, AppResources.Label_CheckYourInternetConnection, AppResources.Label_OK);
                        }
                          
                    }
                    catch (Exception e)
                    {
                        
                    }
                }
                
            };

            if (LikeText.GestureRecognizers.Count > 0)
            {
                LikeText.GestureRecognizers.Clear();
            }
            if (LikeImage.GestureRecognizers.Count > 0)
            {
                LikeImage.GestureRecognizers.Clear();
            }

            LikeText.GestureRecognizers.Add(TapFriendGestureRecognizer);
            LikeImage.GestureRecognizers.Add(TapFriendGestureRecognizer);
        }

       
        public static async Task<string> LikeUnlikePageRequest(string Pageid)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("page_id", Pageid),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=like_page",
                                formContent).ConfigureAwait(false);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        return "Succes";

                    }
                }
            }
            catch (Exception)
            {

            }
            return null;

        }

        public async Task<string> GetPageData(string Pageid)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                     {
                    new KeyValuePair<string, string>("user_id", Settings.User_id),
                    new KeyValuePair<string, string>("page_profile_id",Pageid),
                    new KeyValuePair<string, string>("s",Settings.Session)
                 });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_page_data", formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        JObject userdata = JObject.FromObject(data["page_data"]);
                        var page_id = userdata["page_id"].ToString();
                        var page_title = userdata["page_title"].ToString();
                        var page_description = userdata["page_description"].ToString();
                        var user_id = userdata["user_id"].ToString();
                        var Website = userdata["website"].ToString();
                        var About = userdata["about"].ToString();
                        var company = userdata["company"].ToString();
                        var Is_Liked = userdata["is_liked"].ToString();

                        var Post_Count = userdata["post_count"].ToString();
                        if (Post_Count == "0")
                        {
                            ButtonStacklayot.IsVisible = false;
                            PostWebLoader.HeightRequest = 220;
                        }
                        else if (Post_Count == "1")
                        {
                            PostWebLoader.HeightRequest = 280;
                        }
                        else if (Post_Count == "2")
                        {
                            PostWebLoader.HeightRequest = 590;
                        }

                        else if (Post_Count == "3")
                        {
                            PostWebLoader.HeightRequest =760;
                        }
                        else if (Post_Count == "4")
                        {
                            PostWebLoader.HeightRequest = 970;
                        }
                        else if (Post_Count == "5")
                        {
                            PostWebLoader.HeightRequest = 1170;
                        }
                        else if (Post_Count == "6")
                        {
                            PostWebLoader.HeightRequest = 1380;
                        }
                        else if (Post_Count == "7")
                        {
                            PostWebLoader.HeightRequest = 1580;
                        }
                        else if (Post_Count == "8")
                        {
                            PostWebLoader.HeightRequest = 1890;
                        }

                        if (Is_Liked == "True")
                        {
                            if(LikeText.Text != AppResources.Label_Liked)
                            {
                                LikeText.Text = AppResources.Label_Liked;
                                LikeImage.Source = Settings.Likecheked_Icon;
                            }
                          
                        }
                        else
                        {
                            if (LikeText.Text != AppResources.Label_Like)
                            {
                                LikeText.Text = AppResources.Label_Like;
                                LikeImage.Source = Settings.LikePage_Icon;
                            }
                        }
                        
                        var Call_action_type_url = userdata["call_action_type_url"].ToString();
                        var Call_action_type = userdata["call_action_type"].ToString();
                        var call_action_type_text = userdata["call_action_type_text"].ToString();
                        if (Call_action_type_url == "")
                        {
                            ActionButton.IsVisible = false;
                        }
                        else
                        {
                            ActionButton.IsVisible = true;
                            Call_Action_Type_URL = Call_action_type_url;
                            ActionButton.Text = call_action_type_text;
                        }
                        S_About = System.Net.WebUtility.HtmlDecode(userdata["about"].ToString());
                        S_Website = userdata["website"].ToString();
                        S_Name = userdata["name"].ToString();
                        S_Username = userdata["username"].ToString();
                        S_Phone = userdata["phone"].ToString();
                        S_Address = userdata["address"].ToString();
                        S_Facebook = userdata["facebook"].ToString();
                        S_Google = userdata["google"].ToString();
                        S_Twitter = userdata["twitter"].ToString();
                        S_Linkedin = userdata["linkedin"].ToString();
                        S_Youtube = userdata["youtube"].ToString();
                        S_VK = userdata["vk"].ToString();
                        S_Instagram = userdata["instgram"].ToString();
                        S_Category = userdata["category"].ToString();
                        S_Page_Description = Functions.DecodeString(page_description);
                        S_Company = company;
                        S_URL= userdata["url"].ToString();
                        S_Page_Title = userdata["page_name"].ToString();
                        S_Avatar = userdata["avatar"].ToString();
                        S_Cover = userdata["cover"].ToString();

                        PageTitle.Text = S_Name;
                        AboutMini.Text = S_Category;

                            CoverImage.Source = new UriImageSource { Uri = new Uri(S_Cover) };
                            AvatarImage.Source = new UriImageSource { Uri = new Uri(S_Avatar) };

                        if (S_Website == "") { S_Website = "............"; }
                        if (S_Page_Description == "")
                        {
                            S_Page_Description = "........";
                        }
                        if (S_Phone == "" || S_Phone.Contains("00"))
                        {
                            S_Phone = AppResources.Label_Askme;
                        }
                        if (S_About == "")
                        {
                            S_About = Settings.PR_AboutDefault;
                        }
                        if (S_Address == "")
                        {
                            S_Address = AppResources.Label_Unavailable;
                        }
                        if (S_Company == "")
                        {
                            S_Company = AppResources.Label_Unavailable;
                        }

                        PageInfoListItems.Add(new PageInfoitems()
                        {
                            Label = S_Page_Description,
                            Icon = "\uf040",
                            Color = "#c5c9c8"
                        });
                        PageInfoListItems.Add(new PageInfoitems()
                        {
                            Label = S_Category,
                            Icon = "\uf0ac",
                            Color = "#c5c9c8"
                        });

                       
                           PageInfoListItems.Add(new PageInfoitems()
                            {
                                Label = S_Website,
                                Icon = "\uf0a1",
                               Color = "#c5c9c8"
                          });
                       

                        PageInfoListItems.Add(new PageInfoitems()
                        {
                            Label = AppResources.Label_Show_More,
                            Icon = "\uf0ca",
                            Color = Settings.MainColor,

                        });


                        if (PageType == AppResources.Label_Liked && (Is_Liked == "False" || Is_Liked == "false"))
                        {
                            using (var database = new CommunitiesFunction())
                            {
                                if (P_PageID != "")
                                {
                                    var Community = database.GetCommunityByID(P_PageID);
                                    if (Community != null)
                                    {
                                        database.DeleteCommunitiesRow(Community);
                                    }
                                }
                            }
                        }
                        PageInfoList.ItemsSource = PageInfoListItems;
                        PageInfoList.HeightRequest = Functions.ListInfoResizer(S_Page_Description);
                        this.Title = S_Name;

                    }
                    else if (apiStatus == "400")
                    {
                        JObject errors = JObject.FromObject(data["errors"]);
                        var errortext = errors["error_text"].ToString();
                       
                            await DisplayAlert(AppResources.Label_Security, AppResources.Label_This_Page_Dont_Exists, AppResources.Label_OK);
                            await Navigation.PopAsync(false);
                       
                       
                            json = AppResources.Label_Error;
                    }
                    return json;
                }
            }
            catch (Exception)
            {

                return AppResources.Label_Error;
            }

        }

        private void CopyUrlButton_OnClicked(object sender, EventArgs e)
        {
            DependencyService.Get<IClipboardService>().CopyToClipboard(S_URL);
        }

        private void PageInfoList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            PageInfoList.SelectedItem = null;
        }

        private void PageInfoList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var item = e.Item as PageInfoitems;
            if (item.Label == AppResources.Label_Show_More)
            {
                Navigation.PushAsync(new InfoViewer("Page"));
            }
        }

      

        private void ActionButton_OnClicked(object sender, EventArgs e)
        {
            if (Call_Action_Type_URL.Contains("http") || Call_Action_Type_URL.Contains("www") ||
                Call_Action_Type_URL.Contains(".com") || Call_Action_Type_URL.Contains(".net") ||
                Call_Action_Type_URL.Contains("/"))
            {
                Device.OpenUri(new Uri(Call_Action_Type_URL));
            }
            else
            {
                DisplayAlert(AppResources.Label_Error, AppResources.Label_There_is_no_URL_link, AppResources.Label_OK);
            }
            
        }

        private void ShowmoreButton_OnClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new HyberdPostViewer("Page",""));
        }

        private void OnJavascriptResponse(JavascriptResponseDelegate EventObj)
        {

            if (EventObj.Data.Contains("type"))
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(EventObj.Data);
                string type = data["type"].ToString();
                if (type == "user")
                {
                    string Userid = data["profile_id"].ToString();
                    if (WowonderPhone.Settings.User_id == Userid)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Navigation.PushAsync(new MyProfilePage());
                        });
                    }
                   
                    else
                    {
                        InjectedJavaOpen_UserProfile(Userid);
                    }

                }
                else if (type == "lightbox")
                {
                    string ImageSource = data["image_url"].ToString();
                    var Image = new UriImageSource
                    {
                        Uri = new Uri(ImageSource),
                        CachingEnabled = true,
                        CacheValidity = new TimeSpan(2, 0, 0, 0)
                    };
                    InjectedJavaOpen_OpenImage(Image);
                }
                else if (type == "mention")
                {
                    string user_id = data["user_id"].ToString();
                    InjectedJavaOpen_UserProfile(user_id);
                }
                else if (type == "hashtag")
                {
                    string hashtag = data["hashtag"].ToString();

                    InjectedJavaOpen_OpenImage(hashtag);
                }
                else if (type == "url")
                {
                    string link = data["link"].ToString();

                    InjectedJavaOpen_PostLinks(link);
                }
                else if (type == "page")
                {
                    string Id = data["profile_id"].ToString();
                    if (P_PageID == Id)
                    {
                        return;
                    }
                    else
                    {
                        InjectedJavaOpen_LikePage(Id);
                    }
                 
                }
                else if (type == "group")
                {
                    string Id = data["profile_id"].ToString();

                    InjectedJavaOpen_Group(Id);
                }
                else if (type == "post_wonders" || type == "post_likes")
                {
                    string Id = data["post_id"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Like_Wonder_Viewer_Page(Id, type));
                    });
                }


            }

        }
        public void InjectedJavaOpen_UserProfile(string Userid)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new UserProfilePage(Userid, ""));
            });
        }
        public void InjectedJavaOpen_OpenImage(ImageSource Image)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushModalAsync(new ImageFullScreenPage(Image));
            });
        }
        public void InjectedJavaOpen_PostLinks(string link)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Device.OpenUri(new Uri(link));
            });
        }
        public void InjectedJavaOpen_Hashtag(string word)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new HyberdPostViewer("Hashtag", word));
            });
        }
        public void InjectedJavaOpen_LikePage(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialPageViewer(id, "",""));
            });
        }
        public void InjectedJavaOpen_Group(string id)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new SocialGroup("id", ""));
            });
        }
        private void PostWebLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            //OfflinePost.IsVisible = false;
            //OfflinePost.Source = null;
            //PostWebLoader.IsVisible = true;
            PostWebLoader.RegisterCallback("type", (str) => { });
        }

        private void PostWebLoader_OnOnNavigationError(NavigationErrorDelegate eventobj)
        {
            try
            {

                PostWebLoader.IsVisible = false;
                UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost);
            }
            catch (Exception e)
            {

            }
        }

        private NavigationRequestedDelegate PostWebLoader_OnOnNavigationStarted(NavigationRequestedDelegate eventobj)
        {
            if (eventobj.Uri.Contains(WowonderPhone.Settings.Website))
            {
                return eventobj;
            }
            else
            {
                eventobj.Cancel = true;
                return eventobj;
            }
        }
    }
}

//"call_action_type": "1",
//        "call_action_type_url": "https:\/\/www.wowonder.com",
//        "instgram": "",
//        "youtube": "",
//        "verified": "1",
//        "active": "1",
//        "registered": "4\/2016",
//        "boosted": "0",
//        "about": "",
//        "url": "https:\/\/demo.wowonder.com\/wowonder",
//        "name": "WoWonder",
//        "category": "Science and Technology",
//        "is_page_onwer": false,
//        "username": "wowonder",
//        "post_count": "2",
//        "call_action_type_text": "Read more"

//{
//    "api_status": "200",
//    "api_text": "success",
//    "api_version": "1.4.1",
//    "page_data": {
//        "page_id": "346",
//        "user_id": "7289",
//        "page_name": "FartsGalore",
//        "page_title": "Farts Galore",
//        "page_description": "",
//        "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/d-page.jpg",
//        "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/d-cover.jpg",
//        "page_category": "10",
//        "website": "",
//        "facebook": "",
//        "google": "",
//        "vk": "",
//        "twitter": "",
//        "linkedin": "",
//        "company": "",
//        "phone": "",
//        "address": "",
//        "call_action_type": "0",
//        "call_action_type_url": "",
//        "instgram": "",
//        "youtube": "",
//        "verified": "0",
//        "active": "1",
//        "registered": "9\/2016",
//        "boosted": "0",
//        "about": "",
//        "url": "https:\/\/demo.wowonder.com\/FartsGalore",
//        "name": "Farts Galore",
//        "category": "Live Style",
//        "is_page_onwer": false,
//        "username": "FartsGalore"
//    }
//}