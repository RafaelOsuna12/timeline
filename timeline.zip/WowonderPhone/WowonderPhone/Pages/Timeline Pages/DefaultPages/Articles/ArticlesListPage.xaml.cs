﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Classes;
using WowonderPhone.Languish;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages.Articles
{
    public partial class ArticlesListPage : ContentPage
    {
        public static ObservableCollection<Article> ArticleListItems = new ObservableCollection<Article>();

        public ArticlesListPage()
        {
            InitializeComponent();

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {

                if (ArticleListItems.Count > 0)
                {

                }
                else
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
                    GetLatestBlogs().ConfigureAwait(false);
                }

                if (ListViewArticle.IsVisible == false)
                {
                    ListViewArticle.IsVisible = true;
                }
                if (OfflinePage.IsVisible)
                {
                    OfflinePage.IsVisible = false;
                }
                if (EmptyArticlePage.IsVisible)
                {
                    EmptyArticlePage.IsVisible = false;
                }
            }
            else
            {
                if (ListViewArticle.IsVisible)
                {
                    ListViewArticle.IsVisible = false;
                }
                if (OfflinePage.IsVisible == false)
                {
                    OfflinePage.IsVisible = true;
                }
                if (EmptyArticlePage.IsVisible)
                {
                    EmptyArticlePage.IsVisible = false;
                }
                UserDialogs.Instance.Toast(AppResources.Label_Offline_Mode);
            }

        }

        private void ListView_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {
                var Item = e.Item as Article;
                if (Item.Url != null)
                {
                    Navigation.PushAsync(new HyberdPostViewer("Article", Item.Url));
                    //Device.OpenUri(new Uri(Item.Url));
                }
            }
            catch (Exception)
            {
              
            }
        }

        public async Task GetLatestBlogs()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_blogs",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                     var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var Parser2 = JObject.Parse(json).SelectToken("blogs").ToString();
                        JArray Article_usersArray = JArray.Parse(Parser2);
                        foreach (var Article in Article_usersArray)
                        {

                        var id = Article["id"].ToString();
                        var title = Article["title"].ToString();
                        var posted_Time = Article["posted"].ToString();
                        var category = Article["category"].ToString();
                        var thumbnail = Article["thumbnail"].ToString();
                        var url = Article["url"].ToString();
                        var view = Article["view"].ToString();

                        ArticleListItems.Add(new Article()
                        {
                            BackgroundImage = new UriImageSource
                            {
                                Uri = new Uri(thumbnail),
                                CachingEnabled = true,
                                CacheValidity = new TimeSpan(2, 0, 0, 0)
                            }
                            ,
                            Title = title,
                            Section = category,
                            Time = posted_Time,
                            Views = view,Url = url
                        });
                        }
                    }
                }
                if (ArticleListItems.Count == 0)
                {
                   
                    if (ListViewArticle.IsVisible)
                    {
                        ListViewArticle.IsVisible = false;
                    }
                    if (OfflinePage.IsVisible)
                    {
                        OfflinePage.IsVisible = false;
                    }
                    if (EmptyArticlePage.IsVisible==false)
                    {
                        EmptyArticlePage.IsVisible = true;
                    }
                }
                else
                {
                    if (ListViewArticle.IsVisible==false)
                    {
                        ListViewArticle.IsVisible = true;
                    }
                    if (OfflinePage.IsVisible)
                    {
                        OfflinePage.IsVisible = false;
                    }
                    if (EmptyArticlePage.IsVisible )
                    {
                        EmptyArticlePage.IsVisible = false;
                    }
                }

                UserDialogs.Instance.HideLoading();
                ListViewArticle.ItemsSource = ArticleListItems;
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        private void Refresh_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (ArticleListItems.Count > 0)
                {
                    ArticleListItems.Clear();
                }
              
                GetLatestBlogs().ConfigureAwait(false);

                if (ListViewArticle.IsVisible == false)
                {
                    ListViewArticle.IsVisible = true;
                }
                if (OfflinePage.IsVisible)
                {
                    OfflinePage.IsVisible = false;
                }
                if (EmptyArticlePage.IsVisible)
                {
                    EmptyArticlePage.IsVisible = false;
                }
            }
            else
            {

                if (ListViewArticle.IsVisible)
                {
                    ListViewArticle.IsVisible = false;
                }
                if (OfflinePage.IsVisible == false)
                {
                    OfflinePage.IsVisible = true;
                }
                if (EmptyArticlePage.IsVisible)
                {
                    EmptyArticlePage.IsVisible = false;
                }
                UserDialogs.Instance.Toast(AppResources.Label_Offline_Mode);
            }
        }

        private void TryButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (ArticleListItems.Count > 0)
                {
                    ArticleListItems.Clear();
                }

                GetLatestBlogs().ConfigureAwait(false);

                EmptyArticlePage.IsVisible = false;
                if (ListViewArticle.IsVisible==false)
                {
                    ListViewArticle.IsVisible = true;
                }
                if (OfflinePage.IsVisible)
                {
                    OfflinePage.IsVisible = false;
                }
                UserDialogs.Instance.Toast(AppResources.Label_Loading);
            }
            else
            {
                if (ListViewArticle.IsVisible)
                {
                    ListViewArticle.IsVisible = false;
                }
                if (OfflinePage.IsVisible==false)
                {
                    OfflinePage.IsVisible = true;
                }
                if (EmptyArticlePage.IsVisible)
                {
                    EmptyArticlePage.IsVisible = false;
                }
              
                UserDialogs.Instance.Toast(AppResources.Label_Offline_Mode);
            }
        }

        private void ArticlesListPage_OnDisappearing(object sender, EventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }
    }
}
