﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Plugin.Media;
using Plugin.Media.Abstractions;
using WowonderPhone.Controls;
using WowonderPhone.Languish;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class AddProductPage : ContentPage
    {

        public class Catatgorytems
        {
            public string Label { get; set; }
            public string Icon { get; set; }
            public ImageSource Image { get; set;}
            public Stream ImageStream { get; set; }
            public string ImageFullPath { get; set; }
        }

        public static ObservableCollection<Catatgorytems> ActivityListItems = new ObservableCollection<Catatgorytems>();

        public static string ProductName = "";
        public static string ProductLocation = "";
        public static string ProductPrice = "";
        public static string ProductDescription = "";
        public static string PikedImage = "";

        public AddProductPage()
        {
            InitializeComponent();

            ActivityList.ItemsSource = ActivityListItems;

            if (ActivityListItems.Count == 0)
            {
                ActivityListItems.Add(new Catatgorytems()
                {
                    Label = AppResources.Label_Pick_Take_Photo,
                    Icon = "\uf03e",
                });
            }


        }

        private void UploudButton_OnClicked(object sender, EventArgs e)
        {
            ProductName = ProductNameEntry.Text;
            ProductLocation = locationEntry.Text;
            ProductPrice = priceEntry.Text;
            ProductDescription = ProductDescriptionEntry.Text;
            Navigation.PushAsync(new AddProduct_CategoryPage());
        }

        private void ActivityList_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ActivityList.SelectedItem = null;
        }

        private async void ActivityList_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var Item = e.Item as Catatgorytems;
            if (Item.Label == AppResources.Label_Pick_Take_Photo)
            {
                var action = await DisplayActionSheet(AppResources.Label_Photo, AppResources.Label_Cancel, null, AppResources.Label_Choose_from_Galery, AppResources.Label_Take_a_Picture);
                if (action == AppResources.Label_Choose_from_Galery)
                {
                    await CrossMedia.Current.Initialize();
                    if (!CrossMedia.Current.IsPickPhotoSupported)
                    {
                        await DisplayAlert("Oops", "You Cannot pick an image", AppResources.Label_OK);
                        return;
                    }
                    var file = await CrossMedia.Current.PickPhotoAsync();

                    if (file == null)
                        return;

                 


                    ActivityList.IsVisible = true;
                    if (ActivityListItems.Count() > 0)
                    {
                        ActivityListItems.Clear();
                    }
                    PikedImage = file.Path.Split('/').Last();
                    ActivityListItems.Add(new Catatgorytems
                    {
                        Label = file.Path.Split('/').Last(),
                        Icon = "\uf030",
                        ImageFullPath = file.Path,
                        ImageStream = file.GetStream()
                    });

                    ActivityList.ItemsSource = ActivityListItems;

                }
                else if (action == AppResources.Label_Take_a_Picture)
                {
                    await CrossMedia.Current.Initialize();

                    if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                    {
                        await DisplayAlert("No Camera", ":( No camera avaialble.", AppResources.Label_OK);
                        return;
                    }
                    var time = DateTime.Now.ToString("hh:mm");
                    var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                    {
                        PhotoSize = PhotoSize.Medium,
                        CompressionQuality = 92,
                        SaveToAlbum = true,
                        Name = time + "PictureProduct.jpg"
                    });

                    if (file == null)
                        return;

                    ActivityList.IsVisible = true;
                    if (ActivityListItems.Count() > 0)
                    {
                        ActivityListItems.Clear();
                    }
                    PikedImage = file.Path.Split('/').Last();
                    ActivityListItems.Add(new Catatgorytems
                    {
                        Label = file.Path.Split('/').Last(),
                        Icon = "\uf030",
                        ImageFullPath = file.Path,
                        ImageStream = file.GetStream()
                    });

                    ActivityList.ItemsSource = ActivityListItems;
                }

            }
            else
            {
                try
                {
                    var Function = await DisplayAlert(AppResources.Label_Question, AppResources.Label_Do_you_want_to_add_new_image, AppResources.Label_Yes, AppResources.Label_NO);
                    if (Function)
                    {
                        ActivityListItems.Clear();
                        var action =
                            await DisplayActionSheet(AppResources.Label_Photo, AppResources.Label_Cancel, null, AppResources.Label_Choose_from_Galery, AppResources.Label_Take_a_Picture);
                        if (action == AppResources.Label_Choose_from_Galery)
                        {
                            await CrossMedia.Current.Initialize();
                            if (!CrossMedia.Current.IsPickPhotoSupported)
                            {
                                await DisplayAlert("Oops", "You Cannot pick an image", AppResources.Label_OK);
                                return;
                            }
                            var file = await CrossMedia.Current.PickPhotoAsync();

                            if (file == null)
                                return;

                            var streamReader = new StreamReader(file.GetStream());
                            var bytes = default(byte[]);
                            using (var memstream = new MemoryStream())
                            {
                                streamReader.BaseStream.CopyTo(memstream);
                                bytes = memstream.ToArray();
                            }
                            string MimeTipe = MimeType.GetMimeType(bytes, file.Path);


                            ActivityList.IsVisible = true;
                            if (ActivityListItems.Count() > 0)
                            {
                                ActivityListItems.Clear();
                            }
                            PikedImage = file.Path.Split('/').Last();
                            ActivityListItems.Add(new Catatgorytems
                            {
                                Label = file.Path.Split('/').Last(),
                                Icon = "\uf030",
                                ImageFullPath = file.Path,
                                ImageStream = file.GetStream()

                            });

                            ActivityList.ItemsSource = ActivityListItems;

                        }
                        else if (action == AppResources.Label_Take_a_Picture)
                        {
                            await CrossMedia.Current.Initialize();

                            if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakePhotoSupported)
                            {
                                await DisplayAlert("No Camera", ":( No camera avaialble.", AppResources.Label_OK);
                                return;
                            }
                            var time = DateTime.Now.ToString("hh:mm");
                            var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                            {
                                PhotoSize = PhotoSize.Medium,
                                CompressionQuality = 92,
                                SaveToAlbum = true,
                                Name = time + "PictureProduct.jpg"
                            });

                            if (file == null)
                                return;

                            ActivityList.IsVisible = true;
                            if (ActivityListItems.Count() > 0)
                            {
                                ActivityListItems.Clear();
                            }
                            PikedImage = file.Path.Split('/').Last();
                            ActivityListItems.Add(new Catatgorytems
                            {
                                Label = file.Path.Split('/').Last(),
                                Icon = "\uf030",
                                ImageFullPath = file.Path,
                                ImageStream = file.GetStream()
                            });

                            ActivityList.ItemsSource = ActivityListItems;
                        }
                    }

                }
                catch (Exception)
                {

                }
            }

        }

        private void ProductDescriptionEntry_OnFocused(object sender, FocusEventArgs e)
        {
            if (ProductDescriptionEntry.Text == AppResources.Label_Product_Description)
            {
                ProductDescriptionEntry.Text = "";
            }
        }
    }
}
