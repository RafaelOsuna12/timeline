﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Classes;
using WowonderPhone.Languish;
using WowonderPhone.Pages.CustomCells;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class MarketPage : ContentPage
    {
        private TapGestureRecognizer tapGestureRecognizer = new TapGestureRecognizer();

        public static ObservableCollection<Products> Productlist = new ObservableCollection<Products>();

        public static bool IsPageInNavigationStack<TPage>(INavigation navigation) where TPage : Page
        {
            if (navigation.NavigationStack.Count > 1)
            {
                var last = navigation.NavigationStack[navigation.NavigationStack.Count - 2];

                if (last is TPage)
                {
                    navigation.PopAsync(false);
                    return true;
                }
            }
            return false;
        }

        public MarketPage()
        {
            InitializeComponent();

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (Productlist.Count<=0)
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.None);
                    GetProducts().ConfigureAwait(false);
                }
                else
                {
                    PopulateProductsLists(Productlist);
                }
               
            }
            else
            {
                if (Productlist.Count > 0)
                {
                    PopulateProductsLists(Productlist);
                }
                else
                {
                    OfflinePage.IsVisible = true;
                }
                
            }
            
           
        }
      
        public async Task GetProducts()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("user_profile_id", Settings.User_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response =
                        await
                            client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_products",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var Products = JObject.Parse(json).SelectToken("products").ToString();
                        JArray ProductsdataArray = JArray.Parse(Products);

                        foreach (var PRODUCT in ProductsdataArray)
                        {
                            var name = PRODUCT["name"].ToString();
                            var description = PRODUCT["description"].ToString();
                            var price = PRODUCT["price"].ToString();
                            var location = PRODUCT["location"].ToString();
                            
                            JArray ImagesArray = JArray.Parse(PRODUCT["images"].ToString());
                            var image = "";
                            if (ImagesArray.Count > 0)
                            {
                                foreach (var Img in ImagesArray)
                                {
                                    image = Img["image"].ToString();
                                    break;
                                }


                                JObject Seller = JObject.FromObject(PRODUCT["seller"]);
                                var Seller_name = Seller["name"].ToString();
                                var Seller_User_id = Seller["user_id"].ToString();
                                
                                Productlist.Add(new Products
                                {
                                    Name = name,
                                    Description = description,
                                    Image = new UriImageSource
                                    {
                                        Uri = new Uri(image),
                                        CachingEnabled = true,
                                        CacheValidity = new TimeSpan(5, 1, 0, 0)
                                    },
                                    Price = price,
                                    ThumbnailHeight = "100",
                                    Manufacturer = Seller_name,Manufacturer_UserID = Seller_User_id

                                });
                            }
                            
                        }
                        PopulateProductsLists(Productlist);
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost, 2000);
                    }
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            tapGestureRecognizer.Tapped += OnBannerTapped;
            //EcommerceProductGridBanner.GestureRecognizers.Add(tapGestureRecognizer);
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            tapGestureRecognizer.Tapped -= OnBannerTapped;
            //EcommerceProductGridBanner.GestureRecognizers.Remove(tapGestureRecognizer);
        }

        private void PopulateProductsLists(ObservableCollection<Products> productsList)
        {
            if (productsList.Count == 0)
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    ShowDataGrid.IsVisible = false;
                    EmptyMarketPage.IsVisible = true;
                    if (OfflinePage.IsVisible)
                    {
                        OfflinePage.IsVisible = false;
                    }
                });
            }
            else
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    if (ShowDataGrid.IsVisible == false)
                    {
                        ShowDataGrid.IsVisible = true;
                    }
                   
                    EmptyMarketPage.IsVisible = false;
                    if (OfflinePage.IsVisible)
                    {
                        OfflinePage.IsVisible = false;
                    }
                });
            }
            var lastHeight = "100";
            var y = 0;
            var column = LeftColumn;
            var productTapGestureRecognizer = new TapGestureRecognizer();
            productTapGestureRecognizer.Tapped += OnProductTapped;

            for (var i = 0; i < productsList.Count; i++)
            {
                var item = new ProductGridItemTemplate();

                if (i > 0)
                {

                    if (i == 3 || i == 4 || i == 7 || i == 8 || i == 11 || i == 12)
                    {

                        lastHeight = "100";
                    }
                    else
                    {
                        lastHeight = "190";
                    }

                    if (i % 2 == 0)
                    {
                        column = LeftColumn;
                        y++;
                    }
                    else
                    {
                        column = RightColumn;
                    }
                }

                productsList[i].ThumbnailHeight = lastHeight;
                item.BindingContext = productsList[i];
                item.GestureRecognizers.Add(productTapGestureRecognizer);
                column.Children.Add(item);
            }


        }

        private async void OnProductTapped(Object sender, EventArgs e)
        {
            var selectedItem = (Products)((ProductGridItemTemplate)sender).BindingContext;

            var productView = new ProductItemViewPage()
            {
                BindingContext = selectedItem
            };

            await Navigation.PushAsync(productView);
        }

        private async void OnBannerTapped(Object sender, EventArgs e)
        {
            uint duration = 500;
            var visualElement = (VisualElement)sender;

            await Task.WhenAll(
                visualElement.FadeTo(0, duration / 2, Easing.CubicIn),
                visualElement.ScaleTo(0, duration / 2, Easing.CubicInOut)
            );

            visualElement.HeightRequest = 0;
        }

        private void LoadMore_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                Productlist.Clear();
                var column = LeftColumn;
                column.Children.Clear();
                var columnr = RightColumn;
                columnr.Children.Clear();
                UserDialogs.Instance.ShowLoading("Loading", MaskType.Clear);
                GetProducts().ConfigureAwait(false);
            }
            else
            {
                UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection, 2000);
            }
        }

        private async void AddProducts_OnClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AddProductPage());
        }

        private void MarketPage_OnAppearing(object sender, EventArgs e)
        {
            var Count = LeftColumn.Children.Count + RightColumn.Children.Count;
            if (Productlist.Count != Count)
            {
                var column = LeftColumn;
                column.Children.Clear();
                var columnr = RightColumn;
                columnr.Children.Clear();
                PopulateProductsLists(Productlist);
            }
           
        }

        private void TryButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
               
               UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
               GetProducts().ConfigureAwait(false);
                
            }
            else
            {
                UserDialogs.Instance.Toast(AppResources.Label_You_are_still_Offline);
                OfflinePage.IsVisible = true;
            }
        }

        private async void AddproductButton_OnClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new AddProductPage());
        }

        private void MarketPage_OnDisappearing(object sender, EventArgs e)
        {
            UserDialogs.Instance.HideLoading();
        }
    }
}


 //"products": [
 //       {
 //           "id": "525",
 //           "user_id": "15544",
 //           "name": "Demo Car",
 //           "description": "NIce Cars for everbody",
 //           "category": "2",
 //           "price": "1.00",
 //           "location": "Bangkok Thailand",
 //           "status": "0",
 //           "type": "0",
 //           "time": "1488808186",
 //           "active": "1",
 //           "images": [
 //               {
 //                   "id": "738",
 //                   "image": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/03\/tL6zO5rRQPyGXeKSPU5i_06_a8d75267e644b6bb6dbefcf10c260a7c_image.jpg",
 //                   "product_id": "525",
 //                   "image_org": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/03\/tL6zO5rRQPyGXeKSPU5i_06_a8d75267e644b6bb6dbefcf10c260a7c_image_small.jpg"
 //               }
 //           ],
 //           "time_text": "2 days ago",
 //           "post_id": "22060",
 //           "edit_description": "NIce Cars for everbody",
 //           "url": "https:\/\/demo.wowonder.com\/post\/22060",
 //           "seller": {
 //               "user_id": "15544",
 //               "username": "demomax",
 //               "email": "ybgexosc@sharklasers.com",
 //               "password": "cb671ccd184110e6a38625b97471dab2",
 //               "first_name": "Max",
 //               "last_name": "Wonder",
 //               "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/03\/ZmApf7s2GBqhb5bxeLkr_06_f338470c7fa7440f23cecf22261876db_avatar.jpg",
 //               "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/03\/9ZWfcweyhjUmZIhx6ham_06_0824c6ab9e601da001f82542228dc5b6_cover.png",
 //               "background_image": "",
 //               "background_image_status": "0",
 //               "relationship_id": "0",
 //               "address": "",
 //               "working": "",
 //               "working_link": "",
 //               "about": "",
 //               "school": "",
 //               "gender": "male",
 //               "birthday": "1988-09-01",
 //               "country_id": "213",
 //               "website": "",
 //               "facebook": "",
 //               "google": "",
 //               "twitter": "",
 //               "linkedin": "",
 //               "youtube": "",
 //               "vk": "",
 //               "instagram": "",
 //               "language": "english",
 //               "email_code": "147d7a1e07d1719a091a2e3330479ab1",
 //               "src": "site",
 //               "ip_address": "223.204.248.136",
 //               "follow_privacy": "0",
 //               "post_privacy": "ifollow",
 //               "message_privacy": "0",
 //               "confirm_followers": "0",
 //               "show_activities_privacy": "1",
 //               "birth_privacy": "0",
 //               "visit_privacy": "0",
 //               "verified": "1",
 //               "lastseen": "1488808371",
 //               "showlastseen": "1",
 //               "emailNotification": "1",
 //               "e_liked": "1",
 //               "e_wondered": "1",
 //               "e_shared": "1",
 //               "e_followed": "1",
 //               "e_commented": "1",
 //               "e_visited": "1",
 //               "e_liked_page": "1",
 //               "e_mentioned": "1",
 //               "e_joined_group": "1",
 //               "e_accepted": "1",
 //               "e_profile_wall_post": "1",
 //               "status": "0",
 //               "active": "1",
 //               "admin": "0",
 //               "type": "user",
 //               "registered": "3\/2017",
 //               "start_up": "0",
 //               "start_up_info": "1",
 //               "startup_follow": "0",
 //               "startup_image": "1",
 //               "last_email_sent": "0",
 //               "phone_number": "",
 //               "sms_code": "0",
 //               "is_pro": "1",
 //               "pro_time": "1488807599",
 //               "pro_type": "4",
 //               "joined": "1488807406",
 //               "css_file": "",
 //               "timezone": "UTC",
 //               "referrer": "0",
 //               "balance": "0",
 //               "paypal_email": "",
 //               "notifications_sound": "0",
 //               "order_posts_by": "0",
 //               "avatar_org": "upload\/photos\/2017\/03\/ZmApf7s2GBqhb5bxeLkr_06_f338470c7fa7440f23cecf22261876db_avatar.jpg",
 //               "cover_org": "upload\/photos\/2017\/03\/9ZWfcweyhjUmZIhx6ham_06_0824c6ab9e601da001f82542228dc5b6_cover.png",
 //               "cover_full": "upload\/photos\/2017\/03\/9ZWfcweyhjUmZIhx6ham_06_0824c6ab9e601da001f82542228dc5b6_cover_full.png",
 //               "id": "15544",
 //               "url": "https:\/\/demo.wowonder.com\/demomax",
 //               "name": "Max Wonder"
 //           }
 //       },