﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Classes;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.CustomCells;

using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages.DefaultPages
{
    public partial class AlbumPage : ContentPage
    {
        public static List<Albums> Albumlist = new List<Albums>();

        public AlbumPage()
        {
            InitializeComponent();

            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (Albumlist.Count > 0)
                {
                    PopulateAlbumLists(Albumlist).ConfigureAwait(false);
                }
                else
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.None);
                    GetMyAlbums().ConfigureAwait(false);
                  
                }  
            }
            else
            {
                ShowDataGrid.IsVisible = false;
                OfflinePage.IsVisible = true;
               
            }
           
        }

        public async Task GetMyAlbums()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", Settings.User_id),
                        new KeyValuePair<string, string>("user_profile_id", Settings.User_id),
                        new KeyValuePair<string, string>("s", Settings.Session)
                    });

                    var response = await client.PostAsync(Settings.Website + "/app_api.php?application=phone&type=get_albums",  formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var albums = JObject.Parse(json).SelectToken("albums").ToString();
                        JArray ImagedataArray = JArray.Parse(albums);

                        foreach (var Image in ImagedataArray)
                        {
                            var url = Image["url"].ToString();
                            var post_id = Image["post_id"].ToString();
                            var Orginaltext = Image["Orginaltext"].ToString();
                            var post_time = Image["post_time"].ToString();
                            var postFile = Image["postFile_full"].ToString();
                            var limit_comments = Image["post_comments"].ToString();
                            var post_likes = Image["post_likes"].ToString();
                            var post_wonders = Image["post_wonders"].ToString();
                            JObject PublisherImage = JObject.FromObject(Image["publisher"]);
                            var Publishername = PublisherImage["name"].ToString();
                           // var PublisherAvatar = PublisherImage["name"].ToString();
                            var DecodedOrginaltext = System.Net.WebUtility.HtmlDecode(Orginaltext);
                            JArray CommentsArray = JArray.Parse(Image["get_post_comments"].ToString());
                            var image = "";

                            var Commentlist = new List<Albums.Comment>();

                            if (CommentsArray.Count > 0)
                            {
                                foreach (var Comment in CommentsArray)
                                {
                                    var comment_likes = Comment["comment_likes"].ToString();
                                    var OrginalText = System.Net.WebUtility.HtmlDecode(Comment["Orginaltext"].ToString());
                                    var Commenterurl = Comment["url"].ToString();
                                    JObject CommentPublisher = JObject.FromObject(Comment["publisher"]);
                                    var avatar = CommentPublisher["avatar"].ToString();
                                    var cover = CommentPublisher["cover"].ToString();
                                    var NameUser = CommentPublisher["name"].ToString();
                                    var user_id = CommentPublisher["user_id"].ToString();
                                    var Username = CommentPublisher["username"].ToString();
                                    var DecodedCommentOrginaltext = System.Net.WebUtility.HtmlDecode(OrginalText);
                                    var Imagepath = DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id);
                                    var ImageMediaFile = ImageSource.FromFile(Imagepath);

                                    if (DependencyService.Get<IPicture>().GetPictureFromDisk(avatar, user_id) =="File Dont Exists")
                                    {
                                        ImageMediaFile = new UriImageSource
                                        {
                                            Uri = new Uri(avatar),
                                            CachingEnabled = true,
                                            CacheValidity = new TimeSpan(5, 0, 0, 0)
                                        };

                                       
                                        DependencyService.Get<IPicture>().SavePictureToDisk(avatar, user_id);
                                    }
                                   
                                    Commentlist.Add( new Albums.Comment()
                                    {
                                        CommentText = DecodedCommentOrginaltext,
                                        CommentLikes = comment_likes,CommenterProfileUrl = Commenterurl,NameCommenter = NameUser,UserID = user_id,Username = Username,
                                        AvatarUser = ImageMediaFile ,
                                    });
                                }
                            }

                            Albumlist.Add(new Albums()
                            {
                                Name = "My Album",
                                Image = new UriImageSource
                                {
                                    Uri = new Uri(postFile),
                                    CachingEnabled = true,
                                    CacheValidity = new TimeSpan(5, 1, 0, 0)
                                },
                                Imagetext = DecodedOrginaltext,
                                ThumbnailHeight = "100",
                                Postid = post_id,
                                WonderCount = post_wonders,
                                LikesCount = post_likes,
                                CommentsCount = limit_comments,
                                ImageComments = Commentlist,
                                Publishername= Publishername,
                                ImageTime = post_time

                            });

                        }

                        
                        PopulateAlbumLists(Albumlist).ConfigureAwait(false);
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost, 2000);
                    }

                    UserDialogs.Instance.HideLoading();
                    if (Albumlist.Count == 0)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            ShowDataGrid.IsVisible = false;
                            EmptyAlbumPage.IsVisible = true;
                            if (OfflinePage.IsVisible)
                            {
                                OfflinePage.IsVisible = false;
                            }
                        });
                    }
                    else
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            ShowDataGrid.IsVisible = true;
                            EmptyAlbumPage.IsVisible = false;
                            OfflinePage.IsVisible = false;
                        });
                    }
                    
                }
            }
            catch (Exception)
            {
                UserDialogs.Instance.HideLoading();
            }
        }

        private async Task PopulateAlbumLists(List<Albums> AlbumsList)
        {
            
            var lastHeight = "128";
            var y = 0;
            var column = LeftColumn;
            var productTapGestureRecognizer = new TapGestureRecognizer();
            productTapGestureRecognizer.Tapped += OnProductTapped;

            for (var i = 0; i < AlbumsList.Count; i++)
            {
                var item = new ImageGriditemTemplate();

                if (i % 2 == 0)
                {
                    column = LeftColumn;
                    y++;
                }
                else
                {

                    column = RightColumn;
                }

                AlbumsList[i].ThumbnailHeight = lastHeight;
                item.BindingContext = AlbumsList[i];
                item.GestureRecognizers.Add(productTapGestureRecognizer);
                column.Children.Add(item);
            }
        }

        private async void OnProductTapped(Object sender, EventArgs e)
        {
            var selectedItem = (Albums)((ImageGriditemTemplate)sender).BindingContext;

            var productView = new ImageCommentPage(selectedItem.Postid)
            {
                BindingContext = selectedItem
            };

            await Navigation.PushAsync(productView);
        }

        private void Refresh_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                Albumlist.Clear();
                var column = LeftColumn;
                column.Children.Clear();
                var columnr = RightColumn;
                columnr.Children.Clear();
                UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
                GetMyAlbums().ConfigureAwait(false);
            }
            else
            {
                
                
                UserDialogs.Instance.ShowError(AppResources.Label_CheckYourInternetConnection, 2000);
            }
        }

        private void AlbumPage_OnAppearing(object sender, EventArgs e)
        {
            var Count = LeftColumn.Children.Count + RightColumn.Children.Count;
            if (Albumlist.Count != Count)
            {
                var column = LeftColumn;
                column.Children.Clear();
                var columnr = RightColumn;
                columnr.Children.Clear();
                PopulateAlbumLists(Albumlist).ConfigureAwait(false);
            }
            
        }
       
        private void PostButton_OnClicked(object sender, EventArgs e)
        {
            try
            {
                Navigation.PushAsync(new AddPost(null));
            }
            catch (Exception exception)
            {
               
            }
            
        }

      

        private void TryButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                if (Albumlist.Count > 0)
                {
                    PopulateAlbumLists(Albumlist).ConfigureAwait(false);
                }
                else
                {
                    UserDialogs.Instance.ShowLoading(AppResources.Label_Loading, MaskType.Clear);
                    GetMyAlbums().ConfigureAwait(false);
                }
            }
            else
            {
                UserDialogs.Instance.Toast(AppResources.Label_You_are_still_Offline);
                OfflinePage.IsVisible = true;
            }
        }
    }
}



//"api_status": "200",
//    "api_text": "success",
//    "api_version": "1.4.1",
//    "albums": [
//        {

            //"id": "22781",
            //"post_id": "22781",
            //"user_id": "7367",
            //"recipient_id": "0",
            //"postText": "Wowonder Native <a href=\"https:\/\/demo.wowonder.com\/hashtag\/Timeline\" class=\"hash\">#Timeline<\/a> <a href=\"https:\/\/demo.wowonder.com\/hashtag\/Android\" class=\"hash\">#Android<\/a> Version <a href=\"https:\/\/demo.wowonder.com\/hashtag\/Release\" class=\"hash\">#Release<\/a> on 1\/4\/2017  <br>----------------------------  <br>+ 30 Fully customizable views crafted in XAML",
            //"page_id": "0",
            //"group_id": "0",
            //"postLink": "",
            //"postLinkTitle": "",
            //"postLinkImage": "",
            //"postLinkContent": "",
            //"postVimeo": "",
            //"postDailymotion": "",
            //"postFacebook": "",
            //"postFile": "upload\/photos\/2017\/03\/qdImTJXyOypBpZOd7hvL_14_716118c782ddc3f2cd84ba0a4d7e1a7b_image.jpg",
            //"postFileName": "white-abstract-hd-wallpapers-2.jpg",
            //"postYoutube": "",
            //"postVine": "",
            //"postSoundCloud": "",
            //"postMap": "",
            //"postShare": "0",
            //"postPrivacy": "0",
            //"postType": "post",
            //"postFeeling": "",
            //"postListening": "",
            //"postTraveling": "",
            //"postWatching": "",
            //"postPlaying": "",
            //"time": "1489518558",
            //"registered": "3\/2017",
            //"album_name": "",
            //"multi_image": "0",
            //"boosted": "0",
            //"product_id": "0",
            //"poll_id": "0",
            //"publisher": {
            //    "user_id": "7367",
            //    "username": "allen1992d",
            //    "email": "allen19933@yahoo.com",
            //    "password": "91e5700955bb61c7a60e641cb4835b7e",
            //    "first_name": "Elin",
            //    "last_name": "Doughouz",
            //    "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/11\/k3dXosd1qiH2vozlK1TU_01_361332fb75ecc64baa00ba9d55f7afc6_avatar.jpeg",
            //    "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/01\/4Idd1UwKUBgHTfHiptJV_14_22c4601994fd702598c26ac5fcfe58d8_cover.png",
            //    "background_image": "",
            //    "background_image_status": "0",
            //    "relationship_id": "0",
            //    "address": "\u0130stanbul, T\u00fcrkiye",
            //    "working": "WoWonder",
            //    "working_link": "http:\/\/www.wowonder.com",
            //    "about": "",
            //    "school": "",
            //    "gender": "male",
            //    "birthday": "1992-04-01",
            //    "country_id": "219",
            //    "website": "",
            //    "facebook": "",
            //    "google": "",
            //    "twitter": "",
            //    "linkedin": "",
            //    "youtube": "",
            //    "vk": "",
            //    "instagram": "",
            //    "language": "english",
            //    "email_code": "91e5700955bb61c7a60e641cb4835b7e",
            //    "src": "site",
            //    "ip_address": "78.180.196.60",
            //    "follow_privacy": "0",
            //    "post_privacy": "everyone",
            //    "message_privacy": "1",
            //    "confirm_followers": "0",
            //    "show_activities_privacy": "1",
            //    "birth_privacy": "0",
            //    "visit_privacy": "1",
            //    "verified": "1",
            //    "lastseen": "1487193210",
            //    "showlastseen": "1",
            //    "emailNotification": "1",
            //    "e_liked": "1",
            //    "e_wondered": "1",
            //    "e_shared": "1",
            //    "e_followed": "1",
            //    "e_commented": "1",
            //    "e_visited": "1",
            //    "e_liked_page": "1",
            //    "e_mentioned": "1",
            //    "e_joined_group": "1",
            //    "e_accepted": "1",
            //    "e_profile_wall_post": "1",
            //    "status": "1",
            //    "active": "1",
            //    "admin": "0",
            //    "type": "user",
            //    "registered": "9\/2016",
            //    "start_up": "1",
            //    "start_up_info": "1",
            //    "startup_follow": "1",
            //    "startup_image": "1",
            //    "last_email_sent": "0",
            //    "phone_number": "05360644377",
            //    "sms_code": "0",
            //    "is_pro": "1",
            //    "pro_time": "1487709854",
            //    "pro_type": "4",
            //    "joined": "1474822208",
            //    "css_file": "",
            //    "timezone": "Europe\/Istanbul",
            //    "referrer": "0",
            //    "balance": "0",
            //    "paypal_email": "",
            //    "notifications_sound": "0",
            //    "order_posts_by": "0",
            //    "avatar_org": "upload\/photos\/2016\/11\/k3dXosd1qiH2vozlK1TU_01_361332fb75ecc64baa00ba9d55f7afc6_avatar.jpeg",
            //    "cover_org": "upload\/photos\/2017\/01\/4Idd1UwKUBgHTfHiptJV_14_22c4601994fd702598c26ac5fcfe58d8_cover.png",
            //    "cover_full": "upload\/photos\/2017\/01\/4Idd1UwKUBgHTfHiptJV_14_22c4601994fd702598c26ac5fcfe58d8_cover_full.png",
            //    "id": "7367",
            //    "url": "https:\/\/demo.wowonder.com\/allen1992d",
            //    "name": "Elin Doughouz"
            //},
            //"limit_comments": 5,
            //"limited_comments": true,
            //"is_group_post": false,
            //"group_recipient_exists": false,
            //"group_admin": false,
            //"Orginaltext": "Wowonder Native #Timeline #Android Version #Release on 1\/4\/2017  \n----------------------------  \n+ 30 Fully customizable views crafted in XAML",
            //"page": 0,
            //"url": "https:\/\/demo.wowonder.com\/post\/22781_wowonder-native-timeline-android-version-release-on-1-4-2017-30-fully-customizab.html",
            //"via_type": "",
            //"recipient_exists": false,
            //"recipient": "",
            //"admin": true,
            //"is_post_saved": false,
            //"is_post_reported": false,
            //"is_post_boosted": 0,
            //"is_liked": false,
            //"is_wondered": false,
            //"post_comments": "5",
            //"post_shares": "0",
            //"post_likes": "12",
            //"post_wonders": "1",
            //"is_post_pinned": false,
            //"get_post_comments": [
            //    {
            //        "id": "6680",
            //        "user_id": "7306",
            //        "page_id": "0",
            //        "post_id": "22781",
            //        "text": "Awesome, can&#039;t wait... I wish if you upload bigger screenshots separately. As all these screenshots are on one image and Wowonder photo viewer is not so good yet <i class=\"twa-lg twa twa-disappointed\"><\/i> it needs improving",
            //        "c_file": "",
            //        "time": "1489523955",
            //        "publisher": {
            //            "user_id": "7306",
            //            "username": "Kisssssss",
            //            "email": "khan@live.com",
            //            "password": "818121b51acaf5c90408131dcd38d8e4",
            //            "first_name": "",
            //            "last_name": "",
            //            "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/09\/cgW2C7XmYtPiVH54ojsm_25_4de142106005e288c4f9b8cb9065bdaf_avatar.JPG",
            //            "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2016\/09\/aqPr8MBBN3cAh3L6U8BM_25_e91157ee639e0297ab4d503522b5a9ca_cover.JPG",
            //            "background_image": "",
            //            "background_image_status": "0",
            //            "relationship_id": "0",
            //            "address": "",
            //            "working": "",
            //            "working_link": "",
            //            "about": "",
            //            "school": "",
            //            "gender": "male",
            //            "birthday": "0000-00-00",
            //            "country_id": "219",
            //            "website": "",
            //            "facebook": "",
            //            "google": "",
            //            "twitter": "",
            //            "linkedin": "",
            //            "youtube": "",
            //            "vk": "",
            //            "instagram": "",
            //            "language": "english",
            //            "email_code": "4e388493713b0a2927398f19cbcb2d73",
            //            "src": "site",
            //            "ip_address": "217.165.62.5",
            //            "follow_privacy": "0",
            //            "post_privacy": "ifollow",
            //            "message_privacy": "0",
            //            "confirm_followers": "1",
            //            "show_activities_privacy": "1",
            //            "birth_privacy": "0",
            //            "visit_privacy": "1",
            //            "verified": "0",
            //            "lastseen": "1486067941",
            //            "showlastseen": "1",
            //            "emailNotification": "1",
            //            "e_liked": "1",
            //            "e_wondered": "1",
            //            "e_shared": "1",
            //            "e_followed": "1",
            //            "e_commented": "1",
            //            "e_visited": "1",
            //            "e_liked_page": "1",
            //            "e_mentioned": "1",
            //            "e_joined_group": "1",
            //            "e_accepted": "1",
            //            "e_profile_wall_post": "1",
            //            "status": "1",
            //            "active": "1",
            //            "admin": "0",
            //            "type": "user",
            //            "registered": "9\/2016",
            //            "start_up": "1",
            //            "start_up_info": "1",
            //            "startup_follow": "1",
            //            "startup_image": "1",
            //            "last_email_sent": "0",
            //            "phone_number": "",
            //            "sms_code": "0",
            //            "is_pro": "0",
            //            "pro_time": "0",
            //            "pro_type": "0",
            //            "joined": "1474804526",
            //            "css_file": "",
            //            "timezone": "Asia\/Dubai",
            //            "referrer": "0",
            //            "balance": "0",
            //            "paypal_email": "",
            //            "notifications_sound": "0",
            //            "order_posts_by": "0",
            //            "avatar_org": "upload\/photos\/2016\/09\/cgW2C7XmYtPiVH54ojsm_25_4de142106005e288c4f9b8cb9065bdaf_avatar.JPG",
            //            "cover_org": "upload\/photos\/2016\/09\/aqPr8MBBN3cAh3L6U8BM_25_e91157ee639e0297ab4d503522b5a9ca_cover.JPG",
            //            "cover_full": "upload\/photos\/2016\/09\/aqPr8MBBN3cAh3L6U8BM_25_e91157ee639e0297ab4d503522b5a9ca_cover_full.JPG",
            //            "id": "7306",
            //            "url": "https:\/\/demo.wowonder.com\/Kisssssss",
            //            "name": "Kisssssss"
            //        },
            //        "url": "https:\/\/demo.wowonder.com\/Kisssssss",
            //        "Orginaltext": "Awesome, can&#039;t wait... I wish if you upload bigger screenshots separately. As all these screenshots are on one image and Wowonder photo viewer is not so good yet :( it needs improving",
            //        "onwer": false,
            //        "post_onwer": true,
            //        "comment_likes": "4",
            //        "comment_wonders": "0",
            //        "is_comment_wondered": false,
            //        "is_comment_liked": true
            //    },
            //    {
            //        "id": "6682",
            //        "user_id": "7704",
            //        "page_id": "0",
            //        "post_id": "22781",
            //        "text": "<span class=\"user-popover\" data-id=\"7367\" data-type=\"user\"><a href=\"https:\/\/demo.wowonder.com\/allen1992d\" class=\"hash\" data-ajax=\"?link1=timeline&u=allen1992d\">Elin Doughouz<\/a><\/span> can I see the &quot;following&quot; of another user?",
            //        "c_file": "",
            //        "time": "1489524780",
            //        "publisher": {
            //            "user_id": "7704",
            //            "username": "dameren",
            //            "email": "coolops@yandex.ru",
            //            "password": "3d7f709680f4cbbf36d44dcc7ccbac7a",
            //            "first_name": "King",
            //            "last_name": "Style",
            //            "avatar": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/03\/Buia6F8iLm1eeYNdSbaG_09_b5b0a91b8d0db33b6305051d7d347aea_avatar.jpg",
            //            "cover": "https:\/\/wowonder.s3.amazonaws.com\/upload\/photos\/2017\/01\/Cv7RteYlhy8EdNqbr7uZ_14_974db447c9cf0fd307f83fd79f1e07d1_cover.jpeg",
            //            "background_image": "",
            //            "background_image_status": "0",
            //            "relationship_id": "0",
            //            "address": "\u0421\u0430\u043d\u043a\u0442-\u041f\u0435\u0442\u0435\u0440\u0431\u0443\u0440\u0433, \u0433\u043e\u0440\u043e\u0434 \u0421\u0430\u043d\u043a\u0442-\u041f\u0435\u0442\u0435\u0440\u0431\u0443\u0440\u0433, \u0420\u043e\u0441\u0441\u0438\u044f",
            //            "working": "DACompany",
            //            "working_link": "http:\/\/dacompany.com",
            //            "about": "\u0427\u0435\u043b\u043e\u0432\u0435\u0447\u043d\u044b\u0439 \u0447\u0435\u043b\u043e\u0432\u0435\u043a...",
            //            "school": "",
            //            "gender": "male",
            //            "birthday": "1996-01-22",
            //            "country_id": "179",
            //            "website": "",
            //            "facebook": "2081799955379515",
            //            "google": "",
            //            "twitter": "",
            //            "linkedin": "",
            //            "youtube": "",
            //            "vk": "",
            //            "instagram": "",
            //            "language": "english",
            //            "email_code": "67ef8570e9e0b8b2da6979308f537f2b",
            //            "src": "Facebook",
            //            "ip_address": "217.118.95.98",
            //            "follow_privacy": "0",
            //            "post_privacy": "ifollow",
            //            "message_privacy": "0",
            //            "confirm_followers": "0",
            //            "show_activities_privacy": "1",
            //            "birth_privacy": "0",
            //            "visit_privacy": "1",
            //            "verified": "1",
            //            "lastseen": "1488026770",
            //            "showlastseen": "1",
            //            "emailNotification": "1",
            //            "e_liked": "1",
            //            "e_wondered": "1",
            //            "e_shared": "1",
            //            "e_followed": "1",
            //            "e_commented": "1",
            //            "e_visited": "1",
            //            "e_liked_page": "1",
            //            "e_mentioned": "1",
            //            "e_joined_group": "1",
            //            "e_accepted": "1",
            //            "e_profile_wall_post": "1",
            //            "status": "1",
            //            "active": "1",
            //            "admin": "0",
            //            "type": "user",
            //            "registered": "9\/2016",
            //            "start_up": "1",
            //            "start_up_info": "1",
            //            "startup_follow": "1",
            //            "startup_image": "1",
            //            "last_email_sent": "0",
            //            "phone_number": "",
            //            "sms_code": "0",
            //            "is_pro": "1",
            //            "pro_time": "1475167405",
            //            "pro_type": "4",
            //            "joined": "1475087552",
            //            "css_file": "",
            //            "timezone": "Europe\/Moscow",
            //            "referrer": "0",
            //            "balance": "0",
            //            "paypal_email": "",
            //            "notifications_sound": "1",
            //            "order_posts_by": "0",
            //            "avatar_org": "upload\/photos\/2017\/03\/Buia6F8iLm1eeYNdSbaG_09_b5b0a91b8d0db33b6305051d7d347aea_avatar.jpg",
            //            "cover_org": "upload\/photos\/2017\/01\/Cv7RteYlhy8EdNqbr7uZ_14_974db447c9cf0fd307f83fd79f1e07d1_cover.jpeg",
            //            "cover_full": "upload\/photos\/2017\/01\/Cv7RteYlhy8EdNqbr7uZ_14_974db447c9cf0fd307f83fd79f1e07d1_cover_full.jpeg",
            //            "id": "7704",
            //            "url": "https:\/\/demo.wowonder.com\/dameren",
            //            "name": "King Style"
            //        },
            //        "url": "https:\/\/demo.wowonder.com\/dameren",
            //        "Orginaltext": "@allen1992d can I see the &quot;following&quot; of another user?",
            //        "onwer": false,
            //        "post_onwer": true,
            //        "comment_likes": "1",
            //        "comment_wonders": "0",
            //        "is_comment_wondered": false,
            //        "is_comment_liked": false
            //    },