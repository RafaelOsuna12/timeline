﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Newtonsoft.Json;

using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages.Timeline_Pages.Java_Inject_Pages;
using WowonderPhone.Pages.Timeline_Pages.DefaultPages;
using Xam.Plugin.Abstractions.Events.Inbound;
using Xamarin.Forms;
using XLabs.Ioc;
using XLabs.Platform.Device;
using XLabs.Platform.Services;

namespace WowonderPhone.Pages.Timeline_Pages
{
    public partial class HyberdPostViewer : ContentPage
    {
        public static string Page_Link = "";

        public static string Page_Type = "";

        public HyberdPostViewer(string PageType,string Link)
        {
            InitializeComponent();
            Page_Link = Link;
            Page_Type = PageType;

                var device = Resolver.Resolve<IDevice>();
                var oNetwork = device.Network; // Create Interface to Network-functions
                var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
                if (!xx)
                {
                     LoadingPost.Source= Settings.HTML_LoadingPost_Page;

                    if (PageType == "User")
                    {
                      PostWebLoader.Source = Settings.Website + "/get_news_feed?user_id=" + UserProfilePage.U_UserID;
                      this.Title = UserProfilePage.S_Name + " " + AppResources.Label_Timeline;
                    }
                    else if (PageType == "MyProfile")
                    { 
                      PostWebLoader.Source = Settings.Website + "/get_news_feed?user_id=" + Settings.User_id;
                      this.Title = AppResources.Label_My_Profile;
                    }
                    else if (PageType == "Saved Post")
                    {
                      PostWebLoader.Source = Settings.Website + "/get_news_feed?save_posts=true" + Settings.User_id;
                      this.Title = AppResources.Label_Saved_Post;
                    }
                    else if (PageType == "Page")
                    {
                     this.Title = SocialPageViewer.S_Page_Title;
                     PostWebLoader.Source = Settings.Website + "/get_news_feed?page_id=" + SocialPageViewer.P_PageID;
                    }
                    else if (PageType == "Group")
                    {
                        this.Title = SocialGroup.S_Group_Title;
                      PostWebLoader.Source = Settings.Website + "/get_news_feed?group_id=" + SocialGroup.G_GroupID;
                    }
                    else if (PageType == "Hashtag")
                   {
                    this.Title = Link;
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?hashtag=" + Link;
                   }
                   else if (PageType == "Post")
                   {
                     this.Title = AppResources.Label_Post_Page;
                     PostWebLoader.Source = Settings.Website + "/get_news_feed?post_id=" + Link;
                   }
                    else if (PageType == "Article")
                    {
                        this.Title = Link;
                        PostWebLoader.Source = Link;
                    }

                PostWebLoader.OnJavascriptResponse += OnJavascriptResponse;
                   PostWebLoader.RegisterCallback("type", (str) =>{});
                }
                else
                {

                this.Title = AppResources.Label_Offline;

                if (LoadingPost.IsVisible)
                {
                    LoadingPost.IsVisible = false;
                }
                if (PostWebLoader.IsVisible)
                {
                    PostWebLoader.IsVisible = false;
                }
                if (OfflinePage.IsVisible == false)
                {
                    OfflinePage.IsVisible = true;
                }
            }
        }

        private void CopyUrlButton_OnClicked(object sender, EventArgs e)
        {
            DependencyService.Get<IClipboardService>().CopyToClipboard(PostWebLoader.Source.ToString());
        }
    
        private async void OnJavascriptResponse(JavascriptResponseDelegate EventObj)
        {

            if (EventObj.Data.Contains("type"))
            {
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(EventObj.Data);
                string type = data["type"].ToString();
                if (type == "user")
                {
                    string Userid = data["profile_id"].ToString();
                    if (WowonderPhone.Settings.User_id == Userid)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            Navigation.PushAsync(new MyProfilePage());
                        });
                    }
                    else
                    {
                        InjectedJavaOpen_UserProfile(Userid);
                    }

                }
                else if (type == "lightbox")
                {
                    string ImageSource = data["image_url"].ToString();
                    var Image = new UriImageSource
                    {
                        Uri = new Uri(ImageSource),
                        CachingEnabled = true,
                        CacheValidity = new TimeSpan(2, 0, 0, 0)
                    };
                    InjectedJavaOpen_OpenImage(Image);
                }
                else if (type == "mention")
                {
                    string user_id = data["user_id"].ToString();
                    InjectedJavaOpen_UserProfile(user_id);
                }
                else if (type == "hashtag")
                {
                    string hashtag = data["hashtag"].ToString();

                    InjectedJavaOpen_OpenImage(hashtag);
                }
                else if (type == "url")
                {
                    string link = data["link"].ToString();

                    InjectedJavaOpen_PostLinks(link);
                }
                else if (type == "post_wonders" || type == "post_likes")
                {
                    string Id = data["post_id"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Like_Wonder_Viewer_Page(Id, type));
                    });
                }
                else if (type == "edit_post")
                {
                    string Id = data["post_id"].ToString();
                    string Edit_text = data["edit_text"].ToString();

                    Device.BeginInvokeOnMainThread(() =>
                    {
                        Navigation.PushAsync(new Edit_Post_For_Hyberd_Page(Edit_text, Id, this,null));

                    });
                }
                else if (type == "delete_post")
                {
                    string Id = data["post_id"].ToString();

                    var Qussion = await DisplayAlert(AppResources.Label_Question, AppResources.Label_Would_You_like_to_delete_this_post, AppResources.Label_Yes, AppResources.Label_NO);
                    if (Qussion)
                    {
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            PostWebLoader.InjectJavascript("$('#post-' + " + Id + ").slideUp(200, function () { $(this).remove();}); ");
                        });

                        Post_Manager("delete_post", Id).ConfigureAwait(false);
                    }
                }


            }

        }
        public void EditCommentDone(string ID, string Text)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                //var JavaCode = "$('#post-' + " + ID + ").find('#edit-post').attr('onclick', '{*type*:*edit_post*,*post_id*:*" + ID + "*,*edit_text*:*" + Text + "*}');";
                var JavaCode = "$('#post-' + " + ID + ").find('#edit-post').attr('onclick', 'rr');";
                var service = DependencyService.Get<IMethods>();
                service.ClearWebViewCache();
                var Decode = JavaCode.Replace("*", "&quot;");
                PostWebLoader.InjectJavascript(Decode);

                PostWebLoader.InjectJavascript("$('#post-' + " + ID + ").find('.post-description p').html('" + Text + "');");


            });
        }

        public void PostAjaxRefresh(string type)
        {
            if (type == "Hashtag")
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    PostWebLoader.InjectJavascript("Wo_GetNewHashTagPosts();");
                });
            }
            else
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    PostWebLoader.InjectJavascript("Wo_GetNewPosts();");
                });

            }

        }
        public async Task Post_Manager(string Type, string postid)
        {
            try
            {
                var Action = " ";
                if (Type == "edit_post")
                {
                    Action = "edit";
                }
                else
                {
                    Action = "delete";
                }
                using (var client = new HttpClient())
                {
                    var formContent = new FormUrlEncodedContent(new[]
                    {
                        new KeyValuePair<string, string>("user_id", WowonderPhone.Settings.User_id),
                        new KeyValuePair<string, string>("post_id", postid),
                        new KeyValuePair<string, string>("s",WowonderPhone.Settings.Session),
                        new KeyValuePair<string, string>("action",Action),



                    });

                    var response =
                        await
                            client.PostAsync(WowonderPhone.Settings.Website + "/app_api.php?application=phone&type=post_manager",
                                formContent);
                    response.EnsureSuccessStatusCode();
                    string json = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        if (Type == "edit_post")
                        {
                            Action = "edit";
                        }
                        else
                        {

                        }

                    }
                }
            }
            catch
            {

            }
        }
        public void InjectedJavaOpen_UserProfile(string Userid)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new UserProfilePage(Userid, ""));
            });
        }

        public void InjectedJavaOpen_OpenImage(ImageSource Image)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushModalAsync(new ImageFullScreenPage(Image));
            });
        }

        public void InjectedJavaOpen_PostLinks(string link)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Device.OpenUri(new Uri(link));
            });
        }

        public void InjectedJavaOpen_Hashtag(string word)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                Navigation.PushAsync(new HyberdPostViewer("Hashtag", word));
            });
        }

        private void PostWebLoader_OnOnContentLoaded(ContentLoadedDelegate eventobj)
        {
            if (LoadingPost.IsVisible)
            {
                LoadingPost.IsVisible = false;
                LoadingPost.Source = null;
            }
            if (PostWebLoader.IsVisible==false)
            {
                PostWebLoader.IsVisible = true;
            }
            PostWebLoader.OnJavascriptResponse += OnJavascriptResponse;
            PostWebLoader.RegisterCallback("type", (str) => { });
           
        }

        private void TryButton_OnClicked(object sender, EventArgs e)
        {
            var device = Resolver.Resolve<IDevice>();
            var oNetwork = device.Network; // Create Interface to Network-functions
            var xx = oNetwork.InternetConnectionStatus() == NetworkStatus.NotReachable;
            if (!xx)
            {
                LoadingPost.IsVisible = true;
                PostWebLoader.IsVisible = false;
                OfflinePage.IsVisible = false;
                LoadingPost.Source = Settings.HTML_LoadingPost_Page;

                if (Page_Type == "User")
                {
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?user_id=" + UserProfilePage.U_UserID;
                    Title = UserProfilePage.S_Name + " " + AppResources.Label_Timeline;
                }
                else if (Page_Type == "MyProfile")
                {
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?user_id=" + Settings.User_id;
                    this.Title = AppResources.Label_My_Profile;
                }
                else if (Page_Type == "Saved Post")
                {
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?saved_post=true" + Settings.User_id;
                    this.Title = AppResources.Label_Saved_Post;
                }
                else if (Page_Type == "Page")
                {
                    this.Title = SocialPageViewer.S_Page_Title;
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?page_id=" + SocialPageViewer.P_PageID;
                }
                else if (Page_Type == "Group")
                {
                    this.Title = SocialGroup.S_Group_Title;
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?group_id=" + SocialGroup.G_GroupID;
                }
                else if (Page_Type == "Hashtag")
                {
                    this.Title = Page_Link;
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?hashtag=" + Page_Link;
                }
                else if (Page_Type == "Post")
                {
                    this.Title = AppResources.Label_Post_Page;
                    PostWebLoader.Source = Settings.Website + "/get_news_feed?post_id=" + Page_Link;
                }

                else if (Page_Type == "Article")
                {
                    this.Title = Page_Link;
                    PostWebLoader.Source = Page_Link;
                }

            }
            else
            {
                UserDialogs.Instance.Toast(AppResources.Label_You_are_still_Offline);
                if (LoadingPost.IsVisible)
                {
                    LoadingPost.IsVisible = false;
                }
                if (PostWebLoader.IsVisible)
                {
                    PostWebLoader.IsVisible = false;
                }
                if (OfflinePage.IsVisible==false)
                {
                    OfflinePage.IsVisible = true;
                }

            }
        }

        private void PostWebLoader_OnOnNavigationError(NavigationErrorDelegate eventobj)
        {
            try
            {

                PostWebLoader.IsVisible = false;
                UserDialogs.Instance.ShowError(AppResources.Label_Connection_Lost);
                Navigation.PopAsync();
            }
            catch (Exception e)
            {

            }
        }
    }
}
