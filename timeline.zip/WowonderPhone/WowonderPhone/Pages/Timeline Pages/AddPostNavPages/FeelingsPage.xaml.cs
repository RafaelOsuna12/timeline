﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Languish;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.AddPostNavPages
{
   
    public partial class FeelingsPage : ContentPage
    {

        public class Feelingstems
        {
            public string Label { get; set; }
            public string Icon { get; set; }
            public string Value { get; set; }
            public ImageSource Image { get; set; }
        }

        public static ObservableCollection<Feelingstems> FeelingListItems = new ObservableCollection<Feelingstems>();


        public FeelingsPage()
        {
            InitializeComponent();


            FeelingListItems.Clear();


            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Angry,
                Icon = "\uD83D\uDE20",
                Value= "angry",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Funny,
                Icon = "\uD83D\uDE02",
                Value = "funny",
            });
            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Loved,
                Icon = "\uD83D\uDE0D",
                Value = "loved",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Cool,
                Icon = "\uD83D\uDE0E",
                Value = "cool",
            });
            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Happy,
                Icon = "\uD83D\uDE03",
                Value = "happy",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Tired,
                Icon = "\uD83D\uDE2B",
                Value = "tired",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Sleepy,
                Icon = "\uD83D\uDE34",
                Value = "sleepy",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Expressionless,
                Icon = "\uD83D\uDE11",
                Value = "expressionless",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Confused,
                Icon = "\uD83D\uDE15",
                Value = "confused",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Shocked,
                Icon = "\uD83D\uDE31",
                Value = "shocked",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Very_sad,
                Icon = "\uD83D\uDE2D",
                Value = "so_sad",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Blessed,
                Icon = "\uD83D\uDE07",
                Value = "blessed",
            });

            FeelingListItems.Add(new Feelingstems()
            {
                Label = AppResources.Label_Bored,
                Icon = "\uD83D\uDE15",
                Value = "bored",
            });


            FeelingsListView.ItemsSource = FeelingListItems;
        }

        private void FeelingsListView_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            var Item = e.Item as Feelingstems;

            if (AddPost.ActivityListItems.Count > 0)
            {
                AddPost.ActivityListItems.Clear();
            }

            AddPost.ActivityListItems.Add(new AddPost.Activitytems()
            {
                Label = AppResources.Label_Feeling+ " " + Item.Label,
                Icon = Item.Icon,
                Content = Item.Value,
                TypePost = "Feelings",
            });

            Navigation.PopAsync(false);
        }

        private void FeelingsListView_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            FeelingsListView.SelectedItem = null;
        }
    }
}
