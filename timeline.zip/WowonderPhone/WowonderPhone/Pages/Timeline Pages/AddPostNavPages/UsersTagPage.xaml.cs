﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Classes;
using WowonderPhone.Controls;
using WowonderPhone.Languish;
using WowonderPhone.SQLite;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.AddPostNavPages
{
    public partial class UsersTagPage : ContentPage
    {
        public static ObservableCollection<UserContacts> TagContactsList = new ObservableCollection<UserContacts>();
        public UsersTagPage()
        {
            InitializeComponent();
            try
            {
                this.Title = AppResources.Label_Mention_Friend;

                using (var data = new ContactsFunctions())
                {
                    TagListview.ItemsSource = data.GetContactCacheList();
                }
            }
            catch (Exception e)
            {
               
            }
           
           
        }

        private void SearchBarCo_OnSearchButtonPressed(object sender, EventArgs e)
        {
            try
            {
                if (SearchBarCo.Text != "")
                {
                    TagContactsList.Clear();
                    using (var data = new ContactsFunctions())
                    {
                        TagListview.ItemsSource = data.GetContactTagSearchList(SearchBarCo.Text);
                    }
                }
            }
            catch (Exception)
            {

            }
        }

        private void SearchBarCo_OnTextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (SearchBarCo.Text != "")
                {
                    TagContactsList.Clear();
                    using (var data = new ContactsFunctions())
                    {
                        var ss = data.GetContactTagSearchList(SearchBarCo.Text);
                        TagListview.ItemsSource = ss;
                    }
                }
            }
            catch (Exception)
            {

            }
        }

        private void TagListview_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            TagListview.SelectedItem = null;
        }
       
        private void TagListview_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {
                var Item = e.Item as UserContacts;
                if (Item != null)
                {
                    Item.Checkicon = "\uf058";
                }
            }
            catch (Exception exception)
            {
               
            }
          
        }

        private void DoneButton_OnClickedButton_OnClicked(object sender, EventArgs e)
        {
            try
            {
                var Count = Functions.ChatContactsList.Count(a => a.Checkicon == "\uf058");
                var TagGroup = "";
                foreach (var item in Functions.ChatContactsList)
                {
                    if (item.Checkicon == "\uf058")
                    {
                        TagGroup += " @" + item.Username;
                    }
                }

                if (Count > 0)
                {
                    AddPost.ActivityListItems.Add(new AddPost.Activitytems()
                    {
                        Label = "( " + Count + " )" + " " + AppResources.Label_Mentions,
                        Icon = "\uf02c",
                        TypePost = "Mention",
                        Content = TagGroup
                    });
                }

                Navigation.PopAsync();
            }
            catch (Exception exception)
            {
                Navigation.RemovePage(this);
            }
         
        }
    }
}
