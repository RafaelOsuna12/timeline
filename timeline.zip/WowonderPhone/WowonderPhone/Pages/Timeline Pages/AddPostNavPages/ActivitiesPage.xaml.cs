﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PropertyChanged;
using WowonderPhone.Languish;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages.AddPostNavPages
{
    public partial class ActivitiesPage : ContentPage
    {

        [ImplementPropertyChanged]
        public class ActivitiesItems
        {
            public string ActivityLabel { get; set; }
            public string value { get; set; }
            public string Checkicon { get; set; }
            public string CheckiconColor { get; set; }

        }

        public static ObservableCollection<ActivitiesItems> ActivitiesListItemsCollection =
            new ObservableCollection<ActivitiesItems>();

        public ActivitiesPage()
        {
            InitializeComponent();

            if (ActivitiesListItemsCollection.Count == 0)
            {
                ActivitiesListItemsCollection.Add(new ActivitiesItems()
                {
                    ActivityLabel = AppResources.Label_Traveling_To,
                    value = "0",
                    Checkicon = "\uf072",
                    CheckiconColor = Settings.MainColor
                });
                ActivitiesListItemsCollection.Add(new ActivitiesItems()
                {
                    ActivityLabel = AppResources.Label_Watching,
                    value = "0",
                    Checkicon = "\uf06e",
                    CheckiconColor = Settings.MainColor
                });
                ActivitiesListItemsCollection.Add(new ActivitiesItems()
                {
                    ActivityLabel = AppResources.Label_Playing_Ac,
                    value = "0",
                    Checkicon = "\uf11b",
                    CheckiconColor = Settings.MainColor
                });
                ActivitiesListItemsCollection.Add(new ActivitiesItems()
                {
                    ActivityLabel = AppResources.Label_Listening_To,
                    value = "0",
                    Checkicon = "\uf025",
                    CheckiconColor = Settings.MainColor
                });


            }
            ActivityListView.ItemsSource = ActivitiesListItemsCollection;
        }

        private void ActivityListView_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            ActivityListView.SelectedItem = null;
        }

        private async void ActivityListView_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            try
            {
                var Item = e.Item as ActivitiesItems;
                ActivitySelectedPage ActivitySelected_Page = new ActivitySelectedPage(Item.ActivityLabel);
                await Navigation.PushAsync(ActivitySelected_Page);
            }
            catch (Exception)
            {
                
            } 
        }
    }
}
