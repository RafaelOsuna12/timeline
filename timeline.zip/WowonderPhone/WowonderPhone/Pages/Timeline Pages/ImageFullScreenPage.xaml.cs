﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using FFImageLoading.Forms;
using Xamarin.Forms;

namespace WowonderPhone.Pages.Timeline_Pages
{
    public partial class ImageFullScreenPage : ContentPage
    {
        private const uint animationDuration = 100;
        private TapGestureRecognizer doubleTapGestureRecognizer;

        public ImageFullScreenPage(ImageSource source)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            ImageLoader.Source = source;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            if (doubleTapGestureRecognizer == null)
            {
                doubleTapGestureRecognizer = new TapGestureRecognizer();
                doubleTapGestureRecognizer.NumberOfTapsRequired = 2;
            }

            doubleTapGestureRecognizer.Tapped += OnImagePreviewDoubleTapped;
            ImageLoader.GestureRecognizers.Add(doubleTapGestureRecognizer);
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            doubleTapGestureRecognizer.Tapped -= OnImagePreviewDoubleTapped;
            ImageLoader.GestureRecognizers.Remove(doubleTapGestureRecognizer);
        }

        private async void OnImagePreviewDoubleTapped(object sender, EventArgs args)
        {
            if ((int)ImageLoader.Scale == 1)
            {
                await ImageLoader.ScaleTo(2, animationDuration, Easing.SinInOut);
            }
            else if ((int)ImageLoader.Scale == 2)
            {
                await ImageLoader.ScaleTo(3, animationDuration, Easing.SinInOut);
            }
            else if ((int)ImageLoader.Scale == 3)
            {
                await ImageLoader.ScaleTo(1, animationDuration, Easing.SinInOut);
            }
            else
            {
                await ImageLoader.ScaleTo(1, animationDuration, Easing.SinInOut);
            }

        }

        async void OnCloseButtonClicked(object sender, EventArgs args)
        {
            await Navigation.PopModalAsync();
        }

        private void Img_OnSuccess(object sender, CachedImageEvents.SuccessEventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ImageLoader.IsVisible = true;
                LoaderSpinner.IsVisible = false;
            });
           
        }

        private void ImageLoader_OnFinish(object sender, CachedImageEvents.FinishEventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ImageLoader.IsVisible = true;
                LoaderSpinner.IsVisible = false;
            });
           
        }

        private void ImageLoader_OnDownloadStarted(object sender, CachedImageEvents.DownloadStartedEventArgs e)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                ImageLoader.IsVisible = false;
                LoaderSpinner.IsVisible = true;
            });
           
        }

        private void ImageLoader_OnError(object sender, CachedImageEvents.ErrorEventArgs e)
        {
            UserDialogs.Instance.ShowError("Image Cannot Be Loaded");
        }
    }
}
