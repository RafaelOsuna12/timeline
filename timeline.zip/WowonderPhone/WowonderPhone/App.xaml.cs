﻿
using System;
using System.Globalization;
using WowonderPhone.Dependencies;
using WowonderPhone.Languish;
using WowonderPhone.Pages;
using WowonderPhone.Pages.Register_pages;
using WowonderPhone.SQLite;
using Xamarin.Forms;

namespace WowonderPhone
{
    public partial class App : Application
    {

        public static INavigation Navigation { get; set; }

        public  App()
        {

            L10n.SetLocale();
            var netLanguage = DependencyService.Get<ILocale>().GetCurrent();
            AppResources.Culture = new CultureInfo(netLanguage);


            using (var Data = new LoginFunctions())
            {
                //Data.ClearLoginCredentialsList();
                var CredentialStatus = Data.GetLoginCredentialsStatus();


                InitializeComponent();

                if (CredentialStatus == "Active")
                {
                    var Credential = Data.GetLoginCredentials("Active");
                    Settings.Session = Credential.Session;
                    Settings.User_id = Credential.UserID;
                    Settings.Username = Credential.Username;
                    Settings.Cookie = Credential.Cookie;
                    if (Credential.NotificationLedColor != "")
                    {

                        Settings.NotificationVibrate = Credential.NotificationVibrate;
                        Settings.NotificationSound = Credential.NotificationSound;
                        Settings.NotificationPopup = Credential.NotificationPopup;
                        Settings.NotificationLedColor = Credential.NotificationLedColor;
                        Settings.NotificationLedColorName = Credential.NotificationLedColor;

                    }
                    else
                    {
                        Credential.NotificationVibrate = true;
                        Credential.NotificationLedColor = Settings.MainColor;
                        Credential.NotificationLedColorName = AppResources.Label_Led_Color;
                        Credential.NotificationSound = true;
                        Credential.NotificationPopup = true;
                        Data.UpdateLoginCredentials(Credential);
                        Settings.NotificationVibrate = true;
                        Settings.NotificationSound = true;
                        Settings.NotificationPopup = true;
                        Settings.NotificationLedColor = Settings.MainColor;
                        Settings.NotificationLedColorName = AppResources.Label_Led_Color;
                    }



                    try
                    {

                        var navigationPage = new NavigationPage(new MasterMainSlidePage()) { };
                        navigationPage.BarBackgroundColor = Color.FromHex(Settings.MainPage_HeaderBackround_Color);
                        navigationPage.BarTextColor = Color.FromHex(Settings.MainPage_HeaderText_Color);
                        navigationPage.Title = Settings.MainPage_HeaderTextLabel;
                        navigationPage.Padding = new Thickness(0, 0, 0, 0);
                        MainPage = navigationPage;

                    }

                    catch (Exception ex)
                    {

                    }

                }
                else
                {
                    if (CredentialStatus == "Registered")
                    {
                        var Credential = Data.GetLoginCredentials("Registered");
                        Settings.Session = Credential.Session;
                        Settings.User_id = Credential.UserID;
                        Settings.Username = Credential.Username;
                        Settings.Cookie = Credential.Cookie;
                        if (Credential.NotificationLedColor != "")
                        {
                            Settings.NotificationVibrate = Credential.NotificationVibrate;
                            Settings.NotificationSound = Credential.NotificationSound;
                            Settings.NotificationPopup = Credential.NotificationPopup;
                            Settings.NotificationLedColor = Credential.NotificationLedColor;
                            Settings.NotificationLedColorName = Credential.NotificationLedColor;
                        }
                        MainPage = new NavigationPage(new UploudPicPage());

                    }
                    else
                    {
                        MainPage = new NavigationPage(new WelcomePage());
                    }

                }
            }
        }

        public void GetMainPage()
        {
            try
            {
                var navigationPage = new NavigationPage(new MasterMainSlidePage()) { };
                navigationPage.BarBackgroundColor = Color.FromHex(Settings.MainPage_HeaderBackround_Color);
                navigationPage.BarTextColor = Color.FromHex(Settings.MainPage_HeaderText_Color);
                navigationPage.Title = Settings.MainPage_HeaderTextLabel;
                navigationPage.Padding = new Thickness(0, 0, 0, 0);
                MainPage = navigationPage;
            }
            catch
            {
                App.Current.MainPage = new MasterMainSlidePage();
            }

        }

        public void OpenMainPage(WalkThrough_Page1 sss)
        {
            //MainPage = 
        }

        public static void GetLoginPage()
        {
            try
            {
                var navigationPage = new NavigationPage(new MainPage()) { };
                App.Current.MainPage = navigationPage;
            }
            catch
            {
                App.Current.MainPage = new MainPage();
            }
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }


    }
}
