﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WowonderPhone.Pages.Tabs;

namespace WowonderPhone.Dependencies
{
    public interface IMethods
    {
        void OpenImage(string Directory, string image, string Userid);

        void OpenWebsiteUrl(string Website);

        string UploudAttachment(Stream stream, string Filepath, string user_id, string recipient_id, string session, string text, string time2);
        string CreateProduct(Stream stream, string Filepath, string user_id, string name, string category, string description, string price, string location, string type);
        string AddPost(Stream stream, string Filepath, string postText, string postPrivacy, string PostType, TimelinePostsTab Page);
        void OpenMessengerApp(string Packegename);
        void ClearWebViewCache();

    }
}
