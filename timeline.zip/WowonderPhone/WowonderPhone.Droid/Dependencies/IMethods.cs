using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Android.Content;
using Android.Graphics;
using Android.Net.Http;
using Android.Webkit;
using Xamarin.Forms;
using File = System.IO.File;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WowonderPhone.Pages.Tabs;
using Xam.Plugin.Droid;
using Exception = System.Exception;

[assembly: Xamarin.Forms.Dependency(typeof(WowonderPhone.Droid.Dependencies.IMethods))]

namespace WowonderPhone.Droid.Dependencies
{
    public class IMethods : WowonderPhone.Dependencies.IMethods
    {
        public void OpenImage(string Directory, string image, string Userid)
        {
            try
            {
                if (Directory == "Disk")
                {
                    var documentsDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal) + "/" + Userid;
                    string Image = image.Split('/').Last();
                    string FilePath = System.IO.Path.Combine(documentsDirectory, Image);
                    var bytes = File.ReadAllBytes(FilePath);
                    var externalPath = global::Android.OS.Environment.ExternalStorageDirectory.Path + "/MaterialsReg/" + FilePath;
                    DirectoryInfo dirInfo = System.IO.Directory.CreateDirectory(externalPath.Remove(externalPath.LastIndexOf('/')));
                    File.WriteAllBytes(externalPath, bytes);
                    Java.IO.File file = new Java.IO.File(externalPath);
                    file.SetReadable(true);
                    Android.Net.Uri uri = Android.Net.Uri.FromFile(file);
                    Intent intent = new Intent(Intent.ActionView);
                    intent.SetDataAndType(uri, "image/*");
                    intent.SetFlags(ActivityFlags.ClearWhenTaskReset | ActivityFlags.NewTask);
                    ((MainActivity) Xamarin.Forms.Forms.Context).StartActivity(intent);
                }
                else if (Directory == "Galary")
                {
                    var dir =
                        Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDcim);
                    string Image = image.Split('/').Last();
                    string FilePath = System.IO.Path.Combine(dir + "/" + WowonderPhone.Settings.APP_Name + "/",
                        Image);
                    Intent intent = new Intent();
                    intent.SetAction(Android.Content.Intent.ActionView);
                    Android.Net.Uri uri = Android.Net.Uri.FromFile(new Java.IO.File(FilePath));
                    intent.SetDataAndType(uri, "image/*");
                    ((MainActivity) Xamarin.Forms.Forms.Context).StartActivity(intent);
                }
                else
                {
                    Intent intent = new Intent();
                    intent.SetAction(Android.Content.Intent.ActionView);
                    Android.Net.Uri uri = Android.Net.Uri.FromFile(new Java.IO.File(image));
                    intent.SetDataAndType(uri, "image/*");
                    ((MainActivity)Xamarin.Forms.Forms.Context).StartActivity(intent);
                }
            }
            catch (Exception)
            {
                
            }
           
        }

        public void OpenWebsiteUrl(string Website)
        {
            try
            {
                var uri = Android.Net.Uri.Parse(Website);
                var intent = new Intent(Intent.ActionView, uri);
                ((MainActivity)Xamarin.Forms.Forms.Context).StartActivity(intent);
            }
            catch (Exception)
            {

            }
        }
        public void OpenMessengerApp(string packegename)
        {
            try
            {
                Intent intent = Android.App.Application.Context.PackageManager.GetLaunchIntentForPackage(packegename);
                // If not NULL run the app, if not, take the user to the app store
                if (intent != null)
                {
                    intent.AddFlags(ActivityFlags.NewTask);
                    Forms.Context.StartActivity(intent);
                }
                else
                {
                    intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("market://details?id=" + packegename));
                    intent.AddFlags(ActivityFlags.NewTask);
                    Android.App.Application.Context.StartActivity(intent);
                }
            }
            catch (ActivityNotFoundException)
            {
                var intent = new Intent(Intent.ActionView, Android.Net.Uri.Parse("http://play.google.com/store/apps/details?id=" + packegename));
                intent.AddFlags(ActivityFlags.NewTask);
                Android.App.Application.Context.StartActivity(intent);
            }
        }
        public static string filepath;

        public void ClearWebViewCache()
        {
            Android.Webkit.WebView wv = new Android.Webkit.WebView(Forms.Context);
            wv.ClearCache(true);

          
        }


        public string UploudAttachment(Stream stream , string FileNameAttachment,  string user_id, string recipient_id ,string Session, string TextMsg , string time2)
        {
            try
            {

                var values = new NameValueCollection();
                values["user_id"] = user_id;
                values["recipient_id"] = recipient_id;
                values["s"] = Session;
                values["text"] = TextMsg;
                values["send_time"] = time2;

                filepath = FileNameAttachment;
                System.Threading.Tasks.Task.Factory.StartNew(() =>
                {
                    var files = new[] { new UploadFile { Name = "message_file", Filename = System.IO.Path.GetFileName(FileNameAttachment), ContentType = "text/plain", Stream = stream } };
                    var result = UploadFiles(Settings.Website + "/app_api.php?application=phone&type=insert_new_message", files, values);

                });

                return "Ok";
            }
             catch (Exception)
            {
                return "Error";
            }
        }

        public string CreateProduct(Stream stream, string Filepath, string user_id, string name, string category, string description, string price, string location, string type)
        {
            try
            {

                var values = new NameValueCollection();
                values["user_id"] = user_id;
                values["name"] = name;
                values["s"] = Settings.Session;
                values["category"] = category;
                values["description"] = description;
                values["price"] = price;
                values["location"] = location;
                values["type"] = type;

                filepath = Filepath;
                System.Threading.Tasks.Task.Factory.StartNew(() =>
                {
                    var files = new[] { new UploadFile { Name = "postPhotos", Filename = System.IO.Path.GetFileName(Filepath), ContentType = "text/plain", Stream = stream } };
                    var result = Upload(Settings.Website + "/app_api.php?application=phone&type=new_product", files, values,"");
                });

                return "Done";
            }
            catch (Exception)
            {
                return null;
            }
        }

        public string AddPost(Stream stream, string Filepath, string postText, string postPrivacy,string PostType , TimelinePostsTab Page)
        {
            try
            {
                _Page_Timeline = Page;
                var values = new NameValueCollection();
                values["user_id"] = Settings.User_id;
                values["postText"] = postText;
                values["s"] = Settings.Session;
                values["postPrivacy"] = postPrivacy;
                //filepath = Filepath;

                System.Threading.Tasks.Task.Factory.StartNew(() =>
               {
                    if (PostType == "Image")
                {
                    var files = new[] { new UploadFile { Name = "postPhotos", Filename = System.IO.Path.GetFileName(Filepath), ContentType = "text/plain", Stream = stream } };
                    var result = Upload(Settings.Website + "/app_api.php?application=phone&type=new_post", files, values, Filepath);
                }
                else if (PostType == "Video")
                    {
                        var files = new[]
                        {
                            new UploadFile
                            {
                                Name = "postVideo",
                                Filename = System.IO.Path.GetFileName(Filepath),
                                ContentType = "text/plain",
                                Stream = stream
                            }
                        };
                        var result =
                            Upload(Settings.Website + "/app_api.php?application=phone&type=new_post", files, values,
                                Filepath).ConfigureAwait(false);

                    }
                });

                
                
               
                return "Done";
            }
            catch (Exception)
            {
                return null;
            }
        }

        private TimelinePostsTab _Page_Timeline;
        public async Task<byte[]> UploadFiles(string address, IEnumerable<UploadFile> files, NameValueCollection values)
        {
            try
            {
                var request = WebRequest.Create(address);
                request.Method = "POST";
                var boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x", NumberFormatInfo.InvariantInfo);
                request.ContentType = "multipart/form-data; boundary=" + boundary;
                boundary = "--" + boundary;
               
                using (var requestStream = request.GetRequestStream())
                {
                    // Write the values
                    foreach (string name in values.Keys)
                    {
                        var buffer = Encoding.ASCII.GetBytes(boundary + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.ASCII.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\"{1}{1}", name, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.UTF8.GetBytes(values[name] + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                    }

                    // Write the files
                    foreach (var file in files)
                    {
                        var buffer = Encoding.ASCII.GetBytes(boundary + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.UTF8.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"{2}", file.Name, file.Filename, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.ASCII.GetBytes(string.Format("Content-Type: {0}{1}{1}", file.ContentType, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        file.Stream.CopyTo(requestStream);
                        buffer = Encoding.ASCII.GetBytes(System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                    }

                    var boundaryBuffer = Encoding.ASCII.GetBytes(boundary + "--");
                    requestStream.Write(boundaryBuffer, 0, boundaryBuffer.Length);
                  
                }
             
                using (var response = request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                 
                using (var stream = new MemoryStream())
                {

                    responseStream.CopyTo(stream);
                    var json = System.Text.Encoding.UTF8.GetString(stream.ToArray(), 0, stream.ToArray().Length);
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        var messages = JObject.Parse(json).SelectToken("messages").ToString();
                        JArray ChatMessages = JArray.Parse(messages);
                        
                    }

                    return stream.ToArray();
                }
            }

            catch (Exception)
            {
                return null;
            }
        }
        public async Task<byte[]> Upload(string address, IEnumerable<UploadFile> files, NameValueCollection values,string filee)
        {
            try
            {
                var request = WebRequest.Create(address);
                request.Method = "POST";
                var boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x", NumberFormatInfo.InvariantInfo);
                request.ContentType = "multipart/form-data; boundary=" + boundary;
                boundary = "--" + boundary;

                using (var requestStream = request.GetRequestStream())
                {
                    // Write the values
                    foreach (string name in values.Keys)
                    {
                        var buffer = Encoding.ASCII.GetBytes(boundary + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.ASCII.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\"{1}{1}", name, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.UTF8.GetBytes(values[name] + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                    }

                    // Write the files
                    foreach (var file in files)
                    {
                        var buffer = Encoding.ASCII.GetBytes(boundary + System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.UTF8.GetBytes(string.Format("Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"{2}", file.Name, file.Filename, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        buffer = Encoding.ASCII.GetBytes(string.Format("Content-Type: {0}{1}{1}", file.ContentType, System.Environment.NewLine));
                        requestStream.Write(buffer, 0, buffer.Length);
                        file.Stream.CopyTo(requestStream);
                        buffer = Encoding.ASCII.GetBytes(System.Environment.NewLine);
                        requestStream.Write(buffer, 0, buffer.Length);
                    }

                    var boundaryBuffer = Encoding.ASCII.GetBytes(boundary + "--");
                    requestStream.Write(boundaryBuffer, 0, boundaryBuffer.Length);

                }
              
                using (var response = request.GetResponse())
                using (var responseStream = response.GetResponseStream())

                using (var stream = new MemoryStream())
                {

                   responseStream.CopyTo(stream);
                   responseStream.Close();
                    var json = System.Text.Encoding.UTF8.GetString(stream.ToArray(), 0, stream.ToArray().Length);
                    var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(json);
                    string apiStatus = data["api_status"].ToString();
                    if (apiStatus == "200")
                    {
                        UserDialogs.Instance.ShowSuccess("Post Added", 2000);
                       
                        if (_Page_Timeline != null)
                        {
                            _Page_Timeline.PostAjaxRefresh("");
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.ShowError("Post Faild", 2000);
                    }

                    return null;
                }
            }

            catch (WebException ex)
            {
                UserDialogs.Instance.ShowError("Post Faild", 2000);
                string output = string.Empty;
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    using (var stream = new StreamReader(ex.Response.GetResponseStream()))
                    {
                        output = stream.ReadToEnd();
                    }
                }
                else if (ex.Status == WebExceptionStatus.Timeout)
                {
                    output = "Request timeout is expired.";
                }
            
            return null;
        }
        }
        public class UploadFile
        {
            public UploadFile()
            {
                ContentType = "application/octet-stream";
            }
            public string Name { get; set; }
            public string Filename { get; set; }
            public string ContentType { get; set; }
            public Stream Stream { get; set; }
        }

        internal class WoWebViewClient : WebViewClient
        {

            #region Properties

            private readonly Android.Webkit.WebView _formsWebView;
            private readonly FormsWebViewRenderer _formsRenderer;

            private string _previousUrl;

            #endregion

            #region Constructors

         
            public WoWebViewClient(Android.Webkit.WebView formsWebView)
            {

                #region Properties
                //formsWebView.LoadUrl(WowonderPhone.Settings.Website + "/app_api.php?application=phone&type=set_c&c=" + WowonderPhone.Settings.Cookie);

                _formsWebView = formsWebView;

                #endregion
            }

            #endregion

            #region Event Handlers

            public override void OnPageStarted(Android.Webkit.WebView view, string url, Bitmap favicon)
            {
                base.OnPageStarted(view, url, favicon);

            }

            public override void OnReceivedSslError(Android.Webkit.WebView view, SslErrorHandler handler, SslError error)
            {
                base.OnReceivedSslError(view, handler, error);                    //Comment this out so it will not handle the error on it's own when dealing with self-signed certs mostly

            }

            /// <summary>
            /// Used for redirecting
            /// </summary>
            /// <param name="view">The Android WebView that set off the event.</param>
            /// <param name="url">The URL that is being visited.</param>
            /// <returns>bool, true means we dealt with the URL, false means that the system needs to deal with it.</returns>
            public override bool ShouldOverrideUrlLoading(Android.Webkit.WebView view, string url)
            {

                //If you want to redirect you would use a condition and then return true
                return false;
            }

            /// <summary>
            /// This method reports unrecoverable errors from the main page only. It has been deprecated for the event handler below which receives errors for the main page as well as iframe, images, etc.
            /// </summary>
            //[Obsolete("deprecated")]
            public override void OnReceivedError(Android.Webkit.WebView view, ClientError errorCode, string description, string failingUrl)
            {
                base.OnReceivedError(view, errorCode, description, failingUrl);
                System.Console.WriteLine("\nIn AppName.Droid.FormsWebViewRenderer - Error\nError Code: {0}\nDescription: {1}\nFailing URL: {2}\n", errorCode, description, failingUrl); //TODO: Do something more useful

                //view.LoadData(/* Add your custom error message here along with the 'description' parameter or whatever */, "text/html", "UTF-8");                                         //Load custom errors
            }

            //public override void OnReceivedError(Android.Webkit.WebView view, IWebResourceRequest request, WebResourceError error) {
            //base.OnReceivedError(view, request, error);
            //Console.WriteLine("\nIn AppName.Droid.FormsWebViewRenderer - Error\nError Code: {0}\nDescription: {1}\nFailing URL: {2}\n", error.ErrorCode.ToString(), error.DescriptionFormatted.ToString(), request.Url.ToString()); //TODO: Do something more useful
            //view.LoadData(/* Add your custom error message here */, "text/html", "UTF-8");                                            //Load custom errors
            //}

            public override void OnPageFinished(Android.Webkit.WebView view, string url)
            {

                
            }

            #endregion
        }
    }
}