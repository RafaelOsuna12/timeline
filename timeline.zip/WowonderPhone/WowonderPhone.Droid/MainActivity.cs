﻿using System;
using System.Net;
using System.Net.Http;
using Acr.UserDialogs;
using Android.App;
//using TaskStackBuilder = Android.Support.V4.App;
//using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.Views;
using Android.OS;
using Plugin.Media;
using Xamarin.Forms.Platform.Android;
using XLabs.Ioc;
using XLabs.Platform.Device;
using FFImageLoading.Forms.Droid;
using ImageCircle.Forms.Plugin.Droid;
using Plugin.Permissions;
using WowonderPhone.Pages.Timeline_Pages.DefaultPages;
using Xam.Plugin.Droid;
using Xamarin.Forms;
using Boolean = System.Boolean;
using Exception = System.Exception;

namespace WowonderPhone.Droid
{
    [Activity(Label = "dddddd", Icon = "@drawable/icon", LaunchMode = LaunchMode.SingleTop, Theme = "@style/AppTheme", MainLauncher = false ,ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        protected override void OnCreate(Bundle bundle)
        {
            try
            {
               
                FormsAppCompatActivity.ToolbarResource = Resource.Layout.Toolbar;
                FormsAppCompatActivity.TabLayoutResource = Resource.Layout.Tabbar;

                base.OnCreate(bundle);

                if (Settings.TurnFullScreenOn)
                {
                    this.Window.AddFlags(WindowManagerFlags.Fullscreen);
                    this.Window.AddFlags(WindowManagerFlags.KeepScreenOn);
                }

                if (Settings.TurnSecurityProtocolType3072On)
                {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                    HttpClient client = new HttpClient(new Xamarin.Android.Net.AndroidClientHandler());
                }

                if (Settings.TurnTrustFailureOn_WebException)
                {
                    //If you are Getting this error >>> System.Net.WebException: Error: TrustFailure /// then Set it to true
                    System.Net.ServicePointManager.ServerCertificateValidationCallback += (o, certificate, chain, errors) => true;
                    System.Security.Cryptography.AesCryptoServiceProvider b = new System.Security.Cryptography.AesCryptoServiceProvider();
                }
                

                AndroidClipboardManager = (ClipboardManager)GetSystemService(ClipboardService);

               //MobileAds.Initialize(ApplicationContext, Settings.Ad_Unit_ID);


                FormsWebViewRenderer.Init();

                FormsWebViewRenderer.OnControlChanging += (sender, element, control) =>
                {
                    var webView = control as Android.Webkit.WebView;
                    webView.Settings.EnableSmoothTransition();
                   
                };

              

                global::Xamarin.Forms.Forms.Init(this, bundle);
                var container = new SimpleContainer();
                container.Register<IDevice>(t => AndroidDevice.CurrentDevice);
                //container.Register<IGeolocator, Geolocator>();
                Resolver.ResetResolver();
                Resolver.SetResolver(container.GetResolver());
                CrossMedia.Current.Initialize();
               
				ImageCircleRenderer.Init();
                //PullToRefreshLayoutRenderer.Init();
                CachedImageRenderer.Init();
                UserDialogs.Init(this);
               


                LoadApplication(new App());
                      
            }
            catch (Exception ex)
            {
               
            }

        }
        protected static Boolean isVisible = false;

        public static ClipboardManager AndroidClipboardManager { get; private set; }

        protected override void OnNewIntent(Intent intent)
        {
           
            try
            {
                if (intent.Extras.ContainsKey("username") && this.HasWindowFocus)
                {
                    var Username = intent.Extras.Get("username").ToString();
                    var UserID = intent.Extras.Get("userid").ToString();
                    App.Current.MainPage.Navigation.PushAsync(new NotificationsPage());

                    try
                    {
                        var context = Forms.Context;
                        var notificationManager = (NotificationManager)context.GetSystemService(Context.NotificationService);
                        int useridNumber = Int32.Parse(UserID);
                        notificationManager.Cancel(useridNumber);
                    }
                    catch (Exception)
                    {

                    }
                }
            }
            catch (Exception)
            {
                return;
            }
            base.OnNewIntent(intent);
        }
        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
        {
            PermissionsImplementation.Current.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

       
    }
}
