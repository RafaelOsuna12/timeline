﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;

using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using WowonderPhone.CustomRenders;
using WowonderPhone.Droid.CustomRenders;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

//[assembly: ExportRenderer(typeof(CustomEditor), typeof(AdMobViewRenderer))]
namespace WowonderPhone.Droid.CustomRenders
{
    //public class AdMobViewRenderer : ViewRenderer<AdMobView, AdView>
    //{
    //    string adUnitId = string.Empty;
    //    AdSize adSize = AdSize.SmartBanner;
    //    AdView adView;
    //    AdView CreateNativeControl()
    //    {
    //        if (adView != null)
    //            return adView;

    //        adUnitId = Settings.Ad_Unit_ID;
    //        adView = new AdView(Forms.Context);
    //        adView.AdSize = adSize;
    //        adView.AdUnitId = adUnitId;

    //        var adParams = new LinearLayout.LayoutParams(LayoutParams.WrapContent, LayoutParams.WrapContent);

    //        adView.LayoutParameters = adParams;

    //        adView.LoadAd(new AdRequest
    //                .Builder()
    //            .Build());
    //        return adView;
    //    }

    //    protected override void OnElementChanged(ElementChangedEventArgs<AdMobView> elementChangedEventArgs)
    //    {
    //        base.OnElementChanged(elementChangedEventArgs);
    //        if (Control == null)
    //        {
    //            CreateNativeControl();
    //            SetNativeControl(adView);
    //        }
    //    }
    //}
}