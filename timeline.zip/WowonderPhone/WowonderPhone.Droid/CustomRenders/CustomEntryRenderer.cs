using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Text;
using Android.Views;
using Android.Widget;
using Xamarin.Forms.Platform.Android;
using Xamarin.Forms;

using Xamarin.Forms.Platform.Android;
using Android.Text;
using WowonderPhone.CustomRenders;
using WowonderPhone.Droid.CustomRenders;
using Android.Views.InputMethods;
using WowonderPhone.Languish;

[assembly: ExportRenderer(typeof(CustomEditor), typeof(CustomEntryRenderer))]

namespace WowonderPhone.Droid.CustomRenders
{
    public class CustomEntryRenderer : EditorRenderer
    {
       
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {
            base.OnElementChanged(e);

            if (e.OldElement != null || this.Element == null)
                return;

            if (Control != null)
            {
                this.Control.InputType  = InputTypes.ClassText | InputTypes.TextFlagMultiLine;
                Control.SetBackgroundColor(Android.Graphics.Color.Argb(0, 0, 0, 0));
                Control.Hint = Settings.Label_Whats_Going_On;
                Control.LayoutParameters = new LayoutParams(LayoutParams.MatchParent, LayoutParams.WrapContent);
                SetNativeControl(Control);
            }
        }


      

    }
}